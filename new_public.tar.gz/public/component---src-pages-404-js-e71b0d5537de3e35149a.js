(window.webpackJsonp = window.webpackJsonp || []).push([
  [11],
  {
    w2l6: function(n, e, t) {
      "use strict";
      t.r(e),
        t.d(e, "default", function() {
          return o;
        });
      var u = t("q1tI"),
        a = t.n(u);
      function o() {
        return a.a.createElement(
          "div",
          null,
          a.a.createElement("h2", null, "Page Not Found")
        );
      }
    }
  }
]);
//# sourceMappingURL=component---src-pages-404-js-e71b0d5537de3e35149a.js.map
