(window.webpackJsonp = window.webpackJsonp || []).push([
  [14],
  {
    p7SW: function(t, e, i) {
      "use strict";
      i.d(e, "a", function() {
        return ri;
      });
      var s = i("pNPk"),
        r = i.n(s),
        n = i("2EcY"),
        a = {
          3: "abstract boolean byte char class double enum export extends final float goto implements import int interface long native package private protected public short static super synchronized throws transient volatile",
          5: "class enum extends super const export import",
          6: "enum",
          strict:
            "implements interface let package private protected public static yield",
          strictBind: "eval arguments"
        },
        o =
          "break case catch continue debugger default do else finally for function if return switch throw try var while with null true false instanceof typeof void delete new in this",
        p = { 5: o, 6: o + " const class extends export import super" },
        h = /^in(stanceof)?$/,
        c =
          "ªµºÀ-ÖØ-öø-ˁˆ-ˑˠ-ˤˬˮͰ-ʹͶͷͺ-ͽͿΆΈ-ΊΌΎ-ΡΣ-ϵϷ-ҁҊ-ԯԱ-Ֆՙՠ-ֈא-תׯ-ײؠ-يٮٯٱ-ۓەۥۦۮۯۺ-ۼۿܐܒ-ܯݍ-ޥޱߊ-ߪߴߵߺࠀ-ࠕࠚࠤࠨࡀ-ࡘࡠ-ࡪࢠ-ࢴࢶ-ࢽऄ-हऽॐक़-ॡॱ-ঀঅ-ঌএঐও-নপ-রলশ-হঽৎড়ঢ়য়-ৡৰৱৼਅ-ਊਏਐਓ-ਨਪ-ਰਲਲ਼ਵਸ਼ਸਹਖ਼-ੜਫ਼ੲ-ੴઅ-ઍએ-ઑઓ-નપ-રલળવ-હઽૐૠૡૹଅ-ଌଏଐଓ-ନପ-ରଲଳଵ-ହଽଡ଼ଢ଼ୟ-ୡୱஃஅ-ஊஎ-ஐஒ-கஙசஜஞடணதந-பம-ஹௐఅ-ఌఎ-ఐఒ-నప-హఽౘ-ౚౠౡಀಅ-ಌಎ-ಐಒ-ನಪ-ಳವ-ಹಽೞೠೡೱೲഅ-ഌഎ-ഐഒ-ഺഽൎൔ-ൖൟ-ൡൺ-ൿඅ-ඖක-නඳ-රලව-ෆก-ะาำเ-ๆກຂຄງຈຊຍດ-ທນ-ຟມ-ຣລວສຫອ-ະາຳຽເ-ໄໆໜ-ໟༀཀ-ཇཉ-ཬྈ-ྌက-ဪဿၐ-ၕၚ-ၝၡၥၦၮ-ၰၵ-ႁႎႠ-ჅჇჍა-ჺჼ-ቈቊ-ቍቐ-ቖቘቚ-ቝበ-ኈኊ-ኍነ-ኰኲ-ኵኸ-ኾዀዂ-ዅወ-ዖዘ-ጐጒ-ጕጘ-ፚᎀ-ᎏᎠ-Ᏽᏸ-ᏽᐁ-ᙬᙯ-ᙿᚁ-ᚚᚠ-ᛪᛮ-ᛸᜀ-ᜌᜎ-ᜑᜠ-ᜱᝀ-ᝑᝠ-ᝬᝮ-ᝰក-ឳៗៜᠠ-ᡸᢀ-ᢨᢪᢰ-ᣵᤀ-ᤞᥐ-ᥭᥰ-ᥴᦀ-ᦫᦰ-ᧉᨀ-ᨖᨠ-ᩔᪧᬅ-ᬳᭅ-ᭋᮃ-ᮠᮮᮯᮺ-ᯥᰀ-ᰣᱍ-ᱏᱚ-ᱽᲀ-ᲈᲐ-ᲺᲽ-Ჿᳩ-ᳬᳮ-ᳱᳵᳶᴀ-ᶿḀ-ἕἘ-Ἕἠ-ὅὈ-Ὅὐ-ὗὙὛὝὟ-ώᾀ-ᾴᾶ-ᾼιῂ-ῄῆ-ῌῐ-ΐῖ-Ίῠ-Ῥῲ-ῴῶ-ῼⁱⁿₐ-ₜℂℇℊ-ℓℕ℘-ℝℤΩℨK-ℹℼ-ℿⅅ-ⅉⅎⅠ-ↈⰀ-Ⱞⰰ-ⱞⱠ-ⳤⳫ-ⳮⳲⳳⴀ-ⴥⴧⴭⴰ-ⵧⵯⶀ-ⶖⶠ-ⶦⶨ-ⶮⶰ-ⶶⶸ-ⶾⷀ-ⷆⷈ-ⷎⷐ-ⷖⷘ-ⷞ々-〇〡-〩〱-〵〸-〼ぁ-ゖ゛-ゟァ-ヺー-ヿㄅ-ㄯㄱ-ㆎㆠ-ㆺㇰ-ㇿ㐀-䶵一-鿯ꀀ-ꒌꓐ-ꓽꔀ-ꘌꘐ-ꘟꘪꘫꙀ-ꙮꙿ-ꚝꚠ-ꛯꜗ-ꜟꜢ-ꞈꞋ-ꞹꟷ-ꠁꠃ-ꠅꠇ-ꠊꠌ-ꠢꡀ-ꡳꢂ-ꢳꣲ-ꣷꣻꣽꣾꤊ-ꤥꤰ-ꥆꥠ-ꥼꦄ-ꦲꧏꧠ-ꧤꧦ-ꧯꧺ-ꧾꨀ-ꨨꩀ-ꩂꩄ-ꩋꩠ-ꩶꩺꩾ-ꪯꪱꪵꪶꪹ-ꪽꫀꫂꫛ-ꫝꫠ-ꫪꫲ-ꫴꬁ-ꬆꬉ-ꬎꬑ-ꬖꬠ-ꬦꬨ-ꬮꬰ-ꭚꭜ-ꭥꭰ-ꯢ가-힣ힰ-ퟆퟋ-ퟻ豈-舘並-龎ﬀ-ﬆﬓ-ﬗיִײַ-ﬨשׁ-זּטּ-לּמּנּסּףּפּצּ-ﮱﯓ-ﴽﵐ-ﶏﶒ-ﷇﷰ-ﷻﹰ-ﹴﹶ-ﻼＡ-Ｚａ-ｚｦ-ﾾￂ-ￇￊ-ￏￒ-ￗￚ-ￜ",
        l =
          "‌‍·̀-ͯ·҃-֑҇-ׇֽֿׁׂׅׄؐ-ًؚ-٩ٰۖ-ۜ۟-۪ۤۧۨ-ۭ۰-۹ܑܰ-݊ަ-ް߀-߉߫-߽߳ࠖ-࠙ࠛ-ࠣࠥ-ࠧࠩ-࡙࠭-࡛࣓-ࣣ࣡-ःऺ-़ा-ॏ॑-ॗॢॣ०-९ঁ-ঃ়া-ৄেৈো-্ৗৢৣ০-৯৾ਁ-ਃ਼ਾ-ੂੇੈੋ-੍ੑ੦-ੱੵઁ-ઃ઼ા-ૅે-ૉો-્ૢૣ૦-૯ૺ-૿ଁ-ଃ଼ା-ୄେୈୋ-୍ୖୗୢୣ୦-୯ஂா-ூெ-ைொ-்ௗ௦-௯ఀ-ఄా-ౄె-ైొ-్ౕౖౢౣ౦-౯ಁ-ಃ಼ಾ-ೄೆ-ೈೊ-್ೕೖೢೣ೦-೯ഀ-ഃ഻഼ാ-ൄെ-ൈൊ-്ൗൢൣ൦-൯ංඃ්ා-ුූෘ-ෟ෦-෯ෲෳัิ-ฺ็-๎๐-๙ັິ-ູົຼ່-ໍ໐-໙༘༙༠-༩༹༵༷༾༿ཱ-྄྆྇ྍ-ྗྙ-ྼ࿆ါ-ှ၀-၉ၖ-ၙၞ-ၠၢ-ၤၧ-ၭၱ-ၴႂ-ႍႏ-ႝ፝-፟፩-፱ᜒ-᜔ᜲ-᜴ᝒᝓᝲᝳ឴-៓៝០-៩᠋-᠍᠐-᠙ᢩᤠ-ᤫᤰ-᤻᥆-᥏᧐-᧚ᨗ-ᨛᩕ-ᩞ᩠-᩿᩼-᪉᪐-᪙᪰-᪽ᬀ-ᬄ᬴-᭄᭐-᭙᭫-᭳ᮀ-ᮂᮡ-ᮭ᮰-᮹᯦-᯳ᰤ-᰷᱀-᱉᱐-᱙᳐-᳔᳒-᳨᳭ᳲ-᳴᳷-᳹᷀-᷹᷻-᷿‿⁀⁔⃐-⃥⃜⃡-⃰⳯-⵿⳱ⷠ-〪ⷿ-゙゚〯꘠-꘩꙯ꙴ-꙽ꚞꚟ꛰꛱ꠂ꠆ꠋꠣ-ꠧꢀꢁꢴ-ꣅ꣐-꣙꣠-꣱ꣿ-꤉ꤦ-꤭ꥇ-꥓ꦀ-ꦃ꦳-꧀꧐-꧙ꧥ꧰-꧹ꨩ-ꨶꩃꩌꩍ꩐-꩙ꩻ-ꩽꪰꪲ-ꪴꪷꪸꪾ꪿꫁ꫫ-ꫯꫵ꫶ꯣ-ꯪ꯬꯭꯰-꯹ﬞ︀-️︠-︯︳︴﹍-﹏０-９＿",
        u = new RegExp("[" + c + "]"),
        d = new RegExp("[" + c + l + "]");
      c = l = null;
      var f = [
          0,
          11,
          2,
          25,
          2,
          18,
          2,
          1,
          2,
          14,
          3,
          13,
          35,
          122,
          70,
          52,
          268,
          28,
          4,
          48,
          48,
          31,
          14,
          29,
          6,
          37,
          11,
          29,
          3,
          35,
          5,
          7,
          2,
          4,
          43,
          157,
          19,
          35,
          5,
          35,
          5,
          39,
          9,
          51,
          157,
          310,
          10,
          21,
          11,
          7,
          153,
          5,
          3,
          0,
          2,
          43,
          2,
          1,
          4,
          0,
          3,
          22,
          11,
          22,
          10,
          30,
          66,
          18,
          2,
          1,
          11,
          21,
          11,
          25,
          71,
          55,
          7,
          1,
          65,
          0,
          16,
          3,
          2,
          2,
          2,
          28,
          43,
          28,
          4,
          28,
          36,
          7,
          2,
          27,
          28,
          53,
          11,
          21,
          11,
          18,
          14,
          17,
          111,
          72,
          56,
          50,
          14,
          50,
          14,
          35,
          477,
          28,
          11,
          0,
          9,
          21,
          190,
          52,
          76,
          44,
          33,
          24,
          27,
          35,
          30,
          0,
          12,
          34,
          4,
          0,
          13,
          47,
          15,
          3,
          22,
          0,
          2,
          0,
          36,
          17,
          2,
          24,
          85,
          6,
          2,
          0,
          2,
          3,
          2,
          14,
          2,
          9,
          8,
          46,
          39,
          7,
          3,
          1,
          3,
          21,
          2,
          6,
          2,
          1,
          2,
          4,
          4,
          0,
          19,
          0,
          13,
          4,
          159,
          52,
          19,
          3,
          54,
          47,
          21,
          1,
          2,
          0,
          185,
          46,
          42,
          3,
          37,
          47,
          21,
          0,
          60,
          42,
          86,
          26,
          230,
          43,
          117,
          63,
          32,
          0,
          257,
          0,
          11,
          39,
          8,
          0,
          22,
          0,
          12,
          39,
          3,
          3,
          20,
          0,
          35,
          56,
          264,
          8,
          2,
          36,
          18,
          0,
          50,
          29,
          113,
          6,
          2,
          1,
          2,
          37,
          22,
          0,
          26,
          5,
          2,
          1,
          2,
          31,
          15,
          0,
          328,
          18,
          270,
          921,
          103,
          110,
          18,
          195,
          2749,
          1070,
          4050,
          582,
          8634,
          568,
          8,
          30,
          114,
          29,
          19,
          47,
          17,
          3,
          32,
          20,
          6,
          18,
          689,
          63,
          129,
          68,
          12,
          0,
          67,
          12,
          65,
          1,
          31,
          6129,
          15,
          754,
          9486,
          286,
          82,
          395,
          2309,
          106,
          6,
          12,
          4,
          8,
          8,
          9,
          5991,
          84,
          2,
          70,
          2,
          1,
          3,
          0,
          3,
          1,
          3,
          3,
          2,
          11,
          2,
          0,
          2,
          6,
          2,
          64,
          2,
          3,
          3,
          7,
          2,
          6,
          2,
          27,
          2,
          3,
          2,
          4,
          2,
          0,
          4,
          6,
          2,
          339,
          3,
          24,
          2,
          24,
          2,
          30,
          2,
          24,
          2,
          30,
          2,
          24,
          2,
          30,
          2,
          24,
          2,
          30,
          2,
          24,
          2,
          7,
          4149,
          196,
          60,
          67,
          1213,
          3,
          2,
          26,
          2,
          1,
          2,
          0,
          3,
          0,
          2,
          9,
          2,
          3,
          2,
          0,
          2,
          0,
          7,
          0,
          5,
          0,
          2,
          0,
          2,
          0,
          2,
          2,
          2,
          1,
          2,
          0,
          3,
          0,
          2,
          0,
          2,
          0,
          2,
          0,
          2,
          0,
          2,
          1,
          2,
          0,
          3,
          3,
          2,
          6,
          2,
          3,
          2,
          3,
          2,
          0,
          2,
          9,
          2,
          16,
          6,
          2,
          2,
          4,
          2,
          16,
          4421,
          42710,
          42,
          4148,
          12,
          221,
          3,
          5761,
          15,
          7472,
          3104,
          541
        ],
        m = [
          509,
          0,
          227,
          0,
          150,
          4,
          294,
          9,
          1368,
          2,
          2,
          1,
          6,
          3,
          41,
          2,
          5,
          0,
          166,
          1,
          574,
          3,
          9,
          9,
          525,
          10,
          176,
          2,
          54,
          14,
          32,
          9,
          16,
          3,
          46,
          10,
          54,
          9,
          7,
          2,
          37,
          13,
          2,
          9,
          6,
          1,
          45,
          0,
          13,
          2,
          49,
          13,
          9,
          3,
          4,
          9,
          83,
          11,
          7,
          0,
          161,
          11,
          6,
          9,
          7,
          3,
          56,
          1,
          2,
          6,
          3,
          1,
          3,
          2,
          10,
          0,
          11,
          1,
          3,
          6,
          4,
          4,
          193,
          17,
          10,
          9,
          5,
          0,
          82,
          19,
          13,
          9,
          214,
          6,
          3,
          8,
          28,
          1,
          83,
          16,
          16,
          9,
          82,
          12,
          9,
          9,
          84,
          14,
          5,
          9,
          243,
          14,
          166,
          9,
          280,
          9,
          41,
          6,
          2,
          3,
          9,
          0,
          10,
          10,
          47,
          15,
          406,
          7,
          2,
          7,
          17,
          9,
          57,
          21,
          2,
          13,
          123,
          5,
          4,
          0,
          2,
          1,
          2,
          6,
          2,
          0,
          9,
          9,
          49,
          4,
          2,
          1,
          2,
          4,
          9,
          9,
          330,
          3,
          19306,
          9,
          135,
          4,
          60,
          6,
          26,
          9,
          1016,
          45,
          17,
          3,
          19723,
          1,
          5319,
          4,
          4,
          5,
          9,
          7,
          3,
          6,
          31,
          3,
          149,
          2,
          1418,
          49,
          513,
          54,
          5,
          49,
          9,
          0,
          15,
          0,
          23,
          4,
          2,
          14,
          1361,
          6,
          2,
          16,
          3,
          6,
          2,
          1,
          2,
          4,
          2214,
          6,
          110,
          6,
          6,
          9,
          792487,
          239
        ];
      function y(t, e) {
        for (var i = 65536, s = 0; s < e.length; s += 2) {
          if ((i += e[s]) > t) return !1;
          if ((i += e[s + 1]) >= t) return !0;
        }
      }
      function g(t, e) {
        return t < 65
          ? 36 === t
          : t < 91 ||
              (t < 97
                ? 95 === t
                : t < 123 ||
                  (t <= 65535
                    ? t >= 170 && u.test(String.fromCharCode(t))
                    : !1 !== e && y(t, f)));
      }
      function v(t, e) {
        return t < 48
          ? 36 === t
          : t < 58 ||
              (!(t < 65) &&
                (t < 91 ||
                  (t < 97
                    ? 95 === t
                    : t < 123 ||
                      (t <= 65535
                        ? t >= 170 && d.test(String.fromCharCode(t))
                        : !1 !== e && (y(t, f) || y(t, m))))));
      }
      var x = function(t, e) {
        void 0 === e && (e = {}),
          (this.label = t),
          (this.keyword = e.keyword),
          (this.beforeExpr = !!e.beforeExpr),
          (this.startsExpr = !!e.startsExpr),
          (this.isLoop = !!e.isLoop),
          (this.isAssign = !!e.isAssign),
          (this.prefix = !!e.prefix),
          (this.postfix = !!e.postfix),
          (this.binop = e.binop || null),
          (this.updateContext = null);
      };
      function b(t, e) {
        return new x(t, { beforeExpr: !0, binop: e });
      }
      var _ = { beforeExpr: !0 },
        k = { startsExpr: !0 },
        S = {};
      function w(t, e) {
        return void 0 === e && (e = {}), (e.keyword = t), (S[t] = new x(t, e));
      }
      var E = {
          num: new x("num", k),
          regexp: new x("regexp", k),
          string: new x("string", k),
          name: new x("name", k),
          eof: new x("eof"),
          bracketL: new x("[", { beforeExpr: !0, startsExpr: !0 }),
          bracketR: new x("]"),
          braceL: new x("{", { beforeExpr: !0, startsExpr: !0 }),
          braceR: new x("}"),
          parenL: new x("(", { beforeExpr: !0, startsExpr: !0 }),
          parenR: new x(")"),
          comma: new x(",", _),
          semi: new x(";", _),
          colon: new x(":", _),
          dot: new x("."),
          question: new x("?", _),
          arrow: new x("=>", _),
          template: new x("template"),
          invalidTemplate: new x("invalidTemplate"),
          ellipsis: new x("...", _),
          backQuote: new x("`", k),
          dollarBraceL: new x("${", { beforeExpr: !0, startsExpr: !0 }),
          eq: new x("=", { beforeExpr: !0, isAssign: !0 }),
          assign: new x("_=", { beforeExpr: !0, isAssign: !0 }),
          incDec: new x("++/--", { prefix: !0, postfix: !0, startsExpr: !0 }),
          prefix: new x("!/~", { beforeExpr: !0, prefix: !0, startsExpr: !0 }),
          logicalOR: b("||", 1),
          logicalAND: b("&&", 2),
          bitwiseOR: b("|", 3),
          bitwiseXOR: b("^", 4),
          bitwiseAND: b("&", 5),
          equality: b("==/!=/===/!==", 6),
          relational: b("</>/<=/>=", 7),
          bitShift: b("<</>>/>>>", 8),
          plusMin: new x("+/-", {
            beforeExpr: !0,
            binop: 9,
            prefix: !0,
            startsExpr: !0
          }),
          modulo: b("%", 10),
          star: b("*", 10),
          slash: b("/", 10),
          starstar: new x("**", { beforeExpr: !0 }),
          _break: w("break"),
          _case: w("case", _),
          _catch: w("catch"),
          _continue: w("continue"),
          _debugger: w("debugger"),
          _default: w("default", _),
          _do: w("do", { isLoop: !0, beforeExpr: !0 }),
          _else: w("else", _),
          _finally: w("finally"),
          _for: w("for", { isLoop: !0 }),
          _function: w("function", k),
          _if: w("if"),
          _return: w("return", _),
          _switch: w("switch"),
          _throw: w("throw", _),
          _try: w("try"),
          _var: w("var"),
          _const: w("const"),
          _while: w("while", { isLoop: !0 }),
          _with: w("with"),
          _new: w("new", { beforeExpr: !0, startsExpr: !0 }),
          _this: w("this", k),
          _super: w("super", k),
          _class: w("class", k),
          _extends: w("extends", _),
          _export: w("export"),
          _import: w("import"),
          _null: w("null", k),
          _true: w("true", k),
          _false: w("false", k),
          _in: w("in", { beforeExpr: !0, binop: 7 }),
          _instanceof: w("instanceof", { beforeExpr: !0, binop: 7 }),
          _typeof: w("typeof", { beforeExpr: !0, prefix: !0, startsExpr: !0 }),
          _void: w("void", { beforeExpr: !0, prefix: !0, startsExpr: !0 }),
          _delete: w("delete", { beforeExpr: !0, prefix: !0, startsExpr: !0 })
        },
        A = /\r\n?|\n|\u2028|\u2029/,
        C = new RegExp(A.source, "g");
      function I(t, e) {
        return 10 === t || 13 === t || (!e && (8232 === t || 8233 === t));
      }
      var L = /[\u1680\u180e\u2000-\u200a\u202f\u205f\u3000\ufeff]/,
        P = /(?:\s|\/\/.*|\/\*[^]*?\*\/)*/g,
        N = Object.prototype,
        T = N.hasOwnProperty,
        R = N.toString;
      function O(t, e) {
        return T.call(t, e);
      }
      var j =
          Array.isArray ||
          function(t) {
            return "[object Array]" === R.call(t);
          },
        V = function(t, e) {
          (this.line = t), (this.column = e);
        };
      V.prototype.offset = function(t) {
        return new V(this.line, this.column + t);
      };
      var D = function(t, e, i) {
        (this.start = e),
          (this.end = i),
          null !== t.sourceFile && (this.source = t.sourceFile);
      };
      function F(t, e) {
        for (var i = 1, s = 0; ; ) {
          C.lastIndex = s;
          var r = C.exec(t);
          if (!(r && r.index < e)) return new V(i, e - s);
          ++i, (s = r.index + r[0].length);
        }
      }
      var B = {
        ecmaVersion: 9,
        sourceType: "script",
        onInsertedSemicolon: null,
        onTrailingComma: null,
        allowReserved: null,
        allowReturnOutsideFunction: !1,
        allowImportExportEverywhere: !1,
        allowAwaitOutsideFunction: !1,
        allowHashBang: !1,
        locations: !1,
        onToken: null,
        onComment: null,
        ranges: !1,
        program: null,
        sourceFile: null,
        directSourceFile: null,
        preserveParens: !1
      };
      function M(t) {
        var e = {};
        for (var i in B) e[i] = t && O(t, i) ? t[i] : B[i];
        if (
          (e.ecmaVersion >= 2015 && (e.ecmaVersion -= 2009),
          null == e.allowReserved && (e.allowReserved = e.ecmaVersion < 5),
          j(e.onToken))
        ) {
          var s = e.onToken;
          e.onToken = function(t) {
            return s.push(t);
          };
        }
        return (
          j(e.onComment) &&
            (e.onComment = (function(t, e) {
              return function(i, s, r, n, a, o) {
                var p = {
                  type: i ? "Block" : "Line",
                  value: s,
                  start: r,
                  end: n
                };
                t.locations && (p.loc = new D(this, a, o)),
                  t.ranges && (p.range = [r, n]),
                  e.push(p);
              };
            })(e, e.onComment)),
          e
        );
      }
      function U(t, e) {
        return 2 | (t ? 4 : 0) | (e ? 8 : 0);
      }
      function q(t) {
        return new RegExp("^(?:" + t.replace(/ /g, "|") + ")$");
      }
      var X = function(t, e, i) {
          (this.options = t = M(t)),
            (this.sourceFile = t.sourceFile),
            (this.keywords = q(p[t.ecmaVersion >= 6 ? 6 : 5]));
          var s = "";
          if (!t.allowReserved) {
            for (var r = t.ecmaVersion; !(s = a[r]); r--);
            "module" === t.sourceType && (s += " await");
          }
          this.reservedWords = q(s);
          var n = (s ? s + " " : "") + a.strict;
          (this.reservedWordsStrict = q(n)),
            (this.reservedWordsStrictBind = q(n + " " + a.strictBind)),
            (this.input = String(e)),
            (this.containsEsc = !1),
            i
              ? ((this.pos = i),
                (this.lineStart = this.input.lastIndexOf("\n", i - 1) + 1),
                (this.curLine = this.input
                  .slice(0, this.lineStart)
                  .split(A).length))
              : ((this.pos = this.lineStart = 0), (this.curLine = 1)),
            (this.type = E.eof),
            (this.value = null),
            (this.start = this.end = this.pos),
            (this.startLoc = this.endLoc = this.curPosition()),
            (this.lastTokEndLoc = this.lastTokStartLoc = null),
            (this.lastTokStart = this.lastTokEnd = this.pos),
            (this.context = this.initialContext()),
            (this.exprAllowed = !0),
            (this.inModule = "module" === t.sourceType),
            (this.strict = this.inModule || this.strictDirective(this.pos)),
            (this.potentialArrowAt = -1),
            (this.yieldPos = this.awaitPos = 0),
            (this.labels = []),
            0 === this.pos &&
              t.allowHashBang &&
              "#!" === this.input.slice(0, 2) &&
              this.skipLineComment(2),
            (this.scopeStack = []),
            this.enterScope(1),
            (this.regexpState = null);
        },
        J = {
          inFunction: { configurable: !0 },
          inGenerator: { configurable: !0 },
          inAsync: { configurable: !0 }
        };
      (X.prototype.parse = function() {
        var t = this.options.program || this.startNode();
        return this.nextToken(), this.parseTopLevel(t);
      }),
        (J.inFunction.get = function() {
          return (2 & this.currentVarScope().flags) > 0;
        }),
        (J.inGenerator.get = function() {
          return (8 & this.currentVarScope().flags) > 0;
        }),
        (J.inAsync.get = function() {
          return (4 & this.currentVarScope().flags) > 0;
        }),
        (X.extend = function() {
          for (var t = [], e = arguments.length; e--; ) t[e] = arguments[e];
          for (var i = this, s = 0; s < t.length; s++) i = t[s](i);
          return i;
        }),
        (X.parse = function(t, e) {
          return new this(e, t).parse();
        }),
        (X.parseExpressionAt = function(t, e, i) {
          var s = new this(i, t, e);
          return s.nextToken(), s.parseExpression();
        }),
        (X.tokenizer = function(t, e) {
          return new this(e, t);
        }),
        Object.defineProperties(X.prototype, J);
      var W = X.prototype,
        H = /^(?:'((?:\\.|[^'])*?)'|"((?:\\.|[^"])*?)"|;)/;
      function z() {
        this.shorthandAssign = this.trailingComma = this.parenthesizedAssign = this.parenthesizedBind = this.doubleProto = -1;
      }
      (W.strictDirective = function(t) {
        for (;;) {
          (P.lastIndex = t), (t += P.exec(this.input)[0].length);
          var e = H.exec(this.input.slice(t));
          if (!e) return !1;
          if ("use strict" === (e[1] || e[2])) return !0;
          t += e[0].length;
        }
      }),
        (W.eat = function(t) {
          return this.type === t && (this.next(), !0);
        }),
        (W.isContextual = function(t) {
          return this.type === E.name && this.value === t && !this.containsEsc;
        }),
        (W.eatContextual = function(t) {
          return !!this.isContextual(t) && (this.next(), !0);
        }),
        (W.expectContextual = function(t) {
          this.eatContextual(t) || this.unexpected();
        }),
        (W.canInsertSemicolon = function() {
          return (
            this.type === E.eof ||
            this.type === E.braceR ||
            A.test(this.input.slice(this.lastTokEnd, this.start))
          );
        }),
        (W.insertSemicolon = function() {
          if (this.canInsertSemicolon())
            return (
              this.options.onInsertedSemicolon &&
                this.options.onInsertedSemicolon(
                  this.lastTokEnd,
                  this.lastTokEndLoc
                ),
              !0
            );
        }),
        (W.semicolon = function() {
          this.eat(E.semi) || this.insertSemicolon() || this.unexpected();
        }),
        (W.afterTrailingComma = function(t, e) {
          if (this.type === t)
            return (
              this.options.onTrailingComma &&
                this.options.onTrailingComma(
                  this.lastTokStart,
                  this.lastTokStartLoc
                ),
              e || this.next(),
              !0
            );
        }),
        (W.expect = function(t) {
          this.eat(t) || this.unexpected();
        }),
        (W.unexpected = function(t) {
          this.raise(null != t ? t : this.start, "Unexpected token");
        }),
        (W.checkPatternErrors = function(t, e) {
          if (t) {
            t.trailingComma > -1 &&
              this.raiseRecoverable(
                t.trailingComma,
                "Comma is not permitted after the rest element"
              );
            var i = e ? t.parenthesizedAssign : t.parenthesizedBind;
            i > -1 && this.raiseRecoverable(i, "Parenthesized pattern");
          }
        }),
        (W.checkExpressionErrors = function(t, e) {
          if (!t) return !1;
          var i = t.shorthandAssign,
            s = t.doubleProto;
          if (!e) return i >= 0 || s >= 0;
          i >= 0 &&
            this.raise(
              i,
              "Shorthand property assignments are valid only in destructuring patterns"
            ),
            s >= 0 &&
              this.raiseRecoverable(s, "Redefinition of __proto__ property");
        }),
        (W.checkYieldAwaitInDefaultParams = function() {
          this.yieldPos &&
            (!this.awaitPos || this.yieldPos < this.awaitPos) &&
            this.raise(
              this.yieldPos,
              "Yield expression cannot be a default value"
            ),
            this.awaitPos &&
              this.raise(
                this.awaitPos,
                "Await expression cannot be a default value"
              );
        }),
        (W.isSimpleAssignTarget = function(t) {
          return "ParenthesizedExpression" === t.type
            ? this.isSimpleAssignTarget(t.expression)
            : "Identifier" === t.type || "MemberExpression" === t.type;
        });
      var G = X.prototype;
      G.parseTopLevel = function(t) {
        var e = {};
        for (t.body || (t.body = []); this.type !== E.eof; ) {
          var i = this.parseStatement(null, !0, e);
          t.body.push(i);
        }
        return (
          this.adaptDirectivePrologue(t.body),
          this.next(),
          this.options.ecmaVersion >= 6 &&
            (t.sourceType = this.options.sourceType),
          this.finishNode(t, "Program")
        );
      };
      var Q = { kind: "loop" },
        K = { kind: "switch" };
      (G.isLet = function() {
        if (this.options.ecmaVersion < 6 || !this.isContextual("let"))
          return !1;
        P.lastIndex = this.pos;
        var t = P.exec(this.input),
          e = this.pos + t[0].length,
          i = this.input.charCodeAt(e);
        if (91 === i || 123 === i) return !0;
        if (g(i, !0)) {
          for (var s = e + 1; v(this.input.charCodeAt(s), !0); ) ++s;
          var r = this.input.slice(e, s);
          if (!h.test(r)) return !0;
        }
        return !1;
      }),
        (G.isAsyncFunction = function() {
          if (this.options.ecmaVersion < 8 || !this.isContextual("async"))
            return !1;
          P.lastIndex = this.pos;
          var t = P.exec(this.input),
            e = this.pos + t[0].length;
          return !(
            A.test(this.input.slice(this.pos, e)) ||
            "function" !== this.input.slice(e, e + 8) ||
            (e + 8 !== this.input.length && v(this.input.charAt(e + 8)))
          );
        }),
        (G.parseStatement = function(t, e, i) {
          var s,
            r = this.type,
            n = this.startNode();
          switch ((this.isLet() && ((r = E._var), (s = "let")), r)) {
            case E._break:
            case E._continue:
              return this.parseBreakContinueStatement(n, r.keyword);
            case E._debugger:
              return this.parseDebuggerStatement(n);
            case E._do:
              return this.parseDoStatement(n);
            case E._for:
              return this.parseForStatement(n);
            case E._function:
              return (
                t &&
                  (this.strict || "if" !== t) &&
                  this.options.ecmaVersion >= 6 &&
                  this.unexpected(),
                this.parseFunctionStatement(n, !1, !t)
              );
            case E._class:
              return t && this.unexpected(), this.parseClass(n, !0);
            case E._if:
              return this.parseIfStatement(n);
            case E._return:
              return this.parseReturnStatement(n);
            case E._switch:
              return this.parseSwitchStatement(n);
            case E._throw:
              return this.parseThrowStatement(n);
            case E._try:
              return this.parseTryStatement(n);
            case E._const:
            case E._var:
              return (
                (s = s || this.value),
                t && "var" !== s && this.unexpected(),
                this.parseVarStatement(n, s)
              );
            case E._while:
              return this.parseWhileStatement(n);
            case E._with:
              return this.parseWithStatement(n);
            case E.braceL:
              return this.parseBlock(!0, n);
            case E.semi:
              return this.parseEmptyStatement(n);
            case E._export:
            case E._import:
              return (
                this.options.allowImportExportEverywhere ||
                  (e ||
                    this.raise(
                      this.start,
                      "'import' and 'export' may only appear at the top level"
                    ),
                  this.inModule ||
                    this.raise(
                      this.start,
                      "'import' and 'export' may appear only with 'sourceType: module'"
                    )),
                r === E._import ? this.parseImport(n) : this.parseExport(n, i)
              );
            default:
              if (this.isAsyncFunction())
                return (
                  t && this.unexpected(),
                  this.next(),
                  this.parseFunctionStatement(n, !0, !t)
                );
              var a = this.value,
                o = this.parseExpression();
              return r === E.name &&
                "Identifier" === o.type &&
                this.eat(E.colon)
                ? this.parseLabeledStatement(n, a, o, t)
                : this.parseExpressionStatement(n, o);
          }
        }),
        (G.parseBreakContinueStatement = function(t, e) {
          var i = "break" === e;
          this.next(),
            this.eat(E.semi) || this.insertSemicolon()
              ? (t.label = null)
              : this.type !== E.name
              ? this.unexpected()
              : ((t.label = this.parseIdent()), this.semicolon());
          for (var s = 0; s < this.labels.length; ++s) {
            var r = this.labels[s];
            if (null == t.label || r.name === t.label.name) {
              if (null != r.kind && (i || "loop" === r.kind)) break;
              if (t.label && i) break;
            }
          }
          return (
            s === this.labels.length && this.raise(t.start, "Unsyntactic " + e),
            this.finishNode(t, i ? "BreakStatement" : "ContinueStatement")
          );
        }),
        (G.parseDebuggerStatement = function(t) {
          return (
            this.next(),
            this.semicolon(),
            this.finishNode(t, "DebuggerStatement")
          );
        }),
        (G.parseDoStatement = function(t) {
          return (
            this.next(),
            this.labels.push(Q),
            (t.body = this.parseStatement("do")),
            this.labels.pop(),
            this.expect(E._while),
            (t.test = this.parseParenExpression()),
            this.options.ecmaVersion >= 6 ? this.eat(E.semi) : this.semicolon(),
            this.finishNode(t, "DoWhileStatement")
          );
        }),
        (G.parseForStatement = function(t) {
          this.next();
          var e =
            this.options.ecmaVersion >= 9 &&
            (this.inAsync ||
              (!this.inFunction && this.options.allowAwaitOutsideFunction)) &&
            this.eatContextual("await")
              ? this.lastTokStart
              : -1;
          if (
            (this.labels.push(Q),
            this.enterScope(0),
            this.expect(E.parenL),
            this.type === E.semi)
          )
            return e > -1 && this.unexpected(e), this.parseFor(t, null);
          var i = this.isLet();
          if (this.type === E._var || this.type === E._const || i) {
            var s = this.startNode(),
              r = i ? "let" : this.value;
            return (
              this.next(),
              this.parseVar(s, !0, r),
              this.finishNode(s, "VariableDeclaration"),
              !(
                this.type === E._in ||
                (this.options.ecmaVersion >= 6 && this.isContextual("of"))
              ) ||
              1 !== s.declarations.length ||
              ("var" !== r && s.declarations[0].init)
                ? (e > -1 && this.unexpected(e), this.parseFor(t, s))
                : (this.options.ecmaVersion >= 9 &&
                    (this.type === E._in
                      ? e > -1 && this.unexpected(e)
                      : (t.await = e > -1)),
                  this.parseForIn(t, s))
            );
          }
          var n = new z(),
            a = this.parseExpression(!0, n);
          return this.type === E._in ||
            (this.options.ecmaVersion >= 6 && this.isContextual("of"))
            ? (this.options.ecmaVersion >= 9 &&
                (this.type === E._in
                  ? e > -1 && this.unexpected(e)
                  : (t.await = e > -1)),
              this.toAssignable(a, !1, n),
              this.checkLVal(a),
              this.parseForIn(t, a))
            : (this.checkExpressionErrors(n, !0),
              e > -1 && this.unexpected(e),
              this.parseFor(t, a));
        }),
        (G.parseFunctionStatement = function(t, e, i) {
          return this.next(), this.parseFunction(t, Y | (i ? 0 : Z), !1, e);
        }),
        (G.parseIfStatement = function(t) {
          return (
            this.next(),
            (t.test = this.parseParenExpression()),
            (t.consequent = this.parseStatement("if")),
            (t.alternate = this.eat(E._else)
              ? this.parseStatement("if")
              : null),
            this.finishNode(t, "IfStatement")
          );
        }),
        (G.parseReturnStatement = function(t) {
          return (
            this.inFunction ||
              this.options.allowReturnOutsideFunction ||
              this.raise(this.start, "'return' outside of function"),
            this.next(),
            this.eat(E.semi) || this.insertSemicolon()
              ? (t.argument = null)
              : ((t.argument = this.parseExpression()), this.semicolon()),
            this.finishNode(t, "ReturnStatement")
          );
        }),
        (G.parseSwitchStatement = function(t) {
          var e;
          this.next(),
            (t.discriminant = this.parseParenExpression()),
            (t.cases = []),
            this.expect(E.braceL),
            this.labels.push(K),
            this.enterScope(0);
          for (var i = !1; this.type !== E.braceR; )
            if (this.type === E._case || this.type === E._default) {
              var s = this.type === E._case;
              e && this.finishNode(e, "SwitchCase"),
                t.cases.push((e = this.startNode())),
                (e.consequent = []),
                this.next(),
                s
                  ? (e.test = this.parseExpression())
                  : (i &&
                      this.raiseRecoverable(
                        this.lastTokStart,
                        "Multiple default clauses"
                      ),
                    (i = !0),
                    (e.test = null)),
                this.expect(E.colon);
            } else
              e || this.unexpected(),
                e.consequent.push(this.parseStatement(null));
          return (
            this.exitScope(),
            e && this.finishNode(e, "SwitchCase"),
            this.next(),
            this.labels.pop(),
            this.finishNode(t, "SwitchStatement")
          );
        }),
        (G.parseThrowStatement = function(t) {
          return (
            this.next(),
            A.test(this.input.slice(this.lastTokEnd, this.start)) &&
              this.raise(this.lastTokEnd, "Illegal newline after throw"),
            (t.argument = this.parseExpression()),
            this.semicolon(),
            this.finishNode(t, "ThrowStatement")
          );
        });
      var $ = [];
      (G.parseTryStatement = function(t) {
        if (
          (this.next(),
          (t.block = this.parseBlock()),
          (t.handler = null),
          this.type === E._catch)
        ) {
          var e = this.startNode();
          if ((this.next(), this.eat(E.parenL))) {
            e.param = this.parseBindingAtom();
            var i = "Identifier" === e.param.type;
            this.enterScope(i ? 32 : 0),
              this.checkLVal(e.param, i ? 4 : 2),
              this.expect(E.parenR);
          } else
            this.options.ecmaVersion < 10 && this.unexpected(),
              (e.param = null),
              this.enterScope(0);
          (e.body = this.parseBlock(!1)),
            this.exitScope(),
            (t.handler = this.finishNode(e, "CatchClause"));
        }
        return (
          (t.finalizer = this.eat(E._finally) ? this.parseBlock() : null),
          t.handler ||
            t.finalizer ||
            this.raise(t.start, "Missing catch or finally clause"),
          this.finishNode(t, "TryStatement")
        );
      }),
        (G.parseVarStatement = function(t, e) {
          return (
            this.next(),
            this.parseVar(t, !1, e),
            this.semicolon(),
            this.finishNode(t, "VariableDeclaration")
          );
        }),
        (G.parseWhileStatement = function(t) {
          return (
            this.next(),
            (t.test = this.parseParenExpression()),
            this.labels.push(Q),
            (t.body = this.parseStatement("while")),
            this.labels.pop(),
            this.finishNode(t, "WhileStatement")
          );
        }),
        (G.parseWithStatement = function(t) {
          return (
            this.strict && this.raise(this.start, "'with' in strict mode"),
            this.next(),
            (t.object = this.parseParenExpression()),
            (t.body = this.parseStatement("with")),
            this.finishNode(t, "WithStatement")
          );
        }),
        (G.parseEmptyStatement = function(t) {
          return this.next(), this.finishNode(t, "EmptyStatement");
        }),
        (G.parseLabeledStatement = function(t, e, i, s) {
          for (var r = 0, n = this.labels; r < n.length; r += 1) {
            n[r].name === e &&
              this.raise(i.start, "Label '" + e + "' is already declared");
          }
          for (
            var a = this.type.isLoop
                ? "loop"
                : this.type === E._switch
                ? "switch"
                : null,
              o = this.labels.length - 1;
            o >= 0;
            o--
          ) {
            var p = this.labels[o];
            if (p.statementStart !== t.start) break;
            (p.statementStart = this.start), (p.kind = a);
          }
          return (
            this.labels.push({ name: e, kind: a, statementStart: this.start }),
            (t.body = this.parseStatement(s)),
            ("ClassDeclaration" === t.body.type ||
              ("VariableDeclaration" === t.body.type &&
                "var" !== t.body.kind) ||
              ("FunctionDeclaration" === t.body.type &&
                (this.strict || t.body.generator || t.body.async))) &&
              this.raiseRecoverable(
                t.body.start,
                "Invalid labeled declaration"
              ),
            this.labels.pop(),
            (t.label = i),
            this.finishNode(t, "LabeledStatement")
          );
        }),
        (G.parseExpressionStatement = function(t, e) {
          return (
            (t.expression = e),
            this.semicolon(),
            this.finishNode(t, "ExpressionStatement")
          );
        }),
        (G.parseBlock = function(t, e) {
          for (
            void 0 === t && (t = !0),
              void 0 === e && (e = this.startNode()),
              e.body = [],
              this.expect(E.braceL),
              t && this.enterScope(0);
            !this.eat(E.braceR);

          ) {
            var i = this.parseStatement(null);
            e.body.push(i);
          }
          return t && this.exitScope(), this.finishNode(e, "BlockStatement");
        }),
        (G.parseFor = function(t, e) {
          return (
            (t.init = e),
            this.expect(E.semi),
            (t.test = this.type === E.semi ? null : this.parseExpression()),
            this.expect(E.semi),
            (t.update = this.type === E.parenR ? null : this.parseExpression()),
            this.expect(E.parenR),
            this.exitScope(),
            (t.body = this.parseStatement("for")),
            this.labels.pop(),
            this.finishNode(t, "ForStatement")
          );
        }),
        (G.parseForIn = function(t, e) {
          var i = this.type === E._in ? "ForInStatement" : "ForOfStatement";
          return (
            this.next(),
            "ForInStatement" === i &&
              ("AssignmentPattern" === e.type ||
                ("VariableDeclaration" === e.type &&
                  null != e.declarations[0].init &&
                  (this.strict ||
                    "Identifier" !== e.declarations[0].id.type))) &&
              this.raise(e.start, "Invalid assignment in for-in loop head"),
            (t.left = e),
            (t.right =
              "ForInStatement" === i
                ? this.parseExpression()
                : this.parseMaybeAssign()),
            this.expect(E.parenR),
            this.exitScope(),
            (t.body = this.parseStatement("for")),
            this.labels.pop(),
            this.finishNode(t, i)
          );
        }),
        (G.parseVar = function(t, e, i) {
          for (t.declarations = [], t.kind = i; ; ) {
            var s = this.startNode();
            if (
              (this.parseVarId(s, i),
              this.eat(E.eq)
                ? (s.init = this.parseMaybeAssign(e))
                : "const" !== i ||
                  this.type === E._in ||
                  (this.options.ecmaVersion >= 6 && this.isContextual("of"))
                ? "Identifier" === s.id.type ||
                  (e && (this.type === E._in || this.isContextual("of")))
                  ? (s.init = null)
                  : this.raise(
                      this.lastTokEnd,
                      "Complex binding patterns require an initialization value"
                    )
                : this.unexpected(),
              t.declarations.push(this.finishNode(s, "VariableDeclarator")),
              !this.eat(E.comma))
            )
              break;
          }
          return t;
        }),
        (G.parseVarId = function(t, e) {
          (t.id = this.parseBindingAtom(e)),
            this.checkLVal(t.id, "var" === e ? 1 : 2, !1);
        });
      var Y = 1,
        Z = 2;
      (G.parseFunction = function(t, e, i, s) {
        this.initFunction(t),
          (this.options.ecmaVersion >= 9 ||
            (this.options.ecmaVersion >= 6 && !s)) &&
            (t.generator = this.eat(E.star)),
          this.options.ecmaVersion >= 8 && (t.async = !!s),
          e & Y &&
            ((t.id = 4 & e && this.type !== E.name ? null : this.parseIdent()),
            !t.id ||
              e & Z ||
              this.checkLVal(t.id, this.inModule && !this.inFunction ? 2 : 3));
        var r = this.yieldPos,
          n = this.awaitPos;
        return (
          (this.yieldPos = 0),
          (this.awaitPos = 0),
          this.enterScope(U(t.async, t.generator)),
          e & Y || (t.id = this.type === E.name ? this.parseIdent() : null),
          this.parseFunctionParams(t),
          this.parseFunctionBody(t, i),
          (this.yieldPos = r),
          (this.awaitPos = n),
          this.finishNode(
            t,
            e & Y ? "FunctionDeclaration" : "FunctionExpression"
          )
        );
      }),
        (G.parseFunctionParams = function(t) {
          this.expect(E.parenL),
            (t.params = this.parseBindingList(
              E.parenR,
              !1,
              this.options.ecmaVersion >= 8
            )),
            this.checkYieldAwaitInDefaultParams();
        }),
        (G.parseClass = function(t, e) {
          this.next(), this.parseClassId(t, e), this.parseClassSuper(t);
          var i = this.startNode(),
            s = !1;
          for (i.body = [], this.expect(E.braceL); !this.eat(E.braceR); ) {
            var r = this.parseClassElement();
            r &&
              (i.body.push(r),
              "MethodDefinition" === r.type &&
                "constructor" === r.kind &&
                (s &&
                  this.raise(
                    r.start,
                    "Duplicate constructor in the same class"
                  ),
                (s = !0)));
          }
          return (
            (t.body = this.finishNode(i, "ClassBody")),
            this.finishNode(t, e ? "ClassDeclaration" : "ClassExpression")
          );
        }),
        (G.parseClassElement = function() {
          var t = this;
          if (this.eat(E.semi)) return null;
          var e = this.startNode(),
            i = function(i, s) {
              void 0 === s && (s = !1);
              var r = t.start,
                n = t.startLoc;
              return (
                !!t.eatContextual(i) &&
                (!(t.type === E.parenL || (s && t.canInsertSemicolon())) ||
                  (e.key && t.unexpected(),
                  (e.computed = !1),
                  (e.key = t.startNodeAt(r, n)),
                  (e.key.name = i),
                  t.finishNode(e.key, "Identifier"),
                  !1))
              );
            };
          (e.kind = "method"), (e.static = i("static"));
          var s = this.eat(E.star),
            r = !1;
          s ||
            (this.options.ecmaVersion >= 8 && i("async", !0)
              ? ((r = !0),
                (s = this.options.ecmaVersion >= 9 && this.eat(E.star)))
              : i("get")
              ? (e.kind = "get")
              : i("set") && (e.kind = "set")),
            e.key || this.parsePropertyName(e);
          var n = e.key;
          return (
            e.computed ||
            e.static ||
            !(
              ("Identifier" === n.type && "constructor" === n.name) ||
              ("Literal" === n.type && "constructor" === n.value)
            )
              ? e.static &&
                "Identifier" === n.type &&
                "prototype" === n.name &&
                this.raise(
                  n.start,
                  "Classes may not have a static property named prototype"
                )
              : ("method" !== e.kind &&
                  this.raise(
                    n.start,
                    "Constructor can't have get/set modifier"
                  ),
                s && this.raise(n.start, "Constructor can't be a generator"),
                r &&
                  this.raise(n.start, "Constructor can't be an async method"),
                (e.kind = "constructor")),
            this.parseClassMethod(e, s, r),
            "get" === e.kind &&
              0 !== e.value.params.length &&
              this.raiseRecoverable(
                e.value.start,
                "getter should have no params"
              ),
            "set" === e.kind &&
              1 !== e.value.params.length &&
              this.raiseRecoverable(
                e.value.start,
                "setter should have exactly one param"
              ),
            "set" === e.kind &&
              "RestElement" === e.value.params[0].type &&
              this.raiseRecoverable(
                e.value.params[0].start,
                "Setter cannot use rest params"
              ),
            e
          );
        }),
        (G.parseClassMethod = function(t, e, i) {
          return (
            (t.value = this.parseMethod(e, i)),
            this.finishNode(t, "MethodDefinition")
          );
        }),
        (G.parseClassId = function(t, e) {
          t.id =
            this.type === E.name
              ? this.parseIdent()
              : !0 === e
              ? this.unexpected()
              : null;
        }),
        (G.parseClassSuper = function(t) {
          t.superClass = this.eat(E._extends)
            ? this.parseExprSubscripts()
            : null;
        }),
        (G.parseExport = function(t, e) {
          if ((this.next(), this.eat(E.star)))
            return (
              this.expectContextual("from"),
              this.type !== E.string && this.unexpected(),
              (t.source = this.parseExprAtom()),
              this.semicolon(),
              this.finishNode(t, "ExportAllDeclaration")
            );
          if (this.eat(E._default)) {
            var i;
            if (
              (this.checkExport(e, "default", this.lastTokStart),
              this.type === E._function || (i = this.isAsyncFunction()))
            ) {
              var s = this.startNode();
              this.next(),
                i && this.next(),
                (t.declaration = this.parseFunction(s, 4 | Y, !1, i, !0));
            } else if (this.type === E._class) {
              var r = this.startNode();
              t.declaration = this.parseClass(r, "nullableID");
            } else (t.declaration = this.parseMaybeAssign()), this.semicolon();
            return this.finishNode(t, "ExportDefaultDeclaration");
          }
          if (this.shouldParseExportStatement())
            (t.declaration = this.parseStatement(null)),
              "VariableDeclaration" === t.declaration.type
                ? this.checkVariableExport(e, t.declaration.declarations)
                : this.checkExport(
                    e,
                    t.declaration.id.name,
                    t.declaration.id.start
                  ),
              (t.specifiers = []),
              (t.source = null);
          else {
            if (
              ((t.declaration = null),
              (t.specifiers = this.parseExportSpecifiers(e)),
              this.eatContextual("from"))
            )
              this.type !== E.string && this.unexpected(),
                (t.source = this.parseExprAtom());
            else {
              for (var n = 0, a = t.specifiers; n < a.length; n += 1) {
                var o = a[n];
                this.checkUnreserved(o.local);
              }
              t.source = null;
            }
            this.semicolon();
          }
          return this.finishNode(t, "ExportNamedDeclaration");
        }),
        (G.checkExport = function(t, e, i) {
          t &&
            (O(t, e) &&
              this.raiseRecoverable(i, "Duplicate export '" + e + "'"),
            (t[e] = !0));
        }),
        (G.checkPatternExport = function(t, e) {
          var i = e.type;
          if ("Identifier" === i) this.checkExport(t, e.name, e.start);
          else if ("ObjectPattern" === i)
            for (var s = 0, r = e.properties; s < r.length; s += 1) {
              var n = r[s];
              this.checkPatternExport(t, n);
            }
          else if ("ArrayPattern" === i)
            for (var a = 0, o = e.elements; a < o.length; a += 1) {
              var p = o[a];
              p && this.checkPatternExport(t, p);
            }
          else
            "Property" === i
              ? this.checkPatternExport(t, e.value)
              : "AssignmentPattern" === i
              ? this.checkPatternExport(t, e.left)
              : "RestElement" === i
              ? this.checkPatternExport(t, e.argument)
              : "ParenthesizedExpression" === i &&
                this.checkPatternExport(t, e.expression);
        }),
        (G.checkVariableExport = function(t, e) {
          if (t)
            for (var i = 0, s = e; i < s.length; i += 1) {
              var r = s[i];
              this.checkPatternExport(t, r.id);
            }
        }),
        (G.shouldParseExportStatement = function() {
          return (
            "var" === this.type.keyword ||
            "const" === this.type.keyword ||
            "class" === this.type.keyword ||
            "function" === this.type.keyword ||
            this.isLet() ||
            this.isAsyncFunction()
          );
        }),
        (G.parseExportSpecifiers = function(t) {
          var e = [],
            i = !0;
          for (this.expect(E.braceL); !this.eat(E.braceR); ) {
            if (i) i = !1;
            else if ((this.expect(E.comma), this.afterTrailingComma(E.braceR)))
              break;
            var s = this.startNode();
            (s.local = this.parseIdent(!0)),
              (s.exported = this.eatContextual("as")
                ? this.parseIdent(!0)
                : s.local),
              this.checkExport(t, s.exported.name, s.exported.start),
              e.push(this.finishNode(s, "ExportSpecifier"));
          }
          return e;
        }),
        (G.parseImport = function(t) {
          return (
            this.next(),
            this.type === E.string
              ? ((t.specifiers = $), (t.source = this.parseExprAtom()))
              : ((t.specifiers = this.parseImportSpecifiers()),
                this.expectContextual("from"),
                (t.source =
                  this.type === E.string
                    ? this.parseExprAtom()
                    : this.unexpected())),
            this.semicolon(),
            this.finishNode(t, "ImportDeclaration")
          );
        }),
        (G.parseImportSpecifiers = function() {
          var t = [],
            e = !0;
          if (this.type === E.name) {
            var i = this.startNode();
            if (
              ((i.local = this.parseIdent()),
              this.checkLVal(i.local, 2),
              t.push(this.finishNode(i, "ImportDefaultSpecifier")),
              !this.eat(E.comma))
            )
              return t;
          }
          if (this.type === E.star) {
            var s = this.startNode();
            return (
              this.next(),
              this.expectContextual("as"),
              (s.local = this.parseIdent()),
              this.checkLVal(s.local, 2),
              t.push(this.finishNode(s, "ImportNamespaceSpecifier")),
              t
            );
          }
          for (this.expect(E.braceL); !this.eat(E.braceR); ) {
            if (e) e = !1;
            else if ((this.expect(E.comma), this.afterTrailingComma(E.braceR)))
              break;
            var r = this.startNode();
            (r.imported = this.parseIdent(!0)),
              this.eatContextual("as")
                ? (r.local = this.parseIdent())
                : (this.checkUnreserved(r.imported), (r.local = r.imported)),
              this.checkLVal(r.local, 2),
              t.push(this.finishNode(r, "ImportSpecifier"));
          }
          return t;
        }),
        (G.adaptDirectivePrologue = function(t) {
          for (var e = 0; e < t.length && this.isDirectiveCandidate(t[e]); ++e)
            t[e].directive = t[e].expression.raw.slice(1, -1);
        }),
        (G.isDirectiveCandidate = function(t) {
          return (
            "ExpressionStatement" === t.type &&
            "Literal" === t.expression.type &&
            "string" == typeof t.expression.value &&
            ('"' === this.input[t.start] || "'" === this.input[t.start])
          );
        });
      var tt = X.prototype;
      (tt.toAssignable = function(t, e, i) {
        if (this.options.ecmaVersion >= 6 && t)
          switch (t.type) {
            case "Identifier":
              this.inAsync &&
                "await" === t.name &&
                this.raise(
                  t.start,
                  "Can not use 'await' as identifier inside an async function"
                );
              break;
            case "ObjectPattern":
            case "ArrayPattern":
            case "RestElement":
              break;
            case "ObjectExpression":
              (t.type = "ObjectPattern"), i && this.checkPatternErrors(i, !0);
              for (var s = 0, r = t.properties; s < r.length; s += 1) {
                var n = r[s];
                this.toAssignable(n, e),
                  "RestElement" !== n.type ||
                    ("ArrayPattern" !== n.argument.type &&
                      "ObjectPattern" !== n.argument.type) ||
                    this.raise(n.argument.start, "Unexpected token");
              }
              break;
            case "Property":
              "init" !== t.kind &&
                this.raise(
                  t.key.start,
                  "Object pattern can't contain getter or setter"
                ),
                this.toAssignable(t.value, e);
              break;
            case "ArrayExpression":
              (t.type = "ArrayPattern"),
                i && this.checkPatternErrors(i, !0),
                this.toAssignableList(t.elements, e);
              break;
            case "SpreadElement":
              (t.type = "RestElement"),
                this.toAssignable(t.argument, e),
                "AssignmentPattern" === t.argument.type &&
                  this.raise(
                    t.argument.start,
                    "Rest elements cannot have a default value"
                  );
              break;
            case "AssignmentExpression":
              "=" !== t.operator &&
                this.raise(
                  t.left.end,
                  "Only '=' operator can be used for specifying default value."
                ),
                (t.type = "AssignmentPattern"),
                delete t.operator,
                this.toAssignable(t.left, e);
            case "AssignmentPattern":
              break;
            case "ParenthesizedExpression":
              this.toAssignable(t.expression, e);
              break;
            case "MemberExpression":
              if (!e) break;
            default:
              this.raise(t.start, "Assigning to rvalue");
          }
        else i && this.checkPatternErrors(i, !0);
        return t;
      }),
        (tt.toAssignableList = function(t, e) {
          for (var i = t.length, s = 0; s < i; s++) {
            var r = t[s];
            r && this.toAssignable(r, e);
          }
          if (i) {
            var n = t[i - 1];
            6 === this.options.ecmaVersion &&
              e &&
              n &&
              "RestElement" === n.type &&
              "Identifier" !== n.argument.type &&
              this.unexpected(n.argument.start);
          }
          return t;
        }),
        (tt.parseSpread = function(t) {
          var e = this.startNode();
          return (
            this.next(),
            (e.argument = this.parseMaybeAssign(!1, t)),
            this.finishNode(e, "SpreadElement")
          );
        }),
        (tt.parseRestBinding = function() {
          var t = this.startNode();
          return (
            this.next(),
            6 === this.options.ecmaVersion &&
              this.type !== E.name &&
              this.unexpected(),
            (t.argument = this.parseBindingAtom()),
            this.finishNode(t, "RestElement")
          );
        }),
        (tt.parseBindingAtom = function() {
          if (this.options.ecmaVersion >= 6)
            switch (this.type) {
              case E.bracketL:
                var t = this.startNode();
                return (
                  this.next(),
                  (t.elements = this.parseBindingList(E.bracketR, !0, !0)),
                  this.finishNode(t, "ArrayPattern")
                );
              case E.braceL:
                return this.parseObj(!0);
            }
          return this.parseIdent();
        }),
        (tt.parseBindingList = function(t, e, i) {
          for (var s = [], r = !0; !this.eat(t); )
            if (
              (r ? (r = !1) : this.expect(E.comma), e && this.type === E.comma)
            )
              s.push(null);
            else {
              if (i && this.afterTrailingComma(t)) break;
              if (this.type === E.ellipsis) {
                var n = this.parseRestBinding();
                this.parseBindingListItem(n),
                  s.push(n),
                  this.type === E.comma &&
                    this.raise(
                      this.start,
                      "Comma is not permitted after the rest element"
                    ),
                  this.expect(t);
                break;
              }
              var a = this.parseMaybeDefault(this.start, this.startLoc);
              this.parseBindingListItem(a), s.push(a);
            }
          return s;
        }),
        (tt.parseBindingListItem = function(t) {
          return t;
        }),
        (tt.parseMaybeDefault = function(t, e, i) {
          if (
            ((i = i || this.parseBindingAtom()),
            this.options.ecmaVersion < 6 || !this.eat(E.eq))
          )
            return i;
          var s = this.startNodeAt(t, e);
          return (
            (s.left = i),
            (s.right = this.parseMaybeAssign()),
            this.finishNode(s, "AssignmentPattern")
          );
        }),
        (tt.checkLVal = function(t, e, i) {
          switch ((void 0 === e && (e = 0), t.type)) {
            case "Identifier":
              this.strict &&
                this.reservedWordsStrictBind.test(t.name) &&
                this.raiseRecoverable(
                  t.start,
                  (e ? "Binding " : "Assigning to ") +
                    t.name +
                    " in strict mode"
                ),
                i &&
                  (O(i, t.name) &&
                    this.raiseRecoverable(t.start, "Argument name clash"),
                  (i[t.name] = !0)),
                0 !== e && 5 !== e && this.declareName(t.name, e, t.start);
              break;
            case "MemberExpression":
              e && this.raiseRecoverable(t.start, "Binding member expression");
              break;
            case "ObjectPattern":
              for (var s = 0, r = t.properties; s < r.length; s += 1) {
                var n = r[s];
                this.checkLVal(n, e, i);
              }
              break;
            case "Property":
              this.checkLVal(t.value, e, i);
              break;
            case "ArrayPattern":
              for (var a = 0, o = t.elements; a < o.length; a += 1) {
                var p = o[a];
                p && this.checkLVal(p, e, i);
              }
              break;
            case "AssignmentPattern":
              this.checkLVal(t.left, e, i);
              break;
            case "RestElement":
              this.checkLVal(t.argument, e, i);
              break;
            case "ParenthesizedExpression":
              this.checkLVal(t.expression, e, i);
              break;
            default:
              this.raise(t.start, (e ? "Binding" : "Assigning to") + " rvalue");
          }
        });
      var et = X.prototype;
      (et.checkPropClash = function(t, e, i) {
        if (
          !(
            (this.options.ecmaVersion >= 9 && "SpreadElement" === t.type) ||
            (this.options.ecmaVersion >= 6 &&
              (t.computed || t.method || t.shorthand))
          )
        ) {
          var s,
            r = t.key;
          switch (r.type) {
            case "Identifier":
              s = r.name;
              break;
            case "Literal":
              s = String(r.value);
              break;
            default:
              return;
          }
          var n = t.kind;
          if (this.options.ecmaVersion >= 6)
            "__proto__" === s &&
              "init" === n &&
              (e.proto &&
                (i && i.doubleProto < 0
                  ? (i.doubleProto = r.start)
                  : this.raiseRecoverable(
                      r.start,
                      "Redefinition of __proto__ property"
                    )),
              (e.proto = !0));
          else {
            var a = e[(s = "$" + s)];
            if (a)
              ("init" === n
                ? (this.strict && a.init) || a.get || a.set
                : a.init || a[n]) &&
                this.raiseRecoverable(r.start, "Redefinition of property");
            else a = e[s] = { init: !1, get: !1, set: !1 };
            a[n] = !0;
          }
        }
      }),
        (et.parseExpression = function(t, e) {
          var i = this.start,
            s = this.startLoc,
            r = this.parseMaybeAssign(t, e);
          if (this.type === E.comma) {
            var n = this.startNodeAt(i, s);
            for (n.expressions = [r]; this.eat(E.comma); )
              n.expressions.push(this.parseMaybeAssign(t, e));
            return this.finishNode(n, "SequenceExpression");
          }
          return r;
        }),
        (et.parseMaybeAssign = function(t, e, i) {
          if (this.isContextual("yield")) {
            if (this.inGenerator) return this.parseYield();
            this.exprAllowed = !1;
          }
          var s = !1,
            r = -1,
            n = -1,
            a = -1;
          e
            ? ((r = e.parenthesizedAssign),
              (n = e.trailingComma),
              (a = e.shorthandAssign),
              (e.parenthesizedAssign = e.trailingComma = e.shorthandAssign = -1))
            : ((e = new z()), (s = !0));
          var o = this.start,
            p = this.startLoc;
          (this.type !== E.parenL && this.type !== E.name) ||
            (this.potentialArrowAt = this.start);
          var h = this.parseMaybeConditional(t, e);
          if ((i && (h = i.call(this, h, o, p)), this.type.isAssign)) {
            var c = this.startNodeAt(o, p);
            return (
              (c.operator = this.value),
              (c.left = this.type === E.eq ? this.toAssignable(h, !1, e) : h),
              s || z.call(e),
              (e.shorthandAssign = -1),
              this.checkLVal(h),
              this.next(),
              (c.right = this.parseMaybeAssign(t)),
              this.finishNode(c, "AssignmentExpression")
            );
          }
          return (
            s && this.checkExpressionErrors(e, !0),
            r > -1 && (e.parenthesizedAssign = r),
            n > -1 && (e.trailingComma = n),
            a > -1 && (e.shorthandAssign = a),
            h
          );
        }),
        (et.parseMaybeConditional = function(t, e) {
          var i = this.start,
            s = this.startLoc,
            r = this.parseExprOps(t, e);
          if (this.checkExpressionErrors(e)) return r;
          if (this.eat(E.question)) {
            var n = this.startNodeAt(i, s);
            return (
              (n.test = r),
              (n.consequent = this.parseMaybeAssign()),
              this.expect(E.colon),
              (n.alternate = this.parseMaybeAssign(t)),
              this.finishNode(n, "ConditionalExpression")
            );
          }
          return r;
        }),
        (et.parseExprOps = function(t, e) {
          var i = this.start,
            s = this.startLoc,
            r = this.parseMaybeUnary(e, !1);
          return this.checkExpressionErrors(e) ||
            (r.start === i && "ArrowFunctionExpression" === r.type)
            ? r
            : this.parseExprOp(r, i, s, -1, t);
        }),
        (et.parseExprOp = function(t, e, i, s, r) {
          var n = this.type.binop;
          if (null != n && (!r || this.type !== E._in) && n > s) {
            var a = this.type === E.logicalOR || this.type === E.logicalAND,
              o = this.value;
            this.next();
            var p = this.start,
              h = this.startLoc,
              c = this.parseExprOp(this.parseMaybeUnary(null, !1), p, h, n, r),
              l = this.buildBinary(e, i, t, c, o, a);
            return this.parseExprOp(l, e, i, s, r);
          }
          return t;
        }),
        (et.buildBinary = function(t, e, i, s, r, n) {
          var a = this.startNodeAt(t, e);
          return (
            (a.left = i),
            (a.operator = r),
            (a.right = s),
            this.finishNode(a, n ? "LogicalExpression" : "BinaryExpression")
          );
        }),
        (et.parseMaybeUnary = function(t, e) {
          var i,
            s = this.start,
            r = this.startLoc;
          if (
            this.isContextual("await") &&
            (this.inAsync ||
              (!this.inFunction && this.options.allowAwaitOutsideFunction))
          )
            (i = this.parseAwait()), (e = !0);
          else if (this.type.prefix) {
            var n = this.startNode(),
              a = this.type === E.incDec;
            (n.operator = this.value),
              (n.prefix = !0),
              this.next(),
              (n.argument = this.parseMaybeUnary(null, !0)),
              this.checkExpressionErrors(t, !0),
              a
                ? this.checkLVal(n.argument)
                : this.strict &&
                  "delete" === n.operator &&
                  "Identifier" === n.argument.type
                ? this.raiseRecoverable(
                    n.start,
                    "Deleting local variable in strict mode"
                  )
                : (e = !0),
              (i = this.finishNode(
                n,
                a ? "UpdateExpression" : "UnaryExpression"
              ));
          } else {
            if (
              ((i = this.parseExprSubscripts(t)), this.checkExpressionErrors(t))
            )
              return i;
            for (; this.type.postfix && !this.canInsertSemicolon(); ) {
              var o = this.startNodeAt(s, r);
              (o.operator = this.value),
                (o.prefix = !1),
                (o.argument = i),
                this.checkLVal(i),
                this.next(),
                (i = this.finishNode(o, "UpdateExpression"));
            }
          }
          return !e && this.eat(E.starstar)
            ? this.buildBinary(
                s,
                r,
                i,
                this.parseMaybeUnary(null, !1),
                "**",
                !1
              )
            : i;
        }),
        (et.parseExprSubscripts = function(t) {
          var e = this.start,
            i = this.startLoc,
            s = this.parseExprAtom(t),
            r =
              "ArrowFunctionExpression" === s.type &&
              ")" !== this.input.slice(this.lastTokStart, this.lastTokEnd);
          if (this.checkExpressionErrors(t) || r) return s;
          var n = this.parseSubscripts(s, e, i);
          return (
            t &&
              "MemberExpression" === n.type &&
              (t.parenthesizedAssign >= n.start && (t.parenthesizedAssign = -1),
              t.parenthesizedBind >= n.start && (t.parenthesizedBind = -1)),
            n
          );
        }),
        (et.parseSubscripts = function(t, e, i, s) {
          for (
            var r =
                this.options.ecmaVersion >= 8 &&
                "Identifier" === t.type &&
                "async" === t.name &&
                this.lastTokEnd === t.end &&
                !this.canInsertSemicolon() &&
                "async" === this.input.slice(t.start, t.end),
              n = void 0;
            ;

          )
            if ((n = this.eat(E.bracketL)) || this.eat(E.dot)) {
              var a = this.startNodeAt(e, i);
              (a.object = t),
                (a.property = n ? this.parseExpression() : this.parseIdent(!0)),
                (a.computed = !!n),
                n && this.expect(E.bracketR),
                (t = this.finishNode(a, "MemberExpression"));
            } else if (!s && this.eat(E.parenL)) {
              var o = new z(),
                p = this.yieldPos,
                h = this.awaitPos;
              (this.yieldPos = 0), (this.awaitPos = 0);
              var c = this.parseExprList(
                E.parenR,
                this.options.ecmaVersion >= 8,
                !1,
                o
              );
              if (r && !this.canInsertSemicolon() && this.eat(E.arrow))
                return (
                  this.checkPatternErrors(o, !1),
                  this.checkYieldAwaitInDefaultParams(),
                  (this.yieldPos = p),
                  (this.awaitPos = h),
                  this.parseArrowExpression(this.startNodeAt(e, i), c, !0)
                );
              this.checkExpressionErrors(o, !0),
                (this.yieldPos = p || this.yieldPos),
                (this.awaitPos = h || this.awaitPos);
              var l = this.startNodeAt(e, i);
              (l.callee = t),
                (l.arguments = c),
                (t = this.finishNode(l, "CallExpression"));
            } else {
              if (this.type !== E.backQuote) return t;
              var u = this.startNodeAt(e, i);
              (u.tag = t),
                (u.quasi = this.parseTemplate({ isTagged: !0 })),
                (t = this.finishNode(u, "TaggedTemplateExpression"));
            }
        }),
        (et.parseExprAtom = function(t) {
          var e,
            i = this.potentialArrowAt === this.start;
          switch (this.type) {
            case E._super:
              return (
                this.inFunction ||
                  this.raise(
                    this.start,
                    "'super' outside of function or class"
                  ),
                (e = this.startNode()),
                this.next(),
                this.type !== E.dot &&
                  this.type !== E.bracketL &&
                  this.type !== E.parenL &&
                  this.unexpected(),
                this.finishNode(e, "Super")
              );
            case E._this:
              return (
                (e = this.startNode()),
                this.next(),
                this.finishNode(e, "ThisExpression")
              );
            case E.name:
              var s = this.start,
                r = this.startLoc,
                n = this.containsEsc,
                a = this.parseIdent(this.type !== E.name);
              if (
                this.options.ecmaVersion >= 8 &&
                !n &&
                "async" === a.name &&
                !this.canInsertSemicolon() &&
                this.eat(E._function)
              )
                return this.parseFunction(this.startNodeAt(s, r), 0, !1, !0);
              if (i && !this.canInsertSemicolon()) {
                if (this.eat(E.arrow))
                  return this.parseArrowExpression(
                    this.startNodeAt(s, r),
                    [a],
                    !1
                  );
                if (
                  this.options.ecmaVersion >= 8 &&
                  "async" === a.name &&
                  this.type === E.name &&
                  !n
                )
                  return (
                    (a = this.parseIdent()),
                    (!this.canInsertSemicolon() && this.eat(E.arrow)) ||
                      this.unexpected(),
                    this.parseArrowExpression(this.startNodeAt(s, r), [a], !0)
                  );
              }
              return a;
            case E.regexp:
              var o = this.value;
              return (
                ((e = this.parseLiteral(o.value)).regex = {
                  pattern: o.pattern,
                  flags: o.flags
                }),
                e
              );
            case E.num:
            case E.string:
              return this.parseLiteral(this.value);
            case E._null:
            case E._true:
            case E._false:
              return (
                ((e = this.startNode()).value =
                  this.type === E._null ? null : this.type === E._true),
                (e.raw = this.type.keyword),
                this.next(),
                this.finishNode(e, "Literal")
              );
            case E.parenL:
              var p = this.start,
                h = this.parseParenAndDistinguishExpression(i);
              return (
                t &&
                  (t.parenthesizedAssign < 0 &&
                    !this.isSimpleAssignTarget(h) &&
                    (t.parenthesizedAssign = p),
                  t.parenthesizedBind < 0 && (t.parenthesizedBind = p)),
                h
              );
            case E.bracketL:
              return (
                (e = this.startNode()),
                this.next(),
                (e.elements = this.parseExprList(E.bracketR, !0, !0, t)),
                this.finishNode(e, "ArrayExpression")
              );
            case E.braceL:
              return this.parseObj(!1, t);
            case E._function:
              return (
                (e = this.startNode()), this.next(), this.parseFunction(e, 0)
              );
            case E._class:
              return this.parseClass(this.startNode(), !1);
            case E._new:
              return this.parseNew();
            case E.backQuote:
              return this.parseTemplate();
            default:
              this.unexpected();
          }
        }),
        (et.parseLiteral = function(t) {
          var e = this.startNode();
          return (
            (e.value = t),
            (e.raw = this.input.slice(this.start, this.end)),
            this.next(),
            this.finishNode(e, "Literal")
          );
        }),
        (et.parseParenExpression = function() {
          this.expect(E.parenL);
          var t = this.parseExpression();
          return this.expect(E.parenR), t;
        }),
        (et.parseParenAndDistinguishExpression = function(t) {
          var e,
            i = this.start,
            s = this.startLoc,
            r = this.options.ecmaVersion >= 8;
          if (this.options.ecmaVersion >= 6) {
            this.next();
            var n,
              a = this.start,
              o = this.startLoc,
              p = [],
              h = !0,
              c = !1,
              l = new z(),
              u = this.yieldPos,
              d = this.awaitPos;
            for (
              this.yieldPos = 0, this.awaitPos = 0;
              this.type !== E.parenR;

            ) {
              if (
                (h ? (h = !1) : this.expect(E.comma),
                r && this.afterTrailingComma(E.parenR, !0))
              ) {
                c = !0;
                break;
              }
              if (this.type === E.ellipsis) {
                (n = this.start),
                  p.push(this.parseParenItem(this.parseRestBinding())),
                  this.type === E.comma &&
                    this.raise(
                      this.start,
                      "Comma is not permitted after the rest element"
                    );
                break;
              }
              p.push(this.parseMaybeAssign(!1, l, this.parseParenItem));
            }
            var f = this.start,
              m = this.startLoc;
            if (
              (this.expect(E.parenR),
              t && !this.canInsertSemicolon() && this.eat(E.arrow))
            )
              return (
                this.checkPatternErrors(l, !1),
                this.checkYieldAwaitInDefaultParams(),
                (this.yieldPos = u),
                (this.awaitPos = d),
                this.parseParenArrowList(i, s, p)
              );
            (p.length && !c) || this.unexpected(this.lastTokStart),
              n && this.unexpected(n),
              this.checkExpressionErrors(l, !0),
              (this.yieldPos = u || this.yieldPos),
              (this.awaitPos = d || this.awaitPos),
              p.length > 1
                ? (((e = this.startNodeAt(a, o)).expressions = p),
                  this.finishNodeAt(e, "SequenceExpression", f, m))
                : (e = p[0]);
          } else e = this.parseParenExpression();
          if (this.options.preserveParens) {
            var y = this.startNodeAt(i, s);
            return (
              (y.expression = e), this.finishNode(y, "ParenthesizedExpression")
            );
          }
          return e;
        }),
        (et.parseParenItem = function(t) {
          return t;
        }),
        (et.parseParenArrowList = function(t, e, i) {
          return this.parseArrowExpression(this.startNodeAt(t, e), i);
        });
      var it = [];
      (et.parseNew = function() {
        var t = this.startNode(),
          e = this.parseIdent(!0);
        if (this.options.ecmaVersion >= 6 && this.eat(E.dot)) {
          t.meta = e;
          var i = this.containsEsc;
          return (
            (t.property = this.parseIdent(!0)),
            ("target" !== t.property.name || i) &&
              this.raiseRecoverable(
                t.property.start,
                "The only valid meta property for new is new.target"
              ),
            this.inNonArrowFunction() ||
              this.raiseRecoverable(
                t.start,
                "new.target can only be used in functions"
              ),
            this.finishNode(t, "MetaProperty")
          );
        }
        var s = this.start,
          r = this.startLoc;
        return (
          (t.callee = this.parseSubscripts(this.parseExprAtom(), s, r, !0)),
          this.eat(E.parenL)
            ? (t.arguments = this.parseExprList(
                E.parenR,
                this.options.ecmaVersion >= 8,
                !1
              ))
            : (t.arguments = it),
          this.finishNode(t, "NewExpression")
        );
      }),
        (et.parseTemplateElement = function(t) {
          var e = t.isTagged,
            i = this.startNode();
          return (
            this.type === E.invalidTemplate
              ? (e ||
                  this.raiseRecoverable(
                    this.start,
                    "Bad escape sequence in untagged template literal"
                  ),
                (i.value = { raw: this.value, cooked: null }))
              : (i.value = {
                  raw: this.input
                    .slice(this.start, this.end)
                    .replace(/\r\n?/g, "\n"),
                  cooked: this.value
                }),
            this.next(),
            (i.tail = this.type === E.backQuote),
            this.finishNode(i, "TemplateElement")
          );
        }),
        (et.parseTemplate = function(t) {
          void 0 === t && (t = {});
          var e = t.isTagged;
          void 0 === e && (e = !1);
          var i = this.startNode();
          this.next(), (i.expressions = []);
          var s = this.parseTemplateElement({ isTagged: e });
          for (i.quasis = [s]; !s.tail; )
            this.type === E.eof &&
              this.raise(this.pos, "Unterminated template literal"),
              this.expect(E.dollarBraceL),
              i.expressions.push(this.parseExpression()),
              this.expect(E.braceR),
              i.quasis.push((s = this.parseTemplateElement({ isTagged: e })));
          return this.next(), this.finishNode(i, "TemplateLiteral");
        }),
        (et.isAsyncProp = function(t) {
          return (
            !t.computed &&
            "Identifier" === t.key.type &&
            "async" === t.key.name &&
            (this.type === E.name ||
              this.type === E.num ||
              this.type === E.string ||
              this.type === E.bracketL ||
              this.type.keyword ||
              (this.options.ecmaVersion >= 9 && this.type === E.star)) &&
            !A.test(this.input.slice(this.lastTokEnd, this.start))
          );
        }),
        (et.parseObj = function(t, e) {
          var i = this.startNode(),
            s = !0,
            r = {};
          for (i.properties = [], this.next(); !this.eat(E.braceR); ) {
            if (s) s = !1;
            else if ((this.expect(E.comma), this.afterTrailingComma(E.braceR)))
              break;
            var n = this.parseProperty(t, e);
            t || this.checkPropClash(n, r, e), i.properties.push(n);
          }
          return this.finishNode(i, t ? "ObjectPattern" : "ObjectExpression");
        }),
        (et.parseProperty = function(t, e) {
          var i,
            s,
            r,
            n,
            a = this.startNode();
          if (this.options.ecmaVersion >= 9 && this.eat(E.ellipsis))
            return t
              ? ((a.argument = this.parseIdent(!1)),
                this.type === E.comma &&
                  this.raise(
                    this.start,
                    "Comma is not permitted after the rest element"
                  ),
                this.finishNode(a, "RestElement"))
              : (this.type === E.parenL &&
                  e &&
                  (e.parenthesizedAssign < 0 &&
                    (e.parenthesizedAssign = this.start),
                  e.parenthesizedBind < 0 &&
                    (e.parenthesizedBind = this.start)),
                (a.argument = this.parseMaybeAssign(!1, e)),
                this.type === E.comma &&
                  e &&
                  e.trailingComma < 0 &&
                  (e.trailingComma = this.start),
                this.finishNode(a, "SpreadElement"));
          this.options.ecmaVersion >= 6 &&
            ((a.method = !1),
            (a.shorthand = !1),
            (t || e) && ((r = this.start), (n = this.startLoc)),
            t || (i = this.eat(E.star)));
          var o = this.containsEsc;
          return (
            this.parsePropertyName(a),
            !t &&
            !o &&
            this.options.ecmaVersion >= 8 &&
            !i &&
            this.isAsyncProp(a)
              ? ((s = !0),
                (i = this.options.ecmaVersion >= 9 && this.eat(E.star)),
                this.parsePropertyName(a, e))
              : (s = !1),
            this.parsePropertyValue(a, t, i, s, r, n, e, o),
            this.finishNode(a, "Property")
          );
        }),
        (et.parsePropertyValue = function(t, e, i, s, r, n, a, o) {
          if (
            ((i || s) && this.type === E.colon && this.unexpected(),
            this.eat(E.colon))
          )
            (t.value = e
              ? this.parseMaybeDefault(this.start, this.startLoc)
              : this.parseMaybeAssign(!1, a)),
              (t.kind = "init");
          else if (this.options.ecmaVersion >= 6 && this.type === E.parenL)
            e && this.unexpected(),
              (t.kind = "init"),
              (t.method = !0),
              (t.value = this.parseMethod(i, s));
          else if (
            e ||
            o ||
            !(this.options.ecmaVersion >= 5) ||
            t.computed ||
            "Identifier" !== t.key.type ||
            ("get" !== t.key.name && "set" !== t.key.name) ||
            this.type === E.comma ||
            this.type === E.braceR
          )
            this.options.ecmaVersion >= 6 &&
            !t.computed &&
            "Identifier" === t.key.type
              ? (this.checkUnreserved(t.key),
                (t.kind = "init"),
                e
                  ? (t.value = this.parseMaybeDefault(r, n, t.key))
                  : this.type === E.eq && a
                  ? (a.shorthandAssign < 0 && (a.shorthandAssign = this.start),
                    (t.value = this.parseMaybeDefault(r, n, t.key)))
                  : (t.value = t.key),
                (t.shorthand = !0))
              : this.unexpected();
          else {
            (i || s) && this.unexpected(),
              (t.kind = t.key.name),
              this.parsePropertyName(t),
              (t.value = this.parseMethod(!1));
            var p = "get" === t.kind ? 0 : 1;
            if (t.value.params.length !== p) {
              var h = t.value.start;
              "get" === t.kind
                ? this.raiseRecoverable(h, "getter should have no params")
                : this.raiseRecoverable(
                    h,
                    "setter should have exactly one param"
                  );
            } else
              "set" === t.kind &&
                "RestElement" === t.value.params[0].type &&
                this.raiseRecoverable(
                  t.value.params[0].start,
                  "Setter cannot use rest params"
                );
          }
        }),
        (et.parsePropertyName = function(t) {
          if (this.options.ecmaVersion >= 6) {
            if (this.eat(E.bracketL))
              return (
                (t.computed = !0),
                (t.key = this.parseMaybeAssign()),
                this.expect(E.bracketR),
                t.key
              );
            t.computed = !1;
          }
          return (t.key =
            this.type === E.num || this.type === E.string
              ? this.parseExprAtom()
              : this.parseIdent(!0));
        }),
        (et.initFunction = function(t) {
          (t.id = null),
            this.options.ecmaVersion >= 6 && (t.generator = t.expression = !1),
            this.options.ecmaVersion >= 8 && (t.async = !1);
        }),
        (et.parseMethod = function(t, e) {
          var i = this.startNode(),
            s = this.yieldPos,
            r = this.awaitPos;
          return (
            this.initFunction(i),
            this.options.ecmaVersion >= 6 && (i.generator = t),
            this.options.ecmaVersion >= 8 && (i.async = !!e),
            (this.yieldPos = 0),
            (this.awaitPos = 0),
            this.enterScope(U(e, i.generator)),
            this.expect(E.parenL),
            (i.params = this.parseBindingList(
              E.parenR,
              !1,
              this.options.ecmaVersion >= 8
            )),
            this.checkYieldAwaitInDefaultParams(),
            this.parseFunctionBody(i, !1),
            (this.yieldPos = s),
            (this.awaitPos = r),
            this.finishNode(i, "FunctionExpression")
          );
        }),
        (et.parseArrowExpression = function(t, e, i) {
          var s = this.yieldPos,
            r = this.awaitPos;
          return (
            this.enterScope(16 | U(i, !1)),
            this.initFunction(t),
            this.options.ecmaVersion >= 8 && (t.async = !!i),
            (this.yieldPos = 0),
            (this.awaitPos = 0),
            (t.params = this.toAssignableList(e, !0)),
            this.parseFunctionBody(t, !0),
            (this.yieldPos = s),
            (this.awaitPos = r),
            this.finishNode(t, "ArrowFunctionExpression")
          );
        }),
        (et.parseFunctionBody = function(t, e) {
          var i = e && this.type !== E.braceL,
            s = this.strict,
            r = !1;
          if (i)
            (t.body = this.parseMaybeAssign()),
              (t.expression = !0),
              this.checkParams(t, !1);
          else {
            var n =
              this.options.ecmaVersion >= 7 &&
              !this.isSimpleParamList(t.params);
            (s && !n) ||
              ((r = this.strictDirective(this.end)) &&
                n &&
                this.raiseRecoverable(
                  t.start,
                  "Illegal 'use strict' directive in function with non-simple parameter list"
                ));
            var a = this.labels;
            (this.labels = []),
              r && (this.strict = !0),
              this.checkParams(
                t,
                !s && !r && !e && this.isSimpleParamList(t.params)
              ),
              (t.body = this.parseBlock(!1)),
              (t.expression = !1),
              this.adaptDirectivePrologue(t.body.body),
              (this.labels = a);
          }
          this.exitScope(),
            this.strict && t.id && this.checkLVal(t.id, 5),
            (this.strict = s);
        }),
        (et.isSimpleParamList = function(t) {
          for (var e = 0, i = t; e < i.length; e += 1) {
            if ("Identifier" !== i[e].type) return !1;
          }
          return !0;
        }),
        (et.checkParams = function(t, e) {
          for (var i = {}, s = 0, r = t.params; s < r.length; s += 1) {
            var n = r[s];
            this.checkLVal(n, 1, e ? null : i);
          }
        }),
        (et.parseExprList = function(t, e, i, s) {
          for (var r = [], n = !0; !this.eat(t); ) {
            if (n) n = !1;
            else if ((this.expect(E.comma), e && this.afterTrailingComma(t)))
              break;
            var a = void 0;
            i && this.type === E.comma
              ? (a = null)
              : this.type === E.ellipsis
              ? ((a = this.parseSpread(s)),
                s &&
                  this.type === E.comma &&
                  s.trailingComma < 0 &&
                  (s.trailingComma = this.start))
              : (a = this.parseMaybeAssign(!1, s)),
              r.push(a);
          }
          return r;
        }),
        (et.checkUnreserved = function(t) {
          var e = t.start,
            i = t.end,
            s = t.name;
          (this.inGenerator &&
            "yield" === s &&
            this.raiseRecoverable(
              e,
              "Can not use 'yield' as identifier inside a generator"
            ),
          this.inAsync &&
            "await" === s &&
            this.raiseRecoverable(
              e,
              "Can not use 'await' as identifier inside an async function"
            ),
          this.keywords.test(s) &&
            this.raise(e, "Unexpected keyword '" + s + "'"),
          this.options.ecmaVersion < 6 &&
            -1 !== this.input.slice(e, i).indexOf("\\")) ||
            ((this.strict ? this.reservedWordsStrict : this.reservedWords).test(
              s
            ) &&
              (this.inAsync ||
                "await" !== s ||
                this.raiseRecoverable(
                  e,
                  "Can not use keyword 'await' outside an async function"
                ),
              this.raiseRecoverable(e, "The keyword '" + s + "' is reserved")));
        }),
        (et.parseIdent = function(t, e) {
          var i = this.startNode();
          return (
            t && "never" === this.options.allowReserved && (t = !1),
            this.type === E.name
              ? (i.name = this.value)
              : this.type.keyword
              ? ((i.name = this.type.keyword),
                ("class" !== i.name && "function" !== i.name) ||
                  (this.lastTokEnd === this.lastTokStart + 1 &&
                    46 === this.input.charCodeAt(this.lastTokStart)) ||
                  this.context.pop())
              : this.unexpected(),
            this.next(),
            this.finishNode(i, "Identifier"),
            t || this.checkUnreserved(i),
            i
          );
        }),
        (et.parseYield = function() {
          this.yieldPos || (this.yieldPos = this.start);
          var t = this.startNode();
          return (
            this.next(),
            this.type === E.semi ||
            this.canInsertSemicolon() ||
            (this.type !== E.star && !this.type.startsExpr)
              ? ((t.delegate = !1), (t.argument = null))
              : ((t.delegate = this.eat(E.star)),
                (t.argument = this.parseMaybeAssign())),
            this.finishNode(t, "YieldExpression")
          );
        }),
        (et.parseAwait = function() {
          this.awaitPos || (this.awaitPos = this.start);
          var t = this.startNode();
          return (
            this.next(),
            (t.argument = this.parseMaybeUnary(null, !0)),
            this.finishNode(t, "AwaitExpression")
          );
        });
      var st = X.prototype;
      (st.raise = function(t, e) {
        var i = F(this.input, t);
        e += " (" + i.line + ":" + i.column + ")";
        var s = new SyntaxError(e);
        throw ((s.pos = t), (s.loc = i), (s.raisedAt = this.pos), s);
      }),
        (st.raiseRecoverable = st.raise),
        (st.curPosition = function() {
          if (this.options.locations)
            return new V(this.curLine, this.pos - this.lineStart);
        });
      var rt = X.prototype,
        nt = function(t) {
          (this.flags = t), (this.var = []), (this.lexical = []);
        };
      (rt.enterScope = function(t) {
        this.scopeStack.push(new nt(t));
      }),
        (rt.exitScope = function() {
          this.scopeStack.pop();
        }),
        (rt.declareName = function(t, e, i) {
          var s = !1;
          if (2 === e) {
            var r = this.currentScope();
            (s = r.lexical.indexOf(t) > -1 || r.var.indexOf(t) > -1),
              r.lexical.push(t);
          } else if (4 === e) {
            this.currentScope().lexical.push(t);
          } else if (3 === e) {
            var n = this.currentScope();
            (s = n.lexical.indexOf(t) > -1), n.var.push(t);
          } else
            for (var a = this.scopeStack.length - 1; a >= 0; --a) {
              var o = this.scopeStack[a];
              if (
                (o.lexical.indexOf(t) > -1 &&
                  !(32 & o.flags) &&
                  o.lexical[0] === t &&
                  (s = !0),
                o.var.push(t),
                3 & o.flags)
              )
                break;
            }
          s &&
            this.raiseRecoverable(
              i,
              "Identifier '" + t + "' has already been declared"
            );
        }),
        (rt.currentScope = function() {
          return this.scopeStack[this.scopeStack.length - 1];
        }),
        (rt.currentVarScope = function() {
          for (var t = this.scopeStack.length - 1; ; t--) {
            var e = this.scopeStack[t];
            if (3 & e.flags) return e;
          }
        }),
        (rt.inNonArrowFunction = function() {
          for (var t = this.scopeStack.length - 1; t >= 0; t--)
            if (
              2 & this.scopeStack[t].flags &&
              !(16 & this.scopeStack[t].flags)
            )
              return !0;
          return !1;
        });
      var at = function(t, e, i) {
          (this.type = ""),
            (this.start = e),
            (this.end = 0),
            t.options.locations && (this.loc = new D(t, i)),
            t.options.directSourceFile &&
              (this.sourceFile = t.options.directSourceFile),
            t.options.ranges && (this.range = [e, 0]);
        },
        ot = X.prototype;
      function pt(t, e, i, s) {
        return (
          (t.type = e),
          (t.end = i),
          this.options.locations && (t.loc.end = s),
          this.options.ranges && (t.range[1] = i),
          t
        );
      }
      (ot.startNode = function() {
        return new at(this, this.start, this.startLoc);
      }),
        (ot.startNodeAt = function(t, e) {
          return new at(this, t, e);
        }),
        (ot.finishNode = function(t, e) {
          return pt.call(this, t, e, this.lastTokEnd, this.lastTokEndLoc);
        }),
        (ot.finishNodeAt = function(t, e, i, s) {
          return pt.call(this, t, e, i, s);
        });
      var ht = function(t, e, i, s, r) {
          (this.token = t),
            (this.isExpr = !!e),
            (this.preserveSpace = !!i),
            (this.override = s),
            (this.generator = !!r);
        },
        ct = {
          b_stat: new ht("{", !1),
          b_expr: new ht("{", !0),
          b_tmpl: new ht("${", !1),
          p_stat: new ht("(", !1),
          p_expr: new ht("(", !0),
          q_tmpl: new ht("`", !0, !0, function(t) {
            return t.tryReadTemplateToken();
          }),
          f_stat: new ht("function", !1),
          f_expr: new ht("function", !0),
          f_expr_gen: new ht("function", !0, !1, null, !0),
          f_gen: new ht("function", !1, !1, null, !0)
        },
        lt = X.prototype;
      (lt.initialContext = function() {
        return [ct.b_stat];
      }),
        (lt.braceIsBlock = function(t) {
          var e = this.curContext();
          return (
            e === ct.f_expr ||
            e === ct.f_stat ||
            (t !== E.colon || (e !== ct.b_stat && e !== ct.b_expr)
              ? t === E._return || (t === E.name && this.exprAllowed)
                ? A.test(this.input.slice(this.lastTokEnd, this.start))
                : t === E._else ||
                  t === E.semi ||
                  t === E.eof ||
                  t === E.parenR ||
                  t === E.arrow ||
                  (t === E.braceL
                    ? e === ct.b_stat
                    : t !== E._var && t !== E.name && !this.exprAllowed)
              : !e.isExpr)
          );
        }),
        (lt.inGeneratorContext = function() {
          for (var t = this.context.length - 1; t >= 1; t--) {
            var e = this.context[t];
            if ("function" === e.token) return e.generator;
          }
          return !1;
        }),
        (lt.updateContext = function(t) {
          var e,
            i = this.type;
          i.keyword && t === E.dot
            ? (this.exprAllowed = !1)
            : (e = i.updateContext)
            ? e.call(this, t)
            : (this.exprAllowed = i.beforeExpr);
        }),
        (E.parenR.updateContext = E.braceR.updateContext = function() {
          if (1 !== this.context.length) {
            var t = this.context.pop();
            t === ct.b_stat &&
              "function" === this.curContext().token &&
              (t = this.context.pop()),
              (this.exprAllowed = !t.isExpr);
          } else this.exprAllowed = !0;
        }),
        (E.braceL.updateContext = function(t) {
          this.context.push(this.braceIsBlock(t) ? ct.b_stat : ct.b_expr),
            (this.exprAllowed = !0);
        }),
        (E.dollarBraceL.updateContext = function() {
          this.context.push(ct.b_tmpl), (this.exprAllowed = !0);
        }),
        (E.parenL.updateContext = function(t) {
          var e =
            t === E._if || t === E._for || t === E._with || t === E._while;
          this.context.push(e ? ct.p_stat : ct.p_expr), (this.exprAllowed = !0);
        }),
        (E.incDec.updateContext = function() {}),
        (E._function.updateContext = E._class.updateContext = function(t) {
          t.beforeExpr &&
          t !== E.semi &&
          t !== E._else &&
          ((t !== E.colon && t !== E.braceL) || this.curContext() !== ct.b_stat)
            ? this.context.push(ct.f_expr)
            : this.context.push(ct.f_stat),
            (this.exprAllowed = !1);
        }),
        (E.backQuote.updateContext = function() {
          this.curContext() === ct.q_tmpl
            ? this.context.pop()
            : this.context.push(ct.q_tmpl),
            (this.exprAllowed = !1);
        }),
        (E.star.updateContext = function(t) {
          if (t === E._function) {
            var e = this.context.length - 1;
            this.context[e] === ct.f_expr
              ? (this.context[e] = ct.f_expr_gen)
              : (this.context[e] = ct.f_gen);
          }
          this.exprAllowed = !0;
        }),
        (E.name.updateContext = function(t) {
          var e = !1;
          this.options.ecmaVersion >= 6 &&
            t !== E.dot &&
            (("of" === this.value && !this.exprAllowed) ||
              ("yield" === this.value && this.inGeneratorContext())) &&
            (e = !0),
            (this.exprAllowed = e);
        });
      var ut = {
        $LONE: [
          "ASCII",
          "ASCII_Hex_Digit",
          "AHex",
          "Alphabetic",
          "Alpha",
          "Any",
          "Assigned",
          "Bidi_Control",
          "Bidi_C",
          "Bidi_Mirrored",
          "Bidi_M",
          "Case_Ignorable",
          "CI",
          "Cased",
          "Changes_When_Casefolded",
          "CWCF",
          "Changes_When_Casemapped",
          "CWCM",
          "Changes_When_Lowercased",
          "CWL",
          "Changes_When_NFKC_Casefolded",
          "CWKCF",
          "Changes_When_Titlecased",
          "CWT",
          "Changes_When_Uppercased",
          "CWU",
          "Dash",
          "Default_Ignorable_Code_Point",
          "DI",
          "Deprecated",
          "Dep",
          "Diacritic",
          "Dia",
          "Emoji",
          "Emoji_Component",
          "Emoji_Modifier",
          "Emoji_Modifier_Base",
          "Emoji_Presentation",
          "Extender",
          "Ext",
          "Grapheme_Base",
          "Gr_Base",
          "Grapheme_Extend",
          "Gr_Ext",
          "Hex_Digit",
          "Hex",
          "IDS_Binary_Operator",
          "IDSB",
          "IDS_Trinary_Operator",
          "IDST",
          "ID_Continue",
          "IDC",
          "ID_Start",
          "IDS",
          "Ideographic",
          "Ideo",
          "Join_Control",
          "Join_C",
          "Logical_Order_Exception",
          "LOE",
          "Lowercase",
          "Lower",
          "Math",
          "Noncharacter_Code_Point",
          "NChar",
          "Pattern_Syntax",
          "Pat_Syn",
          "Pattern_White_Space",
          "Pat_WS",
          "Quotation_Mark",
          "QMark",
          "Radical",
          "Regional_Indicator",
          "RI",
          "Sentence_Terminal",
          "STerm",
          "Soft_Dotted",
          "SD",
          "Terminal_Punctuation",
          "Term",
          "Unified_Ideograph",
          "UIdeo",
          "Uppercase",
          "Upper",
          "Variation_Selector",
          "VS",
          "White_Space",
          "space",
          "XID_Continue",
          "XIDC",
          "XID_Start",
          "XIDS"
        ],
        General_Category: [
          "Cased_Letter",
          "LC",
          "Close_Punctuation",
          "Pe",
          "Connector_Punctuation",
          "Pc",
          "Control",
          "Cc",
          "cntrl",
          "Currency_Symbol",
          "Sc",
          "Dash_Punctuation",
          "Pd",
          "Decimal_Number",
          "Nd",
          "digit",
          "Enclosing_Mark",
          "Me",
          "Final_Punctuation",
          "Pf",
          "Format",
          "Cf",
          "Initial_Punctuation",
          "Pi",
          "Letter",
          "L",
          "Letter_Number",
          "Nl",
          "Line_Separator",
          "Zl",
          "Lowercase_Letter",
          "Ll",
          "Mark",
          "M",
          "Combining_Mark",
          "Math_Symbol",
          "Sm",
          "Modifier_Letter",
          "Lm",
          "Modifier_Symbol",
          "Sk",
          "Nonspacing_Mark",
          "Mn",
          "Number",
          "N",
          "Open_Punctuation",
          "Ps",
          "Other",
          "C",
          "Other_Letter",
          "Lo",
          "Other_Number",
          "No",
          "Other_Punctuation",
          "Po",
          "Other_Symbol",
          "So",
          "Paragraph_Separator",
          "Zp",
          "Private_Use",
          "Co",
          "Punctuation",
          "P",
          "punct",
          "Separator",
          "Z",
          "Space_Separator",
          "Zs",
          "Spacing_Mark",
          "Mc",
          "Surrogate",
          "Cs",
          "Symbol",
          "S",
          "Titlecase_Letter",
          "Lt",
          "Unassigned",
          "Cn",
          "Uppercase_Letter",
          "Lu"
        ],
        Script: [
          "Adlam",
          "Adlm",
          "Ahom",
          "Anatolian_Hieroglyphs",
          "Hluw",
          "Arabic",
          "Arab",
          "Armenian",
          "Armn",
          "Avestan",
          "Avst",
          "Balinese",
          "Bali",
          "Bamum",
          "Bamu",
          "Bassa_Vah",
          "Bass",
          "Batak",
          "Batk",
          "Bengali",
          "Beng",
          "Bhaiksuki",
          "Bhks",
          "Bopomofo",
          "Bopo",
          "Brahmi",
          "Brah",
          "Braille",
          "Brai",
          "Buginese",
          "Bugi",
          "Buhid",
          "Buhd",
          "Canadian_Aboriginal",
          "Cans",
          "Carian",
          "Cari",
          "Caucasian_Albanian",
          "Aghb",
          "Chakma",
          "Cakm",
          "Cham",
          "Cherokee",
          "Cher",
          "Common",
          "Zyyy",
          "Coptic",
          "Copt",
          "Qaac",
          "Cuneiform",
          "Xsux",
          "Cypriot",
          "Cprt",
          "Cyrillic",
          "Cyrl",
          "Deseret",
          "Dsrt",
          "Devanagari",
          "Deva",
          "Duployan",
          "Dupl",
          "Egyptian_Hieroglyphs",
          "Egyp",
          "Elbasan",
          "Elba",
          "Ethiopic",
          "Ethi",
          "Georgian",
          "Geor",
          "Glagolitic",
          "Glag",
          "Gothic",
          "Goth",
          "Grantha",
          "Gran",
          "Greek",
          "Grek",
          "Gujarati",
          "Gujr",
          "Gurmukhi",
          "Guru",
          "Han",
          "Hani",
          "Hangul",
          "Hang",
          "Hanunoo",
          "Hano",
          "Hatran",
          "Hatr",
          "Hebrew",
          "Hebr",
          "Hiragana",
          "Hira",
          "Imperial_Aramaic",
          "Armi",
          "Inherited",
          "Zinh",
          "Qaai",
          "Inscriptional_Pahlavi",
          "Phli",
          "Inscriptional_Parthian",
          "Prti",
          "Javanese",
          "Java",
          "Kaithi",
          "Kthi",
          "Kannada",
          "Knda",
          "Katakana",
          "Kana",
          "Kayah_Li",
          "Kali",
          "Kharoshthi",
          "Khar",
          "Khmer",
          "Khmr",
          "Khojki",
          "Khoj",
          "Khudawadi",
          "Sind",
          "Lao",
          "Laoo",
          "Latin",
          "Latn",
          "Lepcha",
          "Lepc",
          "Limbu",
          "Limb",
          "Linear_A",
          "Lina",
          "Linear_B",
          "Linb",
          "Lisu",
          "Lycian",
          "Lyci",
          "Lydian",
          "Lydi",
          "Mahajani",
          "Mahj",
          "Malayalam",
          "Mlym",
          "Mandaic",
          "Mand",
          "Manichaean",
          "Mani",
          "Marchen",
          "Marc",
          "Masaram_Gondi",
          "Gonm",
          "Meetei_Mayek",
          "Mtei",
          "Mende_Kikakui",
          "Mend",
          "Meroitic_Cursive",
          "Merc",
          "Meroitic_Hieroglyphs",
          "Mero",
          "Miao",
          "Plrd",
          "Modi",
          "Mongolian",
          "Mong",
          "Mro",
          "Mroo",
          "Multani",
          "Mult",
          "Myanmar",
          "Mymr",
          "Nabataean",
          "Nbat",
          "New_Tai_Lue",
          "Talu",
          "Newa",
          "Nko",
          "Nkoo",
          "Nushu",
          "Nshu",
          "Ogham",
          "Ogam",
          "Ol_Chiki",
          "Olck",
          "Old_Hungarian",
          "Hung",
          "Old_Italic",
          "Ital",
          "Old_North_Arabian",
          "Narb",
          "Old_Permic",
          "Perm",
          "Old_Persian",
          "Xpeo",
          "Old_South_Arabian",
          "Sarb",
          "Old_Turkic",
          "Orkh",
          "Oriya",
          "Orya",
          "Osage",
          "Osge",
          "Osmanya",
          "Osma",
          "Pahawh_Hmong",
          "Hmng",
          "Palmyrene",
          "Palm",
          "Pau_Cin_Hau",
          "Pauc",
          "Phags_Pa",
          "Phag",
          "Phoenician",
          "Phnx",
          "Psalter_Pahlavi",
          "Phlp",
          "Rejang",
          "Rjng",
          "Runic",
          "Runr",
          "Samaritan",
          "Samr",
          "Saurashtra",
          "Saur",
          "Sharada",
          "Shrd",
          "Shavian",
          "Shaw",
          "Siddham",
          "Sidd",
          "SignWriting",
          "Sgnw",
          "Sinhala",
          "Sinh",
          "Sora_Sompeng",
          "Sora",
          "Soyombo",
          "Soyo",
          "Sundanese",
          "Sund",
          "Syloti_Nagri",
          "Sylo",
          "Syriac",
          "Syrc",
          "Tagalog",
          "Tglg",
          "Tagbanwa",
          "Tagb",
          "Tai_Le",
          "Tale",
          "Tai_Tham",
          "Lana",
          "Tai_Viet",
          "Tavt",
          "Takri",
          "Takr",
          "Tamil",
          "Taml",
          "Tangut",
          "Tang",
          "Telugu",
          "Telu",
          "Thaana",
          "Thaa",
          "Thai",
          "Tibetan",
          "Tibt",
          "Tifinagh",
          "Tfng",
          "Tirhuta",
          "Tirh",
          "Ugaritic",
          "Ugar",
          "Vai",
          "Vaii",
          "Warang_Citi",
          "Wara",
          "Yi",
          "Yiii",
          "Zanabazar_Square",
          "Zanb"
        ]
      };
      Array.prototype.push.apply(ut.$LONE, ut.General_Category),
        (ut.gc = ut.General_Category),
        (ut.sc = ut.Script_Extensions = ut.scx = ut.Script);
      var dt = X.prototype,
        ft = function(t) {
          (this.parser = t),
            (this.validFlags =
              "gim" +
              (t.options.ecmaVersion >= 6 ? "uy" : "") +
              (t.options.ecmaVersion >= 9 ? "s" : "")),
            (this.source = ""),
            (this.flags = ""),
            (this.start = 0),
            (this.switchU = !1),
            (this.switchN = !1),
            (this.pos = 0),
            (this.lastIntValue = 0),
            (this.lastStringValue = ""),
            (this.lastAssertionIsQuantifiable = !1),
            (this.numCapturingParens = 0),
            (this.maxBackReference = 0),
            (this.groupNames = []),
            (this.backReferenceNames = []);
        };
      function mt(t) {
        return t <= 65535
          ? String.fromCharCode(t)
          : ((t -= 65536),
            String.fromCharCode(55296 + (t >> 10), 56320 + (1023 & t)));
      }
      function yt(t) {
        return (
          36 === t ||
          (t >= 40 && t <= 43) ||
          46 === t ||
          63 === t ||
          (t >= 91 && t <= 94) ||
          (t >= 123 && t <= 125)
        );
      }
      function gt(t) {
        return (t >= 65 && t <= 90) || (t >= 97 && t <= 122);
      }
      function vt(t) {
        return gt(t) || 95 === t;
      }
      function xt(t) {
        return vt(t) || bt(t);
      }
      function bt(t) {
        return t >= 48 && t <= 57;
      }
      function _t(t) {
        return (
          (t >= 48 && t <= 57) || (t >= 65 && t <= 70) || (t >= 97 && t <= 102)
        );
      }
      function kt(t) {
        return t >= 65 && t <= 70
          ? t - 65 + 10
          : t >= 97 && t <= 102
          ? t - 97 + 10
          : t - 48;
      }
      function St(t) {
        return t >= 48 && t <= 55;
      }
      (ft.prototype.reset = function(t, e, i) {
        var s = -1 !== i.indexOf("u");
        (this.start = 0 | t),
          (this.source = e + ""),
          (this.flags = i),
          (this.switchU = s && this.parser.options.ecmaVersion >= 6),
          (this.switchN = s && this.parser.options.ecmaVersion >= 9);
      }),
        (ft.prototype.raise = function(t) {
          this.parser.raiseRecoverable(
            this.start,
            "Invalid regular expression: /" + this.source + "/: " + t
          );
        }),
        (ft.prototype.at = function(t) {
          var e = this.source,
            i = e.length;
          if (t >= i) return -1;
          var s = e.charCodeAt(t);
          return !this.switchU || s <= 55295 || s >= 57344 || t + 1 >= i
            ? s
            : (s << 10) + e.charCodeAt(t + 1) - 56613888;
        }),
        (ft.prototype.nextIndex = function(t) {
          var e = this.source,
            i = e.length;
          if (t >= i) return i;
          var s = e.charCodeAt(t);
          return !this.switchU || s <= 55295 || s >= 57344 || t + 1 >= i
            ? t + 1
            : t + 2;
        }),
        (ft.prototype.current = function() {
          return this.at(this.pos);
        }),
        (ft.prototype.lookahead = function() {
          return this.at(this.nextIndex(this.pos));
        }),
        (ft.prototype.advance = function() {
          this.pos = this.nextIndex(this.pos);
        }),
        (ft.prototype.eat = function(t) {
          return this.current() === t && (this.advance(), !0);
        }),
        (dt.validateRegExpFlags = function(t) {
          for (var e = t.validFlags, i = t.flags, s = 0; s < i.length; s++) {
            var r = i.charAt(s);
            -1 === e.indexOf(r) &&
              this.raise(t.start, "Invalid regular expression flag"),
              i.indexOf(r, s + 1) > -1 &&
                this.raise(t.start, "Duplicate regular expression flag");
          }
        }),
        (dt.validateRegExpPattern = function(t) {
          this.regexp_pattern(t),
            !t.switchN &&
              this.options.ecmaVersion >= 9 &&
              t.groupNames.length > 0 &&
              ((t.switchN = !0), this.regexp_pattern(t));
        }),
        (dt.regexp_pattern = function(t) {
          (t.pos = 0),
            (t.lastIntValue = 0),
            (t.lastStringValue = ""),
            (t.lastAssertionIsQuantifiable = !1),
            (t.numCapturingParens = 0),
            (t.maxBackReference = 0),
            (t.groupNames.length = 0),
            (t.backReferenceNames.length = 0),
            this.regexp_disjunction(t),
            t.pos !== t.source.length &&
              (t.eat(41) && t.raise("Unmatched ')'"),
              (t.eat(93) || t.eat(125)) && t.raise("Lone quantifier brackets")),
            t.maxBackReference > t.numCapturingParens &&
              t.raise("Invalid escape");
          for (var e = 0, i = t.backReferenceNames; e < i.length; e += 1) {
            var s = i[e];
            -1 === t.groupNames.indexOf(s) &&
              t.raise("Invalid named capture referenced");
          }
        }),
        (dt.regexp_disjunction = function(t) {
          for (this.regexp_alternative(t); t.eat(124); )
            this.regexp_alternative(t);
          this.regexp_eatQuantifier(t, !0) && t.raise("Nothing to repeat"),
            t.eat(123) && t.raise("Lone quantifier brackets");
        }),
        (dt.regexp_alternative = function(t) {
          for (; t.pos < t.source.length && this.regexp_eatTerm(t); );
        }),
        (dt.regexp_eatTerm = function(t) {
          return this.regexp_eatAssertion(t)
            ? (t.lastAssertionIsQuantifiable &&
                this.regexp_eatQuantifier(t) &&
                t.switchU &&
                t.raise("Invalid quantifier"),
              !0)
            : !!(t.switchU
                ? this.regexp_eatAtom(t)
                : this.regexp_eatExtendedAtom(t)) &&
                (this.regexp_eatQuantifier(t), !0);
        }),
        (dt.regexp_eatAssertion = function(t) {
          var e = t.pos;
          if (((t.lastAssertionIsQuantifiable = !1), t.eat(94) || t.eat(36)))
            return !0;
          if (t.eat(92)) {
            if (t.eat(66) || t.eat(98)) return !0;
            t.pos = e;
          }
          if (t.eat(40) && t.eat(63)) {
            var i = !1;
            if (
              (this.options.ecmaVersion >= 9 && (i = t.eat(60)),
              t.eat(61) || t.eat(33))
            )
              return (
                this.regexp_disjunction(t),
                t.eat(41) || t.raise("Unterminated group"),
                (t.lastAssertionIsQuantifiable = !i),
                !0
              );
          }
          return (t.pos = e), !1;
        }),
        (dt.regexp_eatQuantifier = function(t, e) {
          return (
            void 0 === e && (e = !1),
            !!this.regexp_eatQuantifierPrefix(t, e) && (t.eat(63), !0)
          );
        }),
        (dt.regexp_eatQuantifierPrefix = function(t, e) {
          return (
            t.eat(42) ||
            t.eat(43) ||
            t.eat(63) ||
            this.regexp_eatBracedQuantifier(t, e)
          );
        }),
        (dt.regexp_eatBracedQuantifier = function(t, e) {
          var i = t.pos;
          if (t.eat(123)) {
            var s = 0,
              r = -1;
            if (
              this.regexp_eatDecimalDigits(t) &&
              ((s = t.lastIntValue),
              t.eat(44) &&
                this.regexp_eatDecimalDigits(t) &&
                (r = t.lastIntValue),
              t.eat(125))
            )
              return (
                -1 !== r &&
                  r < s &&
                  !e &&
                  t.raise("numbers out of order in {} quantifier"),
                !0
              );
            t.switchU && !e && t.raise("Incomplete quantifier"), (t.pos = i);
          }
          return !1;
        }),
        (dt.regexp_eatAtom = function(t) {
          return (
            this.regexp_eatPatternCharacters(t) ||
            t.eat(46) ||
            this.regexp_eatReverseSolidusAtomEscape(t) ||
            this.regexp_eatCharacterClass(t) ||
            this.regexp_eatUncapturingGroup(t) ||
            this.regexp_eatCapturingGroup(t)
          );
        }),
        (dt.regexp_eatReverseSolidusAtomEscape = function(t) {
          var e = t.pos;
          if (t.eat(92)) {
            if (this.regexp_eatAtomEscape(t)) return !0;
            t.pos = e;
          }
          return !1;
        }),
        (dt.regexp_eatUncapturingGroup = function(t) {
          var e = t.pos;
          if (t.eat(40)) {
            if (t.eat(63) && t.eat(58)) {
              if ((this.regexp_disjunction(t), t.eat(41))) return !0;
              t.raise("Unterminated group");
            }
            t.pos = e;
          }
          return !1;
        }),
        (dt.regexp_eatCapturingGroup = function(t) {
          if (t.eat(40)) {
            if (
              (this.options.ecmaVersion >= 9
                ? this.regexp_groupSpecifier(t)
                : 63 === t.current() && t.raise("Invalid group"),
              this.regexp_disjunction(t),
              t.eat(41))
            )
              return (t.numCapturingParens += 1), !0;
            t.raise("Unterminated group");
          }
          return !1;
        }),
        (dt.regexp_eatExtendedAtom = function(t) {
          return (
            t.eat(46) ||
            this.regexp_eatReverseSolidusAtomEscape(t) ||
            this.regexp_eatCharacterClass(t) ||
            this.regexp_eatUncapturingGroup(t) ||
            this.regexp_eatCapturingGroup(t) ||
            this.regexp_eatInvalidBracedQuantifier(t) ||
            this.regexp_eatExtendedPatternCharacter(t)
          );
        }),
        (dt.regexp_eatInvalidBracedQuantifier = function(t) {
          return (
            this.regexp_eatBracedQuantifier(t, !0) &&
              t.raise("Nothing to repeat"),
            !1
          );
        }),
        (dt.regexp_eatSyntaxCharacter = function(t) {
          var e = t.current();
          return !!yt(e) && ((t.lastIntValue = e), t.advance(), !0);
        }),
        (dt.regexp_eatPatternCharacters = function(t) {
          for (var e = t.pos, i = 0; -1 !== (i = t.current()) && !yt(i); )
            t.advance();
          return t.pos !== e;
        }),
        (dt.regexp_eatExtendedPatternCharacter = function(t) {
          var e = t.current();
          return (
            !(
              -1 === e ||
              36 === e ||
              (e >= 40 && e <= 43) ||
              46 === e ||
              63 === e ||
              91 === e ||
              94 === e ||
              124 === e
            ) && (t.advance(), !0)
          );
        }),
        (dt.regexp_groupSpecifier = function(t) {
          if (t.eat(63)) {
            if (this.regexp_eatGroupName(t))
              return (
                -1 !== t.groupNames.indexOf(t.lastStringValue) &&
                  t.raise("Duplicate capture group name"),
                void t.groupNames.push(t.lastStringValue)
              );
            t.raise("Invalid group");
          }
        }),
        (dt.regexp_eatGroupName = function(t) {
          if (((t.lastStringValue = ""), t.eat(60))) {
            if (this.regexp_eatRegExpIdentifierName(t) && t.eat(62)) return !0;
            t.raise("Invalid capture group name");
          }
          return !1;
        }),
        (dt.regexp_eatRegExpIdentifierName = function(t) {
          if (
            ((t.lastStringValue = ""), this.regexp_eatRegExpIdentifierStart(t))
          ) {
            for (
              t.lastStringValue += mt(t.lastIntValue);
              this.regexp_eatRegExpIdentifierPart(t);

            )
              t.lastStringValue += mt(t.lastIntValue);
            return !0;
          }
          return !1;
        }),
        (dt.regexp_eatRegExpIdentifierStart = function(t) {
          var e = t.pos,
            i = t.current();
          return (
            t.advance(),
            92 === i &&
              this.regexp_eatRegExpUnicodeEscapeSequence(t) &&
              (i = t.lastIntValue),
            (function(t) {
              return g(t, !0) || 36 === t || 95 === t;
            })(i)
              ? ((t.lastIntValue = i), !0)
              : ((t.pos = e), !1)
          );
        }),
        (dt.regexp_eatRegExpIdentifierPart = function(t) {
          var e = t.pos,
            i = t.current();
          return (
            t.advance(),
            92 === i &&
              this.regexp_eatRegExpUnicodeEscapeSequence(t) &&
              (i = t.lastIntValue),
            (function(t) {
              return (
                v(t, !0) || 36 === t || 95 === t || 8204 === t || 8205 === t
              );
            })(i)
              ? ((t.lastIntValue = i), !0)
              : ((t.pos = e), !1)
          );
        }),
        (dt.regexp_eatAtomEscape = function(t) {
          return (
            !!(
              this.regexp_eatBackReference(t) ||
              this.regexp_eatCharacterClassEscape(t) ||
              this.regexp_eatCharacterEscape(t) ||
              (t.switchN && this.regexp_eatKGroupName(t))
            ) ||
            (t.switchU &&
              (99 === t.current() && t.raise("Invalid unicode escape"),
              t.raise("Invalid escape")),
            !1)
          );
        }),
        (dt.regexp_eatBackReference = function(t) {
          var e = t.pos;
          if (this.regexp_eatDecimalEscape(t)) {
            var i = t.lastIntValue;
            if (t.switchU)
              return i > t.maxBackReference && (t.maxBackReference = i), !0;
            if (i <= t.numCapturingParens) return !0;
            t.pos = e;
          }
          return !1;
        }),
        (dt.regexp_eatKGroupName = function(t) {
          if (t.eat(107)) {
            if (this.regexp_eatGroupName(t))
              return t.backReferenceNames.push(t.lastStringValue), !0;
            t.raise("Invalid named reference");
          }
          return !1;
        }),
        (dt.regexp_eatCharacterEscape = function(t) {
          return (
            this.regexp_eatControlEscape(t) ||
            this.regexp_eatCControlLetter(t) ||
            this.regexp_eatZero(t) ||
            this.regexp_eatHexEscapeSequence(t) ||
            this.regexp_eatRegExpUnicodeEscapeSequence(t) ||
            (!t.switchU && this.regexp_eatLegacyOctalEscapeSequence(t)) ||
            this.regexp_eatIdentityEscape(t)
          );
        }),
        (dt.regexp_eatCControlLetter = function(t) {
          var e = t.pos;
          if (t.eat(99)) {
            if (this.regexp_eatControlLetter(t)) return !0;
            t.pos = e;
          }
          return !1;
        }),
        (dt.regexp_eatZero = function(t) {
          return (
            48 === t.current() &&
            !bt(t.lookahead()) &&
            ((t.lastIntValue = 0), t.advance(), !0)
          );
        }),
        (dt.regexp_eatControlEscape = function(t) {
          var e = t.current();
          return 116 === e
            ? ((t.lastIntValue = 9), t.advance(), !0)
            : 110 === e
            ? ((t.lastIntValue = 10), t.advance(), !0)
            : 118 === e
            ? ((t.lastIntValue = 11), t.advance(), !0)
            : 102 === e
            ? ((t.lastIntValue = 12), t.advance(), !0)
            : 114 === e && ((t.lastIntValue = 13), t.advance(), !0);
        }),
        (dt.regexp_eatControlLetter = function(t) {
          var e = t.current();
          return !!gt(e) && ((t.lastIntValue = e % 32), t.advance(), !0);
        }),
        (dt.regexp_eatRegExpUnicodeEscapeSequence = function(t) {
          var e,
            i = t.pos;
          if (t.eat(117)) {
            if (this.regexp_eatFixedHexDigits(t, 4)) {
              var s = t.lastIntValue;
              if (t.switchU && s >= 55296 && s <= 56319) {
                var r = t.pos;
                if (
                  t.eat(92) &&
                  t.eat(117) &&
                  this.regexp_eatFixedHexDigits(t, 4)
                ) {
                  var n = t.lastIntValue;
                  if (n >= 56320 && n <= 57343)
                    return (
                      (t.lastIntValue =
                        1024 * (s - 55296) + (n - 56320) + 65536),
                      !0
                    );
                }
                (t.pos = r), (t.lastIntValue = s);
              }
              return !0;
            }
            if (
              t.switchU &&
              t.eat(123) &&
              this.regexp_eatHexDigits(t) &&
              t.eat(125) &&
              (e = t.lastIntValue) >= 0 && e <= 1114111
            )
              return !0;
            t.switchU && t.raise("Invalid unicode escape"), (t.pos = i);
          }
          return !1;
        }),
        (dt.regexp_eatIdentityEscape = function(t) {
          if (t.switchU)
            return (
              !!this.regexp_eatSyntaxCharacter(t) ||
              (!!t.eat(47) && ((t.lastIntValue = 47), !0))
            );
          var e = t.current();
          return (
            !(99 === e || (t.switchN && 107 === e)) &&
            ((t.lastIntValue = e), t.advance(), !0)
          );
        }),
        (dt.regexp_eatDecimalEscape = function(t) {
          t.lastIntValue = 0;
          var e = t.current();
          if (e >= 49 && e <= 57) {
            do {
              (t.lastIntValue = 10 * t.lastIntValue + (e - 48)), t.advance();
            } while ((e = t.current()) >= 48 && e <= 57);
            return !0;
          }
          return !1;
        }),
        (dt.regexp_eatCharacterClassEscape = function(t) {
          var e = t.current();
          if (
            (function(t) {
              return (
                100 === t ||
                68 === t ||
                115 === t ||
                83 === t ||
                119 === t ||
                87 === t
              );
            })(e)
          )
            return (t.lastIntValue = -1), t.advance(), !0;
          if (
            t.switchU &&
            this.options.ecmaVersion >= 9 &&
            (80 === e || 112 === e)
          ) {
            if (
              ((t.lastIntValue = -1),
              t.advance(),
              t.eat(123) &&
                this.regexp_eatUnicodePropertyValueExpression(t) &&
                t.eat(125))
            )
              return !0;
            t.raise("Invalid property name");
          }
          return !1;
        }),
        (dt.regexp_eatUnicodePropertyValueExpression = function(t) {
          var e = t.pos;
          if (this.regexp_eatUnicodePropertyName(t) && t.eat(61)) {
            var i = t.lastStringValue;
            if (this.regexp_eatUnicodePropertyValue(t)) {
              var s = t.lastStringValue;
              return (
                this.regexp_validateUnicodePropertyNameAndValue(t, i, s), !0
              );
            }
          }
          if (((t.pos = e), this.regexp_eatLoneUnicodePropertyNameOrValue(t))) {
            var r = t.lastStringValue;
            return this.regexp_validateUnicodePropertyNameOrValue(t, r), !0;
          }
          return !1;
        }),
        (dt.regexp_validateUnicodePropertyNameAndValue = function(t, e, i) {
          (ut.hasOwnProperty(e) && -1 !== ut[e].indexOf(i)) ||
            t.raise("Invalid property name");
        }),
        (dt.regexp_validateUnicodePropertyNameOrValue = function(t, e) {
          -1 === ut.$LONE.indexOf(e) && t.raise("Invalid property name");
        }),
        (dt.regexp_eatUnicodePropertyName = function(t) {
          var e = 0;
          for (t.lastStringValue = ""; vt((e = t.current())); )
            (t.lastStringValue += mt(e)), t.advance();
          return "" !== t.lastStringValue;
        }),
        (dt.regexp_eatUnicodePropertyValue = function(t) {
          var e = 0;
          for (t.lastStringValue = ""; xt((e = t.current())); )
            (t.lastStringValue += mt(e)), t.advance();
          return "" !== t.lastStringValue;
        }),
        (dt.regexp_eatLoneUnicodePropertyNameOrValue = function(t) {
          return this.regexp_eatUnicodePropertyValue(t);
        }),
        (dt.regexp_eatCharacterClass = function(t) {
          if (t.eat(91)) {
            if ((t.eat(94), this.regexp_classRanges(t), t.eat(93))) return !0;
            t.raise("Unterminated character class");
          }
          return !1;
        }),
        (dt.regexp_classRanges = function(t) {
          for (; this.regexp_eatClassAtom(t); ) {
            var e = t.lastIntValue;
            if (t.eat(45) && this.regexp_eatClassAtom(t)) {
              var i = t.lastIntValue;
              !t.switchU ||
                (-1 !== e && -1 !== i) ||
                t.raise("Invalid character class"),
                -1 !== e &&
                  -1 !== i &&
                  e > i &&
                  t.raise("Range out of order in character class");
            }
          }
        }),
        (dt.regexp_eatClassAtom = function(t) {
          var e = t.pos;
          if (t.eat(92)) {
            if (this.regexp_eatClassEscape(t)) return !0;
            if (t.switchU) {
              var i = t.current();
              (99 === i || St(i)) && t.raise("Invalid class escape"),
                t.raise("Invalid escape");
            }
            t.pos = e;
          }
          var s = t.current();
          return 93 !== s && ((t.lastIntValue = s), t.advance(), !0);
        }),
        (dt.regexp_eatClassEscape = function(t) {
          var e = t.pos;
          if (t.eat(98)) return (t.lastIntValue = 8), !0;
          if (t.switchU && t.eat(45)) return (t.lastIntValue = 45), !0;
          if (!t.switchU && t.eat(99)) {
            if (this.regexp_eatClassControlLetter(t)) return !0;
            t.pos = e;
          }
          return (
            this.regexp_eatCharacterClassEscape(t) ||
            this.regexp_eatCharacterEscape(t)
          );
        }),
        (dt.regexp_eatClassControlLetter = function(t) {
          var e = t.current();
          return (
            !(!bt(e) && 95 !== e) &&
            ((t.lastIntValue = e % 32), t.advance(), !0)
          );
        }),
        (dt.regexp_eatHexEscapeSequence = function(t) {
          var e = t.pos;
          if (t.eat(120)) {
            if (this.regexp_eatFixedHexDigits(t, 2)) return !0;
            t.switchU && t.raise("Invalid escape"), (t.pos = e);
          }
          return !1;
        }),
        (dt.regexp_eatDecimalDigits = function(t) {
          var e = t.pos,
            i = 0;
          for (t.lastIntValue = 0; bt((i = t.current())); )
            (t.lastIntValue = 10 * t.lastIntValue + (i - 48)), t.advance();
          return t.pos !== e;
        }),
        (dt.regexp_eatHexDigits = function(t) {
          var e = t.pos,
            i = 0;
          for (t.lastIntValue = 0; _t((i = t.current())); )
            (t.lastIntValue = 16 * t.lastIntValue + kt(i)), t.advance();
          return t.pos !== e;
        }),
        (dt.regexp_eatLegacyOctalEscapeSequence = function(t) {
          if (this.regexp_eatOctalDigit(t)) {
            var e = t.lastIntValue;
            if (this.regexp_eatOctalDigit(t)) {
              var i = t.lastIntValue;
              e <= 3 && this.regexp_eatOctalDigit(t)
                ? (t.lastIntValue = 64 * e + 8 * i + t.lastIntValue)
                : (t.lastIntValue = 8 * e + i);
            } else t.lastIntValue = e;
            return !0;
          }
          return !1;
        }),
        (dt.regexp_eatOctalDigit = function(t) {
          var e = t.current();
          return St(e)
            ? ((t.lastIntValue = e - 48), t.advance(), !0)
            : ((t.lastIntValue = 0), !1);
        }),
        (dt.regexp_eatFixedHexDigits = function(t, e) {
          var i = t.pos;
          t.lastIntValue = 0;
          for (var s = 0; s < e; ++s) {
            var r = t.current();
            if (!_t(r)) return (t.pos = i), !1;
            (t.lastIntValue = 16 * t.lastIntValue + kt(r)), t.advance();
          }
          return !0;
        });
      var wt = function(t) {
          (this.type = t.type),
            (this.value = t.value),
            (this.start = t.start),
            (this.end = t.end),
            t.options.locations && (this.loc = new D(t, t.startLoc, t.endLoc)),
            t.options.ranges && (this.range = [t.start, t.end]);
        },
        Et = X.prototype;
      function At(t) {
        return t <= 65535
          ? String.fromCharCode(t)
          : ((t -= 65536),
            String.fromCharCode(55296 + (t >> 10), 56320 + (1023 & t)));
      }
      (Et.next = function() {
        this.options.onToken && this.options.onToken(new wt(this)),
          (this.lastTokEnd = this.end),
          (this.lastTokStart = this.start),
          (this.lastTokEndLoc = this.endLoc),
          (this.lastTokStartLoc = this.startLoc),
          this.nextToken();
      }),
        (Et.getToken = function() {
          return this.next(), new wt(this);
        }),
        "undefined" != typeof Symbol &&
          (Et[Symbol.iterator] = function() {
            var t = this;
            return {
              next: function() {
                var e = t.getToken();
                return { done: e.type === E.eof, value: e };
              }
            };
          }),
        (Et.curContext = function() {
          return this.context[this.context.length - 1];
        }),
        (Et.nextToken = function() {
          var t = this.curContext();
          return (
            (t && t.preserveSpace) || this.skipSpace(),
            (this.start = this.pos),
            this.options.locations && (this.startLoc = this.curPosition()),
            this.pos >= this.input.length
              ? this.finishToken(E.eof)
              : t.override
              ? t.override(this)
              : void this.readToken(this.fullCharCodeAtPos())
          );
        }),
        (Et.readToken = function(t) {
          return g(t, this.options.ecmaVersion >= 6) || 92 === t
            ? this.readWord()
            : this.getTokenFromCode(t);
        }),
        (Et.fullCharCodeAtPos = function() {
          var t = this.input.charCodeAt(this.pos);
          return t <= 55295 || t >= 57344
            ? t
            : (t << 10) + this.input.charCodeAt(this.pos + 1) - 56613888;
        }),
        (Et.skipBlockComment = function() {
          var t,
            e = this.options.onComment && this.curPosition(),
            i = this.pos,
            s = this.input.indexOf("*/", (this.pos += 2));
          if (
            (-1 === s && this.raise(this.pos - 2, "Unterminated comment"),
            (this.pos = s + 2),
            this.options.locations)
          )
            for (
              C.lastIndex = i;
              (t = C.exec(this.input)) && t.index < this.pos;

            )
              ++this.curLine, (this.lineStart = t.index + t[0].length);
          this.options.onComment &&
            this.options.onComment(
              !0,
              this.input.slice(i + 2, s),
              i,
              this.pos,
              e,
              this.curPosition()
            );
        }),
        (Et.skipLineComment = function(t) {
          for (
            var e = this.pos,
              i = this.options.onComment && this.curPosition(),
              s = this.input.charCodeAt((this.pos += t));
            this.pos < this.input.length && !I(s);

          )
            s = this.input.charCodeAt(++this.pos);
          this.options.onComment &&
            this.options.onComment(
              !1,
              this.input.slice(e + t, this.pos),
              e,
              this.pos,
              i,
              this.curPosition()
            );
        }),
        (Et.skipSpace = function() {
          t: for (; this.pos < this.input.length; ) {
            var t = this.input.charCodeAt(this.pos);
            switch (t) {
              case 32:
              case 160:
                ++this.pos;
                break;
              case 13:
                10 === this.input.charCodeAt(this.pos + 1) && ++this.pos;
              case 10:
              case 8232:
              case 8233:
                ++this.pos,
                  this.options.locations &&
                    (++this.curLine, (this.lineStart = this.pos));
                break;
              case 47:
                switch (this.input.charCodeAt(this.pos + 1)) {
                  case 42:
                    this.skipBlockComment();
                    break;
                  case 47:
                    this.skipLineComment(2);
                    break;
                  default:
                    break t;
                }
                break;
              default:
                if (
                  !(
                    (t > 8 && t < 14) ||
                    (t >= 5760 && L.test(String.fromCharCode(t)))
                  )
                )
                  break t;
                ++this.pos;
            }
          }
        }),
        (Et.finishToken = function(t, e) {
          (this.end = this.pos),
            this.options.locations && (this.endLoc = this.curPosition());
          var i = this.type;
          (this.type = t), (this.value = e), this.updateContext(i);
        }),
        (Et.readToken_dot = function() {
          var t = this.input.charCodeAt(this.pos + 1);
          if (t >= 48 && t <= 57) return this.readNumber(!0);
          var e = this.input.charCodeAt(this.pos + 2);
          return this.options.ecmaVersion >= 6 && 46 === t && 46 === e
            ? ((this.pos += 3), this.finishToken(E.ellipsis))
            : (++this.pos, this.finishToken(E.dot));
        }),
        (Et.readToken_slash = function() {
          var t = this.input.charCodeAt(this.pos + 1);
          return this.exprAllowed
            ? (++this.pos, this.readRegexp())
            : 61 === t
            ? this.finishOp(E.assign, 2)
            : this.finishOp(E.slash, 1);
        }),
        (Et.readToken_mult_modulo_exp = function(t) {
          var e = this.input.charCodeAt(this.pos + 1),
            i = 1,
            s = 42 === t ? E.star : E.modulo;
          return (
            this.options.ecmaVersion >= 7 &&
              42 === t &&
              42 === e &&
              (++i,
              (s = E.starstar),
              (e = this.input.charCodeAt(this.pos + 2))),
            61 === e ? this.finishOp(E.assign, i + 1) : this.finishOp(s, i)
          );
        }),
        (Et.readToken_pipe_amp = function(t) {
          var e = this.input.charCodeAt(this.pos + 1);
          return e === t
            ? this.finishOp(124 === t ? E.logicalOR : E.logicalAND, 2)
            : 61 === e
            ? this.finishOp(E.assign, 2)
            : this.finishOp(124 === t ? E.bitwiseOR : E.bitwiseAND, 1);
        }),
        (Et.readToken_caret = function() {
          return 61 === this.input.charCodeAt(this.pos + 1)
            ? this.finishOp(E.assign, 2)
            : this.finishOp(E.bitwiseXOR, 1);
        }),
        (Et.readToken_plus_min = function(t) {
          var e = this.input.charCodeAt(this.pos + 1);
          return e === t
            ? 45 !== e ||
              this.inModule ||
              62 !== this.input.charCodeAt(this.pos + 2) ||
              (0 !== this.lastTokEnd &&
                !A.test(this.input.slice(this.lastTokEnd, this.pos)))
              ? this.finishOp(E.incDec, 2)
              : (this.skipLineComment(3), this.skipSpace(), this.nextToken())
            : 61 === e
            ? this.finishOp(E.assign, 2)
            : this.finishOp(E.plusMin, 1);
        }),
        (Et.readToken_lt_gt = function(t) {
          var e = this.input.charCodeAt(this.pos + 1),
            i = 1;
          return e === t
            ? ((i =
                62 === t && 62 === this.input.charCodeAt(this.pos + 2) ? 3 : 2),
              61 === this.input.charCodeAt(this.pos + i)
                ? this.finishOp(E.assign, i + 1)
                : this.finishOp(E.bitShift, i))
            : 33 !== e ||
              60 !== t ||
              this.inModule ||
              45 !== this.input.charCodeAt(this.pos + 2) ||
              45 !== this.input.charCodeAt(this.pos + 3)
            ? (61 === e && (i = 2), this.finishOp(E.relational, i))
            : (this.skipLineComment(4), this.skipSpace(), this.nextToken());
        }),
        (Et.readToken_eq_excl = function(t) {
          var e = this.input.charCodeAt(this.pos + 1);
          return 61 === e
            ? this.finishOp(
                E.equality,
                61 === this.input.charCodeAt(this.pos + 2) ? 3 : 2
              )
            : 61 === t && 62 === e && this.options.ecmaVersion >= 6
            ? ((this.pos += 2), this.finishToken(E.arrow))
            : this.finishOp(61 === t ? E.eq : E.prefix, 1);
        }),
        (Et.getTokenFromCode = function(t) {
          switch (t) {
            case 46:
              return this.readToken_dot();
            case 40:
              return ++this.pos, this.finishToken(E.parenL);
            case 41:
              return ++this.pos, this.finishToken(E.parenR);
            case 59:
              return ++this.pos, this.finishToken(E.semi);
            case 44:
              return ++this.pos, this.finishToken(E.comma);
            case 91:
              return ++this.pos, this.finishToken(E.bracketL);
            case 93:
              return ++this.pos, this.finishToken(E.bracketR);
            case 123:
              return ++this.pos, this.finishToken(E.braceL);
            case 125:
              return ++this.pos, this.finishToken(E.braceR);
            case 58:
              return ++this.pos, this.finishToken(E.colon);
            case 63:
              return ++this.pos, this.finishToken(E.question);
            case 96:
              if (this.options.ecmaVersion < 6) break;
              return ++this.pos, this.finishToken(E.backQuote);
            case 48:
              var e = this.input.charCodeAt(this.pos + 1);
              if (120 === e || 88 === e) return this.readRadixNumber(16);
              if (this.options.ecmaVersion >= 6) {
                if (111 === e || 79 === e) return this.readRadixNumber(8);
                if (98 === e || 66 === e) return this.readRadixNumber(2);
              }
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
              return this.readNumber(!1);
            case 34:
            case 39:
              return this.readString(t);
            case 47:
              return this.readToken_slash();
            case 37:
            case 42:
              return this.readToken_mult_modulo_exp(t);
            case 124:
            case 38:
              return this.readToken_pipe_amp(t);
            case 94:
              return this.readToken_caret();
            case 43:
            case 45:
              return this.readToken_plus_min(t);
            case 60:
            case 62:
              return this.readToken_lt_gt(t);
            case 61:
            case 33:
              return this.readToken_eq_excl(t);
            case 126:
              return this.finishOp(E.prefix, 1);
          }
          this.raise(this.pos, "Unexpected character '" + At(t) + "'");
        }),
        (Et.finishOp = function(t, e) {
          var i = this.input.slice(this.pos, this.pos + e);
          return (this.pos += e), this.finishToken(t, i);
        }),
        (Et.readRegexp = function() {
          for (var t, e, i = this.pos; ; ) {
            this.pos >= this.input.length &&
              this.raise(i, "Unterminated regular expression");
            var s = this.input.charAt(this.pos);
            if (
              (A.test(s) && this.raise(i, "Unterminated regular expression"), t)
            )
              t = !1;
            else {
              if ("[" === s) e = !0;
              else if ("]" === s && e) e = !1;
              else if ("/" === s && !e) break;
              t = "\\" === s;
            }
            ++this.pos;
          }
          var r = this.input.slice(i, this.pos);
          ++this.pos;
          var n = this.pos,
            a = this.readWord1();
          this.containsEsc && this.unexpected(n);
          var o = this.regexpState || (this.regexpState = new ft(this));
          o.reset(i, r, a),
            this.validateRegExpFlags(o),
            this.validateRegExpPattern(o);
          var p = null;
          try {
            p = new RegExp(r, a);
          } catch (h) {}
          return this.finishToken(E.regexp, { pattern: r, flags: a, value: p });
        }),
        (Et.readInt = function(t, e) {
          for (
            var i = this.pos, s = 0, r = 0, n = null == e ? 1 / 0 : e;
            r < n;
            ++r
          ) {
            var a = this.input.charCodeAt(this.pos),
              o = void 0;
            if (
              (o =
                a >= 97
                  ? a - 97 + 10
                  : a >= 65
                  ? a - 65 + 10
                  : a >= 48 && a <= 57
                  ? a - 48
                  : 1 / 0) >= t
            )
              break;
            ++this.pos, (s = s * t + o);
          }
          return this.pos === i || (null != e && this.pos - i !== e) ? null : s;
        }),
        (Et.readRadixNumber = function(t) {
          this.pos += 2;
          var e = this.readInt(t);
          return (
            null == e &&
              this.raise(this.start + 2, "Expected number in radix " + t),
            g(this.fullCharCodeAtPos()) &&
              this.raise(this.pos, "Identifier directly after number"),
            this.finishToken(E.num, e)
          );
        }),
        (Et.readNumber = function(t) {
          var e = this.pos;
          t || null !== this.readInt(10) || this.raise(e, "Invalid number");
          var i = this.pos - e >= 2 && 48 === this.input.charCodeAt(e);
          i && this.strict && this.raise(e, "Invalid number"),
            i && /[89]/.test(this.input.slice(e, this.pos)) && (i = !1);
          var s = this.input.charCodeAt(this.pos);
          46 !== s ||
            i ||
            (++this.pos,
            this.readInt(10),
            (s = this.input.charCodeAt(this.pos))),
            (69 !== s && 101 !== s) ||
              i ||
              ((43 !== (s = this.input.charCodeAt(++this.pos)) && 45 !== s) ||
                ++this.pos,
              null === this.readInt(10) && this.raise(e, "Invalid number")),
            g(this.fullCharCodeAtPos()) &&
              this.raise(this.pos, "Identifier directly after number");
          var r = this.input.slice(e, this.pos),
            n = i ? parseInt(r, 8) : parseFloat(r);
          return this.finishToken(E.num, n);
        }),
        (Et.readCodePoint = function() {
          var t;
          if (123 === this.input.charCodeAt(this.pos)) {
            this.options.ecmaVersion < 6 && this.unexpected();
            var e = ++this.pos;
            (t = this.readHexChar(
              this.input.indexOf("}", this.pos) - this.pos
            )),
              ++this.pos,
              t > 1114111 &&
                this.invalidStringToken(e, "Code point out of bounds");
          } else t = this.readHexChar(4);
          return t;
        }),
        (Et.readString = function(t) {
          for (var e = "", i = ++this.pos; ; ) {
            this.pos >= this.input.length &&
              this.raise(this.start, "Unterminated string constant");
            var s = this.input.charCodeAt(this.pos);
            if (s === t) break;
            92 === s
              ? ((e += this.input.slice(i, this.pos)),
                (e += this.readEscapedChar(!1)),
                (i = this.pos))
              : (I(s, this.options.ecmaVersion >= 10) &&
                  this.raise(this.start, "Unterminated string constant"),
                ++this.pos);
          }
          return (
            (e += this.input.slice(i, this.pos++)),
            this.finishToken(E.string, e)
          );
        });
      var Ct = {};
      (Et.tryReadTemplateToken = function() {
        this.inTemplateElement = !0;
        try {
          this.readTmplToken();
        } catch (t) {
          if (t !== Ct) throw t;
          this.readInvalidTemplateToken();
        }
        this.inTemplateElement = !1;
      }),
        (Et.invalidStringToken = function(t, e) {
          if (this.inTemplateElement && this.options.ecmaVersion >= 9) throw Ct;
          this.raise(t, e);
        }),
        (Et.readTmplToken = function() {
          for (var t = "", e = this.pos; ; ) {
            this.pos >= this.input.length &&
              this.raise(this.start, "Unterminated template");
            var i = this.input.charCodeAt(this.pos);
            if (
              96 === i ||
              (36 === i && 123 === this.input.charCodeAt(this.pos + 1))
            )
              return this.pos !== this.start ||
                (this.type !== E.template && this.type !== E.invalidTemplate)
                ? ((t += this.input.slice(e, this.pos)),
                  this.finishToken(E.template, t))
                : 36 === i
                ? ((this.pos += 2), this.finishToken(E.dollarBraceL))
                : (++this.pos, this.finishToken(E.backQuote));
            if (92 === i)
              (t += this.input.slice(e, this.pos)),
                (t += this.readEscapedChar(!0)),
                (e = this.pos);
            else if (I(i)) {
              switch (((t += this.input.slice(e, this.pos)), ++this.pos, i)) {
                case 13:
                  10 === this.input.charCodeAt(this.pos) && ++this.pos;
                case 10:
                  t += "\n";
                  break;
                default:
                  t += String.fromCharCode(i);
              }
              this.options.locations &&
                (++this.curLine, (this.lineStart = this.pos)),
                (e = this.pos);
            } else ++this.pos;
          }
        }),
        (Et.readInvalidTemplateToken = function() {
          for (; this.pos < this.input.length; this.pos++)
            switch (this.input[this.pos]) {
              case "\\":
                ++this.pos;
                break;
              case "$":
                if ("{" !== this.input[this.pos + 1]) break;
              case "`":
                return this.finishToken(
                  E.invalidTemplate,
                  this.input.slice(this.start, this.pos)
                );
            }
          this.raise(this.start, "Unterminated template");
        }),
        (Et.readEscapedChar = function(t) {
          var e = this.input.charCodeAt(++this.pos);
          switch ((++this.pos, e)) {
            case 110:
              return "\n";
            case 114:
              return "\r";
            case 120:
              return String.fromCharCode(this.readHexChar(2));
            case 117:
              return At(this.readCodePoint());
            case 116:
              return "\t";
            case 98:
              return "\b";
            case 118:
              return "\v";
            case 102:
              return "\f";
            case 13:
              10 === this.input.charCodeAt(this.pos) && ++this.pos;
            case 10:
              return (
                this.options.locations &&
                  ((this.lineStart = this.pos), ++this.curLine),
                ""
              );
            default:
              if (e >= 48 && e <= 55) {
                var i = this.input.substr(this.pos - 1, 3).match(/^[0-7]+/)[0],
                  s = parseInt(i, 8);
                return (
                  s > 255 && ((i = i.slice(0, -1)), (s = parseInt(i, 8))),
                  (this.pos += i.length - 1),
                  (e = this.input.charCodeAt(this.pos)),
                  ("0" === i && 56 !== e && 57 !== e) ||
                    (!this.strict && !t) ||
                    this.invalidStringToken(
                      this.pos - 1 - i.length,
                      t
                        ? "Octal literal in template string"
                        : "Octal literal in strict mode"
                    ),
                  String.fromCharCode(s)
                );
              }
              return String.fromCharCode(e);
          }
        }),
        (Et.readHexChar = function(t) {
          var e = this.pos,
            i = this.readInt(16, t);
          return (
            null === i &&
              this.invalidStringToken(e, "Bad character escape sequence"),
            i
          );
        }),
        (Et.readWord1 = function() {
          this.containsEsc = !1;
          for (
            var t = "", e = !0, i = this.pos, s = this.options.ecmaVersion >= 6;
            this.pos < this.input.length;

          ) {
            var r = this.fullCharCodeAtPos();
            if (v(r, s)) this.pos += r <= 65535 ? 1 : 2;
            else {
              if (92 !== r) break;
              (this.containsEsc = !0), (t += this.input.slice(i, this.pos));
              var n = this.pos;
              117 !== this.input.charCodeAt(++this.pos) &&
                this.invalidStringToken(
                  this.pos,
                  "Expecting Unicode escape sequence \\uXXXX"
                ),
                ++this.pos;
              var a = this.readCodePoint();
              (e ? g : v)(a, s) ||
                this.invalidStringToken(n, "Invalid Unicode escape"),
                (t += At(a)),
                (i = this.pos);
            }
            e = !1;
          }
          return t + this.input.slice(i, this.pos);
        }),
        (Et.readWord = function() {
          var t = this.readWord1(),
            e = E.name;
          return (
            this.keywords.test(t) &&
              (this.containsEsc &&
                this.raiseRecoverable(
                  this.start,
                  "Escape sequence in keyword " + t
                ),
              (e = S[t])),
            this.finishToken(e, t)
          );
        });
      var It = Object.freeze({
          version: "6.0.2",
          parse: function(t, e) {
            return X.parse(t, e);
          },
          parseExpressionAt: function(t, e, i) {
            return X.parseExpressionAt(t, e, i);
          },
          tokenizer: function(t, e) {
            return X.tokenizer(t, e);
          },
          Parser: X,
          defaultOptions: B,
          Position: V,
          SourceLocation: D,
          getLineInfo: F,
          Node: at,
          TokenType: x,
          tokTypes: E,
          keywordTypes: S,
          TokContext: ht,
          tokContexts: ct,
          isIdentifierChar: v,
          isIdentifierStart: g,
          Token: wt,
          isNewLine: I,
          lineBreak: A,
          lineBreakG: C,
          nonASCIIwhitespace: L
        }),
        Lt = {
          quot: '"',
          amp: "&",
          apos: "'",
          lt: "<",
          gt: ">",
          nbsp: " ",
          iexcl: "¡",
          cent: "¢",
          pound: "£",
          curren: "¤",
          yen: "¥",
          brvbar: "¦",
          sect: "§",
          uml: "¨",
          copy: "©",
          ordf: "ª",
          laquo: "«",
          not: "¬",
          shy: "­",
          reg: "®",
          macr: "¯",
          deg: "°",
          plusmn: "±",
          sup2: "²",
          sup3: "³",
          acute: "´",
          micro: "µ",
          para: "¶",
          middot: "·",
          cedil: "¸",
          sup1: "¹",
          ordm: "º",
          raquo: "»",
          frac14: "¼",
          frac12: "½",
          frac34: "¾",
          iquest: "¿",
          Agrave: "À",
          Aacute: "Á",
          Acirc: "Â",
          Atilde: "Ã",
          Auml: "Ä",
          Aring: "Å",
          AElig: "Æ",
          Ccedil: "Ç",
          Egrave: "È",
          Eacute: "É",
          Ecirc: "Ê",
          Euml: "Ë",
          Igrave: "Ì",
          Iacute: "Í",
          Icirc: "Î",
          Iuml: "Ï",
          ETH: "Ð",
          Ntilde: "Ñ",
          Ograve: "Ò",
          Oacute: "Ó",
          Ocirc: "Ô",
          Otilde: "Õ",
          Ouml: "Ö",
          times: "×",
          Oslash: "Ø",
          Ugrave: "Ù",
          Uacute: "Ú",
          Ucirc: "Û",
          Uuml: "Ü",
          Yacute: "Ý",
          THORN: "Þ",
          szlig: "ß",
          agrave: "à",
          aacute: "á",
          acirc: "â",
          atilde: "ã",
          auml: "ä",
          aring: "å",
          aelig: "æ",
          ccedil: "ç",
          egrave: "è",
          eacute: "é",
          ecirc: "ê",
          euml: "ë",
          igrave: "ì",
          iacute: "í",
          icirc: "î",
          iuml: "ï",
          eth: "ð",
          ntilde: "ñ",
          ograve: "ò",
          oacute: "ó",
          ocirc: "ô",
          otilde: "õ",
          ouml: "ö",
          divide: "÷",
          oslash: "ø",
          ugrave: "ù",
          uacute: "ú",
          ucirc: "û",
          uuml: "ü",
          yacute: "ý",
          thorn: "þ",
          yuml: "ÿ",
          OElig: "Œ",
          oelig: "œ",
          Scaron: "Š",
          scaron: "š",
          Yuml: "Ÿ",
          fnof: "ƒ",
          circ: "ˆ",
          tilde: "˜",
          Alpha: "Α",
          Beta: "Β",
          Gamma: "Γ",
          Delta: "Δ",
          Epsilon: "Ε",
          Zeta: "Ζ",
          Eta: "Η",
          Theta: "Θ",
          Iota: "Ι",
          Kappa: "Κ",
          Lambda: "Λ",
          Mu: "Μ",
          Nu: "Ν",
          Xi: "Ξ",
          Omicron: "Ο",
          Pi: "Π",
          Rho: "Ρ",
          Sigma: "Σ",
          Tau: "Τ",
          Upsilon: "Υ",
          Phi: "Φ",
          Chi: "Χ",
          Psi: "Ψ",
          Omega: "Ω",
          alpha: "α",
          beta: "β",
          gamma: "γ",
          delta: "δ",
          epsilon: "ε",
          zeta: "ζ",
          eta: "η",
          theta: "θ",
          iota: "ι",
          kappa: "κ",
          lambda: "λ",
          mu: "μ",
          nu: "ν",
          xi: "ξ",
          omicron: "ο",
          pi: "π",
          rho: "ρ",
          sigmaf: "ς",
          sigma: "σ",
          tau: "τ",
          upsilon: "υ",
          phi: "φ",
          chi: "χ",
          psi: "ψ",
          omega: "ω",
          thetasym: "ϑ",
          upsih: "ϒ",
          piv: "ϖ",
          ensp: " ",
          emsp: " ",
          thinsp: " ",
          zwnj: "‌",
          zwj: "‍",
          lrm: "‎",
          rlm: "‏",
          ndash: "–",
          mdash: "—",
          lsquo: "‘",
          rsquo: "’",
          sbquo: "‚",
          ldquo: "“",
          rdquo: "”",
          bdquo: "„",
          dagger: "†",
          Dagger: "‡",
          bull: "•",
          hellip: "…",
          permil: "‰",
          prime: "′",
          Prime: "″",
          lsaquo: "‹",
          rsaquo: "›",
          oline: "‾",
          frasl: "⁄",
          euro: "€",
          image: "ℑ",
          weierp: "℘",
          real: "ℜ",
          trade: "™",
          alefsym: "ℵ",
          larr: "←",
          uarr: "↑",
          rarr: "→",
          darr: "↓",
          harr: "↔",
          crarr: "↵",
          lArr: "⇐",
          uArr: "⇑",
          rArr: "⇒",
          dArr: "⇓",
          hArr: "⇔",
          forall: "∀",
          part: "∂",
          exist: "∃",
          empty: "∅",
          nabla: "∇",
          isin: "∈",
          notin: "∉",
          ni: "∋",
          prod: "∏",
          sum: "∑",
          minus: "−",
          lowast: "∗",
          radic: "√",
          prop: "∝",
          infin: "∞",
          ang: "∠",
          and: "∧",
          or: "∨",
          cap: "∩",
          cup: "∪",
          int: "∫",
          there4: "∴",
          sim: "∼",
          cong: "≅",
          asymp: "≈",
          ne: "≠",
          equiv: "≡",
          le: "≤",
          ge: "≥",
          sub: "⊂",
          sup: "⊃",
          nsub: "⊄",
          sube: "⊆",
          supe: "⊇",
          oplus: "⊕",
          otimes: "⊗",
          perp: "⊥",
          sdot: "⋅",
          lceil: "⌈",
          rceil: "⌉",
          lfloor: "⌊",
          rfloor: "⌋",
          lang: "〈",
          rang: "〉",
          loz: "◊",
          spades: "♠",
          clubs: "♣",
          hearts: "♥",
          diams: "♦"
        },
        Pt = /^[\da-fA-F]+$/,
        Nt = /^\d+$/,
        Tt = It.tokTypes,
        Rt = It.TokContext,
        Ot = It.tokContexts,
        jt = It.TokenType,
        Vt = It.isNewLine,
        Dt = It.isIdentifierStart,
        Ft = It.isIdentifierChar,
        Bt = new Rt("<tag", !1),
        Mt = new Rt("</tag", !1),
        Ut = new Rt("<tag>...</tag>", !0, !0),
        qt = {
          jsxName: new jt("jsxName"),
          jsxText: new jt("jsxText", { beforeExpr: !0 }),
          jsxTagStart: new jt("jsxTagStart"),
          jsxTagEnd: new jt("jsxTagEnd")
        };
      function Xt(t) {
        return t
          ? "JSXIdentifier" === t.type
            ? t.name
            : "JSXNamespacedName" === t.type
            ? t.namespace.name + ":" + t.name.name
            : "JSXMemberExpression" === t.type
            ? Xt(t.object) + "." + Xt(t.property)
            : void 0
          : t;
      }
      (qt.jsxTagStart.updateContext = function() {
        this.context.push(Ut), this.context.push(Bt), (this.exprAllowed = !1);
      }),
        (qt.jsxTagEnd.updateContext = function(t) {
          var e = this.context.pop();
          (e === Bt && t === Tt.slash) || e === Mt
            ? (this.context.pop(),
              (this.exprAllowed = this.curContext() === Ut))
            : (this.exprAllowed = !0);
        });
      var Jt = function(t) {
        return (
          void 0 === t && (t = {}),
          function(e) {
            return (function(t, e) {
              return (function(e) {
                function i() {
                  e.apply(this, arguments);
                }
                return (
                  e && (i.__proto__ = e),
                  (i.prototype = Object.create(e && e.prototype)),
                  (i.prototype.constructor = i),
                  (i.prototype.jsx_readToken = function() {
                    for (var t = "", e = this.pos; ; ) {
                      this.pos >= this.input.length &&
                        this.raise(this.start, "Unterminated JSX contents");
                      var i = this.input.charCodeAt(this.pos);
                      switch (i) {
                        case 60:
                        case 123:
                          return this.pos === this.start
                            ? 60 === i && this.exprAllowed
                              ? (++this.pos, this.finishToken(qt.jsxTagStart))
                              : this.getTokenFromCode(i)
                            : ((t += this.input.slice(e, this.pos)),
                              this.finishToken(qt.jsxText, t));
                        case 38:
                          (t += this.input.slice(e, this.pos)),
                            (t += this.jsx_readEntity()),
                            (e = this.pos);
                          break;
                        default:
                          Vt(i)
                            ? ((t += this.input.slice(e, this.pos)),
                              (t += this.jsx_readNewLine(!0)),
                              (e = this.pos))
                            : ++this.pos;
                      }
                    }
                  }),
                  (i.prototype.jsx_readNewLine = function(t) {
                    var e,
                      i = this.input.charCodeAt(this.pos);
                    return (
                      ++this.pos,
                      13 === i && 10 === this.input.charCodeAt(this.pos)
                        ? (++this.pos, (e = t ? "\n" : "\r\n"))
                        : (e = String.fromCharCode(i)),
                      this.options.locations &&
                        (++this.curLine, (this.lineStart = this.pos)),
                      e
                    );
                  }),
                  (i.prototype.jsx_readString = function(t) {
                    for (var e = "", i = ++this.pos; ; ) {
                      this.pos >= this.input.length &&
                        this.raise(this.start, "Unterminated string constant");
                      var s = this.input.charCodeAt(this.pos);
                      if (s === t) break;
                      38 === s
                        ? ((e += this.input.slice(i, this.pos)),
                          (e += this.jsx_readEntity()),
                          (i = this.pos))
                        : Vt(s)
                        ? ((e += this.input.slice(i, this.pos)),
                          (e += this.jsx_readNewLine(!1)),
                          (i = this.pos))
                        : ++this.pos;
                    }
                    return (
                      (e += this.input.slice(i, this.pos++)),
                      this.finishToken(Tt.string, e)
                    );
                  }),
                  (i.prototype.jsx_readEntity = function() {
                    var t,
                      e = "",
                      i = 0,
                      s = this.input[this.pos];
                    "&" !== s &&
                      this.raise(
                        this.pos,
                        "Entity must start with an ampersand"
                      );
                    for (
                      var r = ++this.pos;
                      this.pos < this.input.length && i++ < 10;

                    ) {
                      if (";" === (s = this.input[this.pos++])) {
                        "#" === e[0]
                          ? "x" === e[1]
                            ? ((e = e.substr(2)),
                              Pt.test(e) &&
                                (t = String.fromCharCode(parseInt(e, 16))))
                            : ((e = e.substr(1)),
                              Nt.test(e) &&
                                (t = String.fromCharCode(parseInt(e, 10))))
                          : (t = Lt[e]);
                        break;
                      }
                      e += s;
                    }
                    return t || ((this.pos = r), "&");
                  }),
                  (i.prototype.jsx_readWord = function() {
                    var t,
                      e = this.pos;
                    do {
                      t = this.input.charCodeAt(++this.pos);
                    } while (Ft(t) || 45 === t);
                    return this.finishToken(
                      qt.jsxName,
                      this.input.slice(e, this.pos)
                    );
                  }),
                  (i.prototype.jsx_parseIdentifier = function() {
                    var t = this.startNode();
                    return (
                      this.type === qt.jsxName
                        ? (t.name = this.value)
                        : this.type.keyword
                        ? (t.name = this.type.keyword)
                        : this.unexpected(),
                      this.next(),
                      this.finishNode(t, "JSXIdentifier")
                    );
                  }),
                  (i.prototype.jsx_parseNamespacedName = function() {
                    var e = this.start,
                      i = this.startLoc,
                      s = this.jsx_parseIdentifier();
                    if (!t.allowNamespaces || !this.eat(Tt.colon)) return s;
                    var r = this.startNodeAt(e, i);
                    return (
                      (r.namespace = s),
                      (r.name = this.jsx_parseIdentifier()),
                      this.finishNode(r, "JSXNamespacedName")
                    );
                  }),
                  (i.prototype.jsx_parseElementName = function() {
                    if (this.type === qt.jsxTagEnd) return "";
                    var e = this.start,
                      i = this.startLoc,
                      s = this.jsx_parseNamespacedName();
                    for (
                      this.type !== Tt.dot ||
                      "JSXNamespacedName" !== s.type ||
                      t.allowNamespacedObjects ||
                      this.unexpected();
                      this.eat(Tt.dot);

                    ) {
                      var r = this.startNodeAt(e, i);
                      (r.object = s),
                        (r.property = this.jsx_parseIdentifier()),
                        (s = this.finishNode(r, "JSXMemberExpression"));
                    }
                    return s;
                  }),
                  (i.prototype.jsx_parseAttributeValue = function() {
                    switch (this.type) {
                      case Tt.braceL:
                        var t = this.jsx_parseExpressionContainer();
                        return (
                          "JSXEmptyExpression" === t.expression.type &&
                            this.raise(
                              t.start,
                              "JSX attributes must only be assigned a non-empty expression"
                            ),
                          t
                        );
                      case qt.jsxTagStart:
                      case Tt.string:
                        return this.parseExprAtom();
                      default:
                        this.raise(
                          this.start,
                          "JSX value should be either an expression or a quoted JSX text"
                        );
                    }
                  }),
                  (i.prototype.jsx_parseEmptyExpression = function() {
                    var t = this.startNodeAt(
                      this.lastTokEnd,
                      this.lastTokEndLoc
                    );
                    return this.finishNodeAt(
                      t,
                      "JSXEmptyExpression",
                      this.start,
                      this.startLoc
                    );
                  }),
                  (i.prototype.jsx_parseExpressionContainer = function() {
                    var t = this.startNode();
                    return (
                      this.next(),
                      (t.expression =
                        this.type === Tt.braceR
                          ? this.jsx_parseEmptyExpression()
                          : this.parseExpression()),
                      this.expect(Tt.braceR),
                      this.finishNode(t, "JSXExpressionContainer")
                    );
                  }),
                  (i.prototype.jsx_parseAttribute = function() {
                    var t = this.startNode();
                    return this.eat(Tt.braceL)
                      ? (this.expect(Tt.ellipsis),
                        (t.argument = this.parseMaybeAssign()),
                        this.expect(Tt.braceR),
                        this.finishNode(t, "JSXSpreadAttribute"))
                      : ((t.name = this.jsx_parseNamespacedName()),
                        (t.value = this.eat(Tt.eq)
                          ? this.jsx_parseAttributeValue()
                          : null),
                        this.finishNode(t, "JSXAttribute"));
                  }),
                  (i.prototype.jsx_parseOpeningElementAt = function(t, e) {
                    var i = this.startNodeAt(t, e);
                    i.attributes = [];
                    var s = this.jsx_parseElementName();
                    for (
                      s && (i.name = s);
                      this.type !== Tt.slash && this.type !== qt.jsxTagEnd;

                    )
                      i.attributes.push(this.jsx_parseAttribute());
                    return (
                      (i.selfClosing = this.eat(Tt.slash)),
                      this.expect(qt.jsxTagEnd),
                      this.finishNode(
                        i,
                        s ? "JSXOpeningElement" : "JSXOpeningFragment"
                      )
                    );
                  }),
                  (i.prototype.jsx_parseClosingElementAt = function(t, e) {
                    var i = this.startNodeAt(t, e),
                      s = this.jsx_parseElementName();
                    return (
                      s && (i.name = s),
                      this.expect(qt.jsxTagEnd),
                      this.finishNode(
                        i,
                        s ? "JSXClosingElement" : "JSXClosingFragment"
                      )
                    );
                  }),
                  (i.prototype.jsx_parseElementAt = function(t, e) {
                    var i = this.startNodeAt(t, e),
                      s = [],
                      r = this.jsx_parseOpeningElementAt(t, e),
                      n = null;
                    if (!r.selfClosing) {
                      t: for (;;)
                        switch (this.type) {
                          case qt.jsxTagStart:
                            if (
                              ((t = this.start),
                              (e = this.startLoc),
                              this.next(),
                              this.eat(Tt.slash))
                            ) {
                              n = this.jsx_parseClosingElementAt(t, e);
                              break t;
                            }
                            s.push(this.jsx_parseElementAt(t, e));
                            break;
                          case qt.jsxText:
                            s.push(this.parseExprAtom());
                            break;
                          case Tt.braceL:
                            s.push(this.jsx_parseExpressionContainer());
                            break;
                          default:
                            this.unexpected();
                        }
                      Xt(n.name) !== Xt(r.name) &&
                        this.raise(
                          n.start,
                          "Expected corresponding JSX closing tag for <" +
                            Xt(r.name) +
                            ">"
                        );
                    }
                    var a = r.name ? "Element" : "Fragment";
                    return (
                      (i["opening" + a] = r),
                      (i["closing" + a] = n),
                      (i.children = s),
                      this.type === Tt.relational &&
                        "<" === this.value &&
                        this.raise(
                          this.start,
                          "Adjacent JSX elements must be wrapped in an enclosing tag"
                        ),
                      this.finishNode(i, "JSX" + a)
                    );
                  }),
                  (i.prototype.jsx_parseText = function(t) {
                    var e = this.parseLiteral(t);
                    return (e.type = "JSXText"), e;
                  }),
                  (i.prototype.jsx_parseElement = function() {
                    var t = this.start,
                      e = this.startLoc;
                    return this.next(), this.jsx_parseElementAt(t, e);
                  }),
                  (i.prototype.parseExprAtom = function(t) {
                    return this.type === qt.jsxText
                      ? this.jsx_parseText(this.value)
                      : this.type === qt.jsxTagStart
                      ? this.jsx_parseElement()
                      : e.prototype.parseExprAtom.call(this, t);
                  }),
                  (i.prototype.readToken = function(t) {
                    var i = this.curContext();
                    if (i === Ut) return this.jsx_readToken();
                    if (i === Bt || i === Mt) {
                      if (Dt(t)) return this.jsx_readWord();
                      if (62 == t)
                        return ++this.pos, this.finishToken(qt.jsxTagEnd);
                      if ((34 === t || 39 === t) && i == Bt)
                        return this.jsx_readString(t);
                    }
                    return 60 === t &&
                      this.exprAllowed &&
                      33 !== this.input.charCodeAt(this.pos + 1)
                      ? (++this.pos, this.finishToken(qt.jsxTagStart))
                      : e.prototype.readToken.call(this, t);
                  }),
                  (i.prototype.updateContext = function(t) {
                    if (this.type == Tt.braceL) {
                      var i = this.curContext();
                      i == Bt
                        ? this.context.push(Ot.b_expr)
                        : i == Ut
                        ? this.context.push(Ot.b_tmpl)
                        : e.prototype.updateContext.call(this, t),
                        (this.exprAllowed = !0);
                    } else {
                      if (this.type !== Tt.slash || t !== qt.jsxTagStart)
                        return e.prototype.updateContext.call(this, t);
                      (this.context.length -= 2),
                        this.context.push(Mt),
                        (this.exprAllowed = !1);
                    }
                  }),
                  i
                );
              })(e);
            })(
              {
                allowNamespaces: !1 !== t.allowNamespaces,
                allowNamespacedObjects: !!t.allowNamespacedObjects
              },
              e
            );
          }
        );
      };
      Jt.tokTypes = qt;
      var Wt,
        Ht = (function(t, e) {
          return t((e = { exports: {} }), e.exports), e.exports;
        })(function(t, e) {
          Object.defineProperty(e, "__esModule", { value: !0 }),
            (e.DynamicImportKey = void 0);
          var i = (function() {
              function t(t, e) {
                for (var i = 0; i < e.length; i++) {
                  var s = e[i];
                  (s.enumerable = s.enumerable || !1),
                    (s.configurable = !0),
                    "value" in s && (s.writable = !0),
                    Object.defineProperty(t, s.key, s);
                }
              }
              return function(e, i, s) {
                return i && t(e.prototype, i), s && t(e, s), e;
              };
            })(),
            s = function t(e, i, s) {
              null === e && (e = Function.prototype);
              var r = Object.getOwnPropertyDescriptor(e, i);
              if (void 0 === r) {
                var n = Object.getPrototypeOf(e);
                return null === n ? void 0 : t(n, i, s);
              }
              if ("value" in r) return r.value;
              var a = r.get;
              return void 0 !== a ? a.call(s) : void 0;
            };
          function r(t, e) {
            if (!(t instanceof e))
              throw new TypeError("Cannot call a class as a function");
          }
          function n(t, e) {
            if (!t)
              throw new ReferenceError(
                "this hasn't been initialised - super() hasn't been called"
              );
            return !e || ("object" != typeof e && "function" != typeof e)
              ? t
              : e;
          }
          e.default = function(t) {
            return (function(t) {
              function e() {
                return (
                  r(this, e),
                  n(
                    this,
                    (e.__proto__ || Object.getPrototypeOf(e)).apply(
                      this,
                      arguments
                    )
                  )
                );
              }
              return (
                (function(t, e) {
                  if ("function" != typeof e && null !== e)
                    throw new TypeError(
                      "Super expression must either be null or a function, not " +
                        typeof e
                    );
                  (t.prototype = Object.create(e && e.prototype, {
                    constructor: {
                      value: t,
                      enumerable: !1,
                      writable: !0,
                      configurable: !0
                    }
                  })),
                    e &&
                      (Object.setPrototypeOf
                        ? Object.setPrototypeOf(t, e)
                        : (t.__proto__ = e));
                })(e, t),
                i(e, [
                  {
                    key: "parseStatement",
                    value: function(t, i, r) {
                      return this.type === It.tokTypes._import && p.call(this)
                        ? this.parseExpressionStatement(
                            this.startNode(),
                            this.parseExpression()
                          )
                        : s(
                            e.prototype.__proto__ ||
                              Object.getPrototypeOf(e.prototype),
                            "parseStatement",
                            this
                          ).call(this, t, i, r);
                    }
                  },
                  {
                    key: "parseExprAtom",
                    value: function(t) {
                      return this.type === It.tokTypes._import
                        ? o.call(this)
                        : s(
                            e.prototype.__proto__ ||
                              Object.getPrototypeOf(e.prototype),
                            "parseExprAtom",
                            this
                          ).call(this, t);
                    }
                  }
                ]),
                e
              );
            })(t);
          };
          var a = (e.DynamicImportKey = "Import");
          function o() {
            var t = this.startNode();
            return (
              this.next(),
              this.type !== It.tokTypes.parenL && this.unexpected(),
              this.finishNode(t, a)
            );
          }
          function p() {
            return /^(\s|\/\/.*|\/\*[^]*?\*\/)*\(/.test(
              this.input.slice(this.pos)
            );
          }
          It.tokTypes._import.startsExpr = !0;
        }),
        zt =
          (Wt = Ht) &&
          Wt.__esModule &&
          Object.prototype.hasOwnProperty.call(Wt, "default")
            ? Wt.default
            : Wt;
      Ht.DynamicImportKey;
      function Gt(t) {
        var e = {};
        return (
          Object.keys(t).forEach(function(i) {
            "parent" !== i &&
              "program" !== i &&
              "keys" !== i &&
              "__wrapped" !== i &&
              (Array.isArray(t[i])
                ? (e[i] = t[i].map(Gt))
                : t[i] && t[i].toJSON
                ? (e[i] = t[i].toJSON())
                : (e[i] = t[i]));
          }),
          e
        );
      }
      var Qt = function() {};
      function Kt(t) {
        var e = [];
        return $t[t.type](e, t), e;
      }
      (Qt.prototype.ancestor = function(t) {
        for (var e = this; t--; ) if (!(e = e.parent)) return null;
        return e;
      }),
        (Qt.prototype.contains = function(t) {
          for (; t; ) {
            if (t === this) return !0;
            t = t.parent;
          }
          return !1;
        }),
        (Qt.prototype.findLexicalBoundary = function() {
          return this.parent.findLexicalBoundary();
        }),
        (Qt.prototype.findNearest = function(t) {
          return (
            "string" == typeof t && (t = new RegExp("^" + t + "$")),
            t.test(this.type) ? this : this.parent.findNearest(t)
          );
        }),
        (Qt.prototype.unparenthesizedParent = function() {
          for (var t = this.parent; t && "ParenthesizedExpression" === t.type; )
            t = t.parent;
          return t;
        }),
        (Qt.prototype.unparenthesize = function() {
          for (var t = this; "ParenthesizedExpression" === t.type; )
            t = t.expression;
          return t;
        }),
        (Qt.prototype.findScope = function(t) {
          return this.parent.findScope(t);
        }),
        (Qt.prototype.getIndentation = function() {
          return this.parent.getIndentation();
        }),
        (Qt.prototype.initialise = function(t) {
          for (var e = 0, i = this.keys; e < i.length; e += 1) {
            var s = this[i[e]];
            Array.isArray(s)
              ? s.forEach(function(e) {
                  return e && e.initialise(t);
                })
              : s && "object" == typeof s && s.initialise(t);
          }
        }),
        (Qt.prototype.toJSON = function() {
          return Gt(this);
        }),
        (Qt.prototype.toString = function() {
          return this.program.magicString.original.slice(this.start, this.end);
        }),
        (Qt.prototype.transpile = function(t, e) {
          for (var i = 0, s = this.keys; i < s.length; i += 1) {
            var r = this[s[i]];
            Array.isArray(r)
              ? r.forEach(function(i) {
                  return i && i.transpile(t, e);
                })
              : r && "object" == typeof r && r.transpile(t, e);
          }
        });
      var $t = {
          Identifier: function(t, e) {
            t.push(e);
          },
          ObjectPattern: function(t, e) {
            for (var i = 0, s = e.properties; i < s.length; i += 1) {
              var r = s[i];
              $t[r.type](t, r);
            }
          },
          Property: function(t, e) {
            $t[e.value.type](t, e.value);
          },
          ArrayPattern: function(t, e) {
            for (var i = 0, s = e.elements; i < s.length; i += 1) {
              var r = s[i];
              r && $t[r.type](t, r);
            }
          },
          RestElement: function(t, e) {
            $t[e.argument.type](t, e.argument);
          },
          AssignmentPattern: function(t, e) {
            $t[e.left.type](t, e.left);
          }
        },
        Yt = Object.create(null);
      function Zt(t) {
        (t = t || {}),
          (this.parent = t.parent),
          (this.isBlockScope = !!t.block),
          (this.createDeclarationCallback = t.declare);
        for (var e = this; e.isBlockScope; ) e = e.parent;
        (this.functionScope = e),
          (this.identifiers = []),
          (this.declarations = Object.create(null)),
          (this.references = Object.create(null)),
          (this.blockScopedDeclarations = this.isBlockScope
            ? null
            : Object.create(null)),
          (this.aliases = Object.create(null));
      }
      function te(t, e) {
        var i,
          s = t.split("\n"),
          r = s.length,
          n = 0;
        for (i = 0; i < r; i += 1) {
          var a = n + s[i].length + 1;
          if (a > e) return { line: i + 1, column: e - n, char: i };
          n = a;
        }
        throw new Error("Could not determine location of character");
      }
      function ee(t, e) {
        for (var i = ""; e--; ) i += t;
        return i;
      }
      function ie(t, e, i) {
        void 0 === i && (i = 1);
        var s = Math.max(e.line - 5, 0),
          r = e.line,
          n = String(r).length,
          a = t.split("\n").slice(s, r),
          o = a[a.length - 1].slice(0, e.column).replace(/\t/g, "  ").length,
          p = a
            .map(function(t, e) {
              return (
                (i = n),
                (r = String(e + s + 1)) +
                  ee(" ", i - r.length) +
                  " : " +
                  t.replace(/\t/g, "  ")
              );
              var i, r;
            })
            .join("\n");
        return (p += "\n" + ee(" ", n + 3 + o) + ee("^", i));
      }
      "do if in for let new try var case else enum eval null this true void with await break catch class const false super throw while yield delete export import public return static switch typeof default extends finally package private continue debugger function arguments interface protected implements instanceof"
        .split(" ")
        .forEach(function(t) {
          return (Yt[t] = !0);
        }),
        (Zt.prototype = {
          addDeclaration: function(t, e) {
            for (var i = 0, s = Kt(t); i < s.length; i += 1) {
              var r = s[i],
                n = r.name,
                a = { name: n, node: r, kind: e, instances: [] };
              (this.declarations[n] = a),
                this.isBlockScope &&
                  (this.functionScope.blockScopedDeclarations[n] ||
                    (this.functionScope.blockScopedDeclarations[n] = []),
                  this.functionScope.blockScopedDeclarations[n].push(a));
            }
          },
          addReference: function(t) {
            this.consolidated
              ? this.consolidateReference(t)
              : this.identifiers.push(t);
          },
          consolidate: function() {
            for (var t = 0; t < this.identifiers.length; t += 1) {
              var e = this.identifiers[t];
              this.consolidateReference(e);
            }
            this.consolidated = !0;
          },
          consolidateReference: function(t) {
            var e = this.declarations[t.name];
            e
              ? e.instances.push(t)
              : ((this.references[t.name] = !0),
                this.parent && this.parent.addReference(t));
          },
          contains: function(t) {
            return (
              this.declarations[t] || (!!this.parent && this.parent.contains(t))
            );
          },
          createIdentifier: function(t) {
            "number" == typeof t && (t = t.toString());
            for (
              var e = (t = t
                  .replace(/\s/g, "")
                  .replace(/\[([^\]]+)\]/g, "_$1")
                  .replace(/[^a-zA-Z0-9_$]/g, "_")
                  .replace(/_{2,}/, "_")),
                i = 1;
              this.declarations[e] ||
              this.references[e] ||
              this.aliases[e] ||
              e in Yt;

            )
              e = t + "$" + i++;
            return (this.aliases[e] = !0), e;
          },
          createDeclaration: function(t) {
            var e = this.createIdentifier(t);
            return this.createDeclarationCallback(e), e;
          },
          findDeclaration: function(t) {
            return (
              this.declarations[t] ||
              (this.parent && this.parent.findDeclaration(t))
            );
          },
          resolveName: function(t) {
            var e = this.findDeclaration(t);
            return e ? e.name : t;
          }
        });
      var se = (function(t) {
        function e(e, i) {
          if ((t.call(this, e), (this.name = "CompileError"), i)) {
            var s = i.program.magicString.original,
              r = te(s, i.start);
            (this.message = e + " (" + r.line + ":" + r.column + ")"),
              (this.stack = new t().stack.replace(
                new RegExp(".+new " + this.name + ".+\\n", "m"),
                ""
              )),
              (this.loc = r),
              (this.snippet = ie(s, r, i.end - i.start));
          }
        }
        return (
          t && (e.__proto__ = t),
          (e.prototype = Object.create(t && t.prototype)),
          (e.prototype.constructor = e),
          (e.prototype.toString = function() {
            return this.name + ": " + this.message + "\n" + this.snippet;
          }),
          e
        );
      })(Error);
      function re(t, e) {
        for (var i = 0; i < t.length; i += 1) if (e(t[i], i)) return i;
        return -1;
      }
      var ne = {
        Identifier: oe,
        AssignmentPattern: function(t, e, i, s, r, n, a) {
          var o = "Identifier" === s.left.type,
            p = o ? s.left.name : r;
          n ||
            a.push(function(e, i, r) {
              t.prependRight(
                s.left.end,
                i + "if ( " + p + " === void 0 ) " + p
              ),
                t.move(s.left.end, s.right.end, e),
                t.appendLeft(s.right.end, r);
            });
          o || ae(t, e, i, s.left, r, n, a);
        },
        ArrayPattern: function(t, e, i, s, r, n, a) {
          var o = s.start;
          s.elements.forEach(function(s, p) {
            s &&
              ("RestElement" === s.type
                ? he(t, e, i, o, s.argument, r + ".slice(" + p + ")", n, a)
                : he(t, e, i, o, s, r + "[" + p + "]", n, a),
              (o = s.end));
          }),
            t.remove(o, s.end);
        },
        ObjectPattern: pe
      };
      function ae(t, e, i, s, r, n, a) {
        ne[s.type](t, e, i, s, r, n, a);
      }
      function oe(t, e, i, s, r, n, a) {
        a.push(function(e, a, o) {
          t.overwrite(
            s.start,
            s.end,
            (n ? a : a + "var ") + i(s) + " = " + r + o
          ),
            t.move(s.start, s.end, e);
        });
      }
      function pe(t, e, i, s, r, n, a) {
        var o = this,
          p = s.start,
          h = [];
        s.properties.forEach(function(s) {
          var c, l;
          if ("Property" === s.type) {
            var u = s.computed || "Identifier" !== s.key.type,
              d = u ? t.slice(s.key.start, s.key.end) : s.key.name;
            (c = u ? r + "[" + d + "]" : r + "." + d),
              (l = s.value),
              h.push(u ? d : '"' + d + '"');
          } else {
            if ("RestElement" !== s.type)
              throw new se(
                o,
                "Unexpected node of type " + s.type + " in object pattern"
              );
            (l = s.argument),
              (c = e("rest")),
              a.push(function(e, i, a) {
                var o = s.program.getObjectWithoutPropertiesHelper(t);
                t.overwrite(
                  s.start,
                  (p = s.argument.start),
                  (n ? i : i + "var ") +
                    c +
                    " = " +
                    o +
                    "( " +
                    r +
                    ", [" +
                    h.join(", ") +
                    "] )" +
                    a
                ),
                  t.move(s.start, p, e);
              });
          }
          he(t, e, i, p, l, c, n, a), (p = s.end);
        }),
          t.remove(p, s.end);
      }
      function he(t, e, i, s, r, n, a, o) {
        switch (r.type) {
          case "Identifier":
            t.remove(s, r.start), oe(t, 0, i, r, n, a, o);
            break;
          case "MemberExpression":
            t.remove(s, r.start),
              (function(t, e, i, s, r, n, a) {
                a.push(function(e, i, a) {
                  t.prependRight(s.start, n ? i : i + "var "),
                    t.appendLeft(s.end, " = " + r + a),
                    t.move(s.start, s.end, e);
                });
              })(t, 0, 0, r, n, !0, o);
            break;
          case "AssignmentPattern":
            var p,
              h = "Identifier" === r.left.type;
            (p = h ? i(r.left) : e(n)),
              o.push(function(e, i, s) {
                a
                  ? (t.prependRight(
                      r.right.start,
                      p + " = " + n + ", " + p + " = " + p + " === void 0 ? "
                    ),
                    t.appendLeft(r.right.end, " : " + p + s))
                  : (t.prependRight(
                      r.right.start,
                      i +
                        "var " +
                        p +
                        " = " +
                        n +
                        "; if ( " +
                        p +
                        " === void 0 ) " +
                        p +
                        " = "
                    ),
                    t.appendLeft(r.right.end, s)),
                  t.move(r.right.start, r.right.end, e);
              }),
              h
                ? t.remove(s, r.right.start)
                : (t.remove(s, r.left.start),
                  t.remove(r.left.end, r.right.start),
                  he(t, e, i, s, r.left, p, a, o));
            break;
          case "ObjectPattern":
            t.remove(s, (s = r.start));
            var c = n;
            r.properties.length > 1 &&
              ((c = e(n)),
              o.push(function(e, i, o) {
                t.prependRight(r.start, (a ? "" : i + "var ") + c + " = "),
                  t.overwrite(r.start, (s = r.start + 1), n),
                  t.appendLeft(s, o),
                  t.overwrite(
                    r.start,
                    (s = r.start + 1),
                    (a ? "" : i + "var ") + c + " = " + n + o
                  ),
                  t.move(r.start, s, e);
              })),
              pe(t, e, i, r, c, a, o);
            break;
          case "ArrayPattern":
            if (
              (t.remove(s, (s = r.start)),
              r.elements.filter(Boolean).length > 1)
            ) {
              var l = e(n);
              o.push(function(e, i, o) {
                t.prependRight(r.start, (a ? "" : i + "var ") + l + " = "),
                  t.overwrite(r.start, (s = r.start + 1), n, {
                    contentOnly: !0
                  }),
                  t.appendLeft(s, o),
                  t.move(r.start, s, e);
              }),
                r.elements.forEach(function(r, n) {
                  r &&
                    ("RestElement" === r.type
                      ? he(
                          t,
                          e,
                          i,
                          s,
                          r.argument,
                          l + ".slice(" + n + ")",
                          a,
                          o
                        )
                      : he(t, e, i, s, r, l + "[" + n + "]", a, o),
                    (s = r.end));
                });
            } else {
              var u = re(r.elements, Boolean),
                d = r.elements[u];
              "RestElement" === d.type
                ? he(t, e, i, s, d.argument, n + ".slice(" + u + ")", a, o)
                : he(t, e, i, s, d, n + "[" + u + "]", a, o),
                (s = d.end);
            }
            t.remove(s, r.end);
            break;
          default:
            throw new Error(
              "Unexpected node type in destructuring (" + r.type + ")"
            );
        }
      }
      var ce = (function(t) {
        function e() {
          t.apply(this, arguments);
        }
        return (
          t && (e.__proto__ = t),
          (e.prototype = Object.create(t && t.prototype)),
          (e.prototype.constructor = e),
          (e.prototype.createScope = function() {
            var t = this;
            (this.parentIsFunction = /Function/.test(this.parent.type)),
              (this.isFunctionBlock =
                this.parentIsFunction || "Root" === this.parent.type),
              (this.scope = new Zt({
                block: !this.isFunctionBlock,
                parent: this.parent.findScope(!1),
                declare: function(e) {
                  return t.createdDeclarations.push(e);
                }
              })),
              this.parentIsFunction &&
                this.parent.params.forEach(function(e) {
                  t.scope.addDeclaration(e, "param");
                });
          }),
          (e.prototype.initialise = function(t) {
            (this.thisAlias = null),
              (this.argumentsAlias = null),
              (this.defaultParameters = []),
              (this.createdDeclarations = []),
              this.scope || this.createScope(),
              this.body.forEach(function(e) {
                return e.initialise(t);
              }),
              this.scope.consolidate();
          }),
          (e.prototype.findLexicalBoundary = function() {
            return "Program" === this.type || /^Function/.test(this.parent.type)
              ? this
              : this.parent.findLexicalBoundary();
          }),
          (e.prototype.findScope = function(t) {
            return t && !this.isFunctionBlock
              ? this.parent.findScope(t)
              : this.scope;
          }),
          (e.prototype.getArgumentsAlias = function() {
            return (
              this.argumentsAlias ||
                (this.argumentsAlias = this.scope.createIdentifier(
                  "arguments"
                )),
              this.argumentsAlias
            );
          }),
          (e.prototype.getArgumentsArrayAlias = function() {
            return (
              this.argumentsArrayAlias ||
                (this.argumentsArrayAlias = this.scope.createIdentifier(
                  "argsArray"
                )),
              this.argumentsArrayAlias
            );
          }),
          (e.prototype.getThisAlias = function() {
            return (
              this.thisAlias ||
                (this.thisAlias = this.scope.createIdentifier("this")),
              this.thisAlias
            );
          }),
          (e.prototype.getIndentation = function() {
            if (void 0 === this.indentation) {
              for (
                var t = this.program.magicString.original,
                  e = this.synthetic || !this.body.length,
                  i = e ? this.start : this.body[0].start;
                i && "\n" !== t[i];

              )
                i -= 1;
              for (this.indentation = ""; ; ) {
                var s = t[(i += 1)];
                if (" " !== s && "\t" !== s) break;
                this.indentation += s;
              }
              for (
                var r = this.program.magicString.getIndentString(),
                  n = this.parent;
                n;

              )
                "constructor" !== n.kind ||
                  n.parent.parent.superClass ||
                  (this.indentation = this.indentation.replace(r, "")),
                  (n = n.parent);
              e && (this.indentation += r);
            }
            return this.indentation;
          }),
          (e.prototype.transpile = function(e, i) {
            var s,
              r,
              n = this,
              a = this.getIndentation(),
              o = [];
            if (
              (this.argumentsAlias &&
                o.push(function(t, i, s) {
                  var r = i + "var " + n.argumentsAlias + " = arguments" + s;
                  e.appendLeft(t, r);
                }),
              this.thisAlias &&
                o.push(function(t, i, s) {
                  var r = i + "var " + n.thisAlias + " = this" + s;
                  e.appendLeft(t, r);
                }),
              this.argumentsArrayAlias &&
                o.push(function(t, i, s) {
                  var r = n.scope.createIdentifier("i"),
                    o =
                      i +
                      "var " +
                      r +
                      " = arguments.length, " +
                      n.argumentsArrayAlias +
                      " = Array(" +
                      r +
                      ");\n" +
                      a +
                      "while ( " +
                      r +
                      "-- ) " +
                      n.argumentsArrayAlias +
                      "[" +
                      r +
                      "] = arguments[" +
                      r +
                      "]" +
                      s;
                  e.appendLeft(t, o);
                }),
              /Function/.test(this.parent.type)
                ? this.transpileParameters(this.parent.params, e, i, a, o)
                : "CatchClause" === this.parent.type &&
                  this.transpileParameters([this.parent.param], e, i, a, o),
              i.letConst &&
                this.isFunctionBlock &&
                this.transpileBlockScopedIdentifiers(e),
              t.prototype.transpile.call(this, e, i),
              this.createdDeclarations.length &&
                o.push(function(t, i, s) {
                  var r = i + "var " + n.createdDeclarations.join(", ") + s;
                  e.appendLeft(t, r);
                }),
              this.synthetic)
            )
              if ("ArrowFunctionExpression" === this.parent.type) {
                var p = this.body[0];
                o.length
                  ? (e
                      .appendLeft(this.start, "{")
                      .prependRight(
                        this.end,
                        this.parent.getIndentation() + "}"
                      ),
                    e.prependRight(p.start, "\n" + a + "return "),
                    e.appendLeft(p.end, ";\n"))
                  : i.arrow &&
                    (e.prependRight(p.start, "{ return "),
                    e.appendLeft(p.end, "; }"));
              } else
                o.length &&
                  e.prependRight(this.start, "{").appendLeft(this.end, "}");
            (r = this.body[0]),
              (s =
                r &&
                "ExpressionStatement" === r.type &&
                "Literal" === r.expression.type &&
                "use strict" === r.expression.value
                  ? this.body[0].end
                  : this.synthetic || "Root" === this.parent.type
                  ? this.start
                  : this.start + 1);
            var h = "\n" + a,
              c = ";";
            o.forEach(function(t, e) {
              e === o.length - 1 && (c = ";\n"), t(s, h, c);
            });
          }),
          (e.prototype.transpileParameters = function(t, e, i, s, r) {
            var n = this;
            t.forEach(function(a) {
              if (
                "AssignmentPattern" === a.type &&
                "Identifier" === a.left.type
              )
                i.defaultParameter &&
                  r.push(function(t, i, s) {
                    var r =
                      i +
                      "if ( " +
                      a.left.name +
                      " === void 0 ) " +
                      a.left.name;
                    e.prependRight(a.left.end, r)
                      .move(a.left.end, a.right.end, t)
                      .appendLeft(a.right.end, s);
                  });
              else if ("RestElement" === a.type)
                i.spreadRest &&
                  r.push(function(i, r, o) {
                    var p = t[t.length - 2];
                    if (p) e.remove(p ? p.end : a.start, a.end);
                    else {
                      for (
                        var h = a.start, c = a.end;
                        /\s/.test(e.original[h - 1]);

                      )
                        h -= 1;
                      for (; /\s/.test(e.original[c]); ) c += 1;
                      e.remove(h, c);
                    }
                    var l = a.argument.name,
                      u = n.scope.createIdentifier("len"),
                      d = t.length - 1;
                    d
                      ? e.prependRight(
                          i,
                          r +
                            "var " +
                            l +
                            " = [], " +
                            u +
                            " = arguments.length - " +
                            d +
                            ";\n" +
                            s +
                            "while ( " +
                            u +
                            "-- > 0 ) " +
                            l +
                            "[ " +
                            u +
                            " ] = arguments[ " +
                            u +
                            " + " +
                            d +
                            " ]" +
                            o
                        )
                      : e.prependRight(
                          i,
                          r +
                            "var " +
                            l +
                            " = [], " +
                            u +
                            " = arguments.length;\n" +
                            s +
                            "while ( " +
                            u +
                            "-- ) " +
                            l +
                            "[ " +
                            u +
                            " ] = arguments[ " +
                            u +
                            " ]" +
                            o
                        );
                  });
              else if ("Identifier" !== a.type && i.parameterDestructuring) {
                var o = n.scope.createIdentifier("ref");
                ae(
                  e,
                  function(t) {
                    return n.scope.createIdentifier(t);
                  },
                  function(t) {
                    var e = t.name;
                    return n.scope.resolveName(e);
                  },
                  a,
                  o,
                  !1,
                  r
                ),
                  e.prependRight(a.start, o);
              }
            });
          }),
          (e.prototype.transpileBlockScopedIdentifiers = function(t) {
            var e = this;
            Object.keys(this.scope.blockScopedDeclarations).forEach(function(
              i
            ) {
              for (
                var s = 0, r = e.scope.blockScopedDeclarations[i];
                s < r.length;
                s += 1
              ) {
                var n = r[s],
                  a = !1;
                if ("for.let" === n.kind) {
                  var o = n.node.findNearest("ForStatement");
                  if (o.shouldRewriteAsFunction) {
                    var p = e.scope.createIdentifier(i),
                      h = o.reassigned[i] ? e.scope.createIdentifier(i) : i;
                    (n.name = p),
                      t.overwrite(n.node.start, n.node.end, p, {
                        storeName: !0
                      }),
                      (o.aliases[i] = { outer: p, inner: h });
                    for (var c = 0, l = n.instances; c < l.length; c += 1) {
                      var u = l[c],
                        d = o.body.contains(u) ? h : p;
                      i !== d &&
                        t.overwrite(u.start, u.end, d, { storeName: !0 });
                    }
                    a = !0;
                  }
                }
                if (!a) {
                  var f = e.scope.createIdentifier(i);
                  if (i !== f) {
                    (n.name = f),
                      t.overwrite(n.node.start, n.node.end, f, {
                        storeName: !0
                      });
                    for (var m = 0, y = n.instances; m < y.length; m += 1) {
                      var g = y[m];
                      (g.rewritten = !0),
                        t.overwrite(g.start, g.end, f, { storeName: !0 });
                    }
                  }
                }
              }
            });
          }),
          e
        );
      })(Qt);
      function le(t) {
        return "Identifier" === t.type && "arguments" === t.name;
      }
      function ue(t, e, i, s, r) {
        for (var n = e.length, a = -1; n--; ) {
          var o = e[n];
          o &&
            "SpreadElement" === o.type &&
            (le(o.argument) && t.overwrite(o.argument.start, o.argument.end, s),
            (a = n));
        }
        if (-1 === a) return !1;
        if (r) {
          for (n = 0; n < e.length; n += 1) {
            var p = e[n];
            "SpreadElement" === p.type
              ? t.remove(p.start, p.argument.start)
              : (t.prependRight(p.start, "["), t.prependRight(p.end, "]"));
          }
          return !0;
        }
        var h = e[a],
          c = e[a - 1];
        for (
          c
            ? t.overwrite(c.end, h.start, " ].concat( ")
            : (t.remove(i, h.start),
              t.overwrite(h.end, e[1].start, ".concat( ")),
            n = a;
          n < e.length;
          n += 1
        )
          (h = e[n]) &&
            ("SpreadElement" === h.type
              ? t.remove(h.start, h.argument.start)
              : (t.appendLeft(h.start, "["), t.appendLeft(h.end, "]")));
        return !0;
      }
      var de = (function(t) {
        function e() {
          t.apply(this, arguments);
        }
        return (
          t && (e.__proto__ = t),
          (e.prototype = Object.create(t && t.prototype)),
          (e.prototype.constructor = e),
          (e.prototype.initialise = function(e) {
            if (e.spreadRest && this.elements.length)
              for (
                var i = this.findLexicalBoundary(), s = this.elements.length;
                s--;

              ) {
                var r = this.elements[s];
                r &&
                  "SpreadElement" === r.type &&
                  le(r.argument) &&
                  (this.argumentsArrayAlias = i.getArgumentsArrayAlias());
              }
            t.prototype.initialise.call(this, e);
          }),
          (e.prototype.transpile = function(e, i) {
            if ((t.prototype.transpile.call(this, e, i), i.spreadRest)) {
              if (this.elements.length) {
                var s = this.elements[this.elements.length - 1];
                s &&
                  /\s*,/.test(e.original.slice(s.end, this.end)) &&
                  e.overwrite(s.end, this.end - 1, " ");
              }
              if (1 === this.elements.length) {
                var r = this.elements[0];
                r &&
                  "SpreadElement" === r.type &&
                  (le(r.argument)
                    ? e.overwrite(
                        this.start,
                        this.end,
                        "[].concat( " + this.argumentsArrayAlias + " )"
                      )
                    : (e.overwrite(this.start, r.argument.start, "[].concat( "),
                      e.overwrite(r.end, this.end, " )")));
              } else {
                ue(e, this.elements, this.start, this.argumentsArrayAlias) &&
                  e.overwrite(this.end - 1, this.end, ")");
              }
            }
          }),
          e
        );
      })(Qt);
      function fe(t, e) {
        for (; ")" !== t.original[e]; ) {
          if ("," === t.original[e]) return void t.remove(e, e + 1);
          "/" === t.original[e] &&
            (e =
              t.original.indexOf("/" === t.original[e + 1] ? "\n" : "*/", e) +
              1),
            (e += 1);
        }
      }
      var me = (function(t) {
        function e() {
          t.apply(this, arguments);
        }
        return (
          t && (e.__proto__ = t),
          (e.prototype = Object.create(t && t.prototype)),
          (e.prototype.constructor = e),
          (e.prototype.initialise = function(e) {
            this.body.createScope(), t.prototype.initialise.call(this, e);
          }),
          (e.prototype.transpile = function(e, i) {
            var s =
              1 === this.params.length && this.start === this.params[0].start;
            if (i.arrow || this.needsArguments(i)) {
              for (var r = this.body.start; "=" !== e.original[r]; ) r -= 1;
              e.remove(r, this.body.start),
                t.prototype.transpile.call(this, e, i),
                s &&
                  (e.prependRight(this.params[0].start, "("),
                  e.appendLeft(this.params[0].end, ")")),
                this.parent && "ExpressionStatement" === this.parent.type
                  ? e.prependRight(this.start, "!function")
                  : e.prependRight(this.start, "function ");
            } else t.prototype.transpile.call(this, e, i);
            i.trailingFunctionCommas &&
              this.params.length &&
              !s &&
              fe(e, this.params[this.params.length - 1].end);
          }),
          (e.prototype.needsArguments = function(t) {
            return (
              t.spreadRest &&
              this.params.filter(function(t) {
                return "RestElement" === t.type;
              }).length > 0
            );
          }),
          e
        );
      })(Qt);
      function ye(t, e) {
        var i = e.findDeclaration(t.name);
        if (i && "const" === i.kind) throw new se(t.name + " is read-only", t);
      }
      var ge = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.initialise = function(e) {
              if ("Identifier" === this.left.type) {
                var i = this.findScope(!1).findDeclaration(this.left.name),
                  s = i && i.node.ancestor(3);
                s &&
                  "ForStatement" === s.type &&
                  s.body.contains(this) &&
                  (s.reassigned[this.left.name] = !0);
              }
              t.prototype.initialise.call(this, e);
            }),
            (e.prototype.transpile = function(e, i) {
              "Identifier" === this.left.type &&
                ye(this.left, this.findScope(!1)),
                "**=" === this.operator && i.exponentiation
                  ? this.transpileExponentiation(e, i)
                  : /Pattern/.test(this.left.type) &&
                    i.destructuring &&
                    this.transpileDestructuring(e),
                t.prototype.transpile.call(this, e, i);
            }),
            (e.prototype.transpileDestructuring = function(t) {
              var e = this,
                i = this.findScope(!0),
                s = this.findScope(!1),
                r = i.createDeclaration("assign");
              t.appendRight(this.left.end, "(" + r),
                t.appendLeft(this.right.end, ", ");
              var n = [];
              ae(
                t,
                function(t) {
                  return i.createDeclaration(t);
                },
                function(t) {
                  var e = s.resolveName(t.name);
                  return ye(t, s), e;
                },
                this.left,
                r,
                !0,
                n
              );
              var a = ", ";
              n.forEach(function(t, i) {
                i === n.length - 1 && (a = ""), t(e.end, "", a);
              }),
                "ExpressionStatement" === this.unparenthesizedParent().type
                  ? t.prependRight(this.end, ")")
                  : t.appendRight(this.end, ", " + r + ")");
            }),
            (e.prototype.transpileExponentiation = function(t) {
              for (
                var e, i = this.findScope(!1), s = this.left.end;
                "*" !== t.original[s];

              )
                s += 1;
              t.remove(s, s + 2);
              var r = this.left.unparenthesize();
              if ("Identifier" === r.type) e = i.resolveName(r.name);
              else if ("MemberExpression" === r.type) {
                var n,
                  a,
                  o = !1,
                  p = !1,
                  h = this.findNearest(/(?:Statement|Declaration)$/),
                  c = h.getIndentation();
                "Identifier" === r.property.type
                  ? (a = r.computed
                      ? i.resolveName(r.property.name)
                      : r.property.name)
                  : ((a = i.createDeclaration("property")), (p = !0)),
                  "Identifier" === r.object.type
                    ? (n = i.resolveName(r.object.name))
                    : ((n = i.createDeclaration("object")), (o = !0)),
                  r.start === h.start
                    ? o && p
                      ? (t.prependRight(h.start, n + " = "),
                        t.overwrite(
                          r.object.end,
                          r.property.start,
                          ";\n" + c + a + " = "
                        ),
                        t.overwrite(
                          r.property.end,
                          r.end,
                          ";\n" + c + n + "[" + a + "]"
                        ))
                      : o
                      ? (t.prependRight(h.start, n + " = "),
                        t.appendLeft(r.object.end, ";\n" + c),
                        t.appendLeft(r.object.end, n))
                      : p &&
                        (t.prependRight(r.property.start, a + " = "),
                        t.appendLeft(r.property.end, ";\n" + c),
                        t.move(r.property.start, r.property.end, this.start),
                        t.appendLeft(r.object.end, "[" + a + "]"),
                        t.remove(r.object.end, r.property.start),
                        t.remove(r.property.end, r.end))
                    : (o && p
                        ? (t.prependRight(r.start, "( " + n + " = "),
                          t.overwrite(
                            r.object.end,
                            r.property.start,
                            ", " + a + " = "
                          ),
                          t.overwrite(
                            r.property.end,
                            r.end,
                            ", " + n + "[" + a + "]"
                          ))
                        : o
                        ? (t.prependRight(r.start, "( " + n + " = "),
                          t.appendLeft(r.object.end, ", " + n))
                        : p &&
                          (t.prependRight(r.property.start, "( " + a + " = "),
                          t.appendLeft(r.property.end, ", "),
                          t.move(r.property.start, r.property.end, r.start),
                          t.overwrite(
                            r.object.end,
                            r.property.start,
                            "[" + a + "]"
                          ),
                          t.remove(r.property.end, r.end)),
                      p && t.appendLeft(this.end, " )")),
                  (e = n + (r.computed || p ? "[" + a + "]" : "." + a));
              }
              t.prependRight(this.right.start, "Math.pow( " + e + ", "),
                t.appendLeft(this.right.end, " )");
            }),
            e
          );
        })(Qt),
        ve = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.transpile = function(e, i) {
              "**" === this.operator &&
                i.exponentiation &&
                (e.prependRight(this.start, "Math.pow( "),
                e.overwrite(this.left.end, this.right.start, ", "),
                e.appendLeft(this.end, " )")),
                t.prototype.transpile.call(this, e, i);
            }),
            e
          );
        })(Qt),
        xe = /(?:For(?:In|Of)?|While)Statement/,
        be = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.initialise = function() {
              var t = this.findNearest(xe),
                e = this.findNearest("SwitchCase");
              t &&
                (!e || t.depth > e.depth) &&
                ((t.canBreak = !0), (this.loop = t));
            }),
            (e.prototype.transpile = function(t) {
              if (this.loop && this.loop.shouldRewriteAsFunction) {
                if (this.label)
                  throw new se(
                    "Labels are not currently supported in a loop with locally-scoped variables",
                    this
                  );
                t.overwrite(this.start, this.start + 5, "return 'break'");
              }
            }),
            e
          );
        })(Qt),
        _e = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.initialise = function(e) {
              if (e.spreadRest && this.arguments.length > 1)
                for (
                  var i = this.findLexicalBoundary(), s = this.arguments.length;
                  s--;

                ) {
                  var r = this.arguments[s];
                  "SpreadElement" === r.type &&
                    le(r.argument) &&
                    (this.argumentsArrayAlias = i.getArgumentsArrayAlias());
                }
              t.prototype.initialise.call(this, e);
            }),
            (e.prototype.transpile = function(e, i) {
              if (i.spreadRest && this.arguments.length) {
                var s,
                  r = !1,
                  n = this.arguments[0];
                if (
                  (1 === this.arguments.length
                    ? "SpreadElement" === n.type &&
                      (e.remove(n.start, n.argument.start), (r = !0))
                    : (r = ue(
                        e,
                        this.arguments,
                        n.start,
                        this.argumentsArrayAlias
                      )),
                  r)
                ) {
                  var a = null;
                  if (
                    ("Super" === this.callee.type
                      ? (a = this.callee)
                      : "MemberExpression" === this.callee.type &&
                        "Super" === this.callee.object.type &&
                        (a = this.callee.object),
                    a || "MemberExpression" !== this.callee.type)
                  )
                    s = "void 0";
                  else if ("Identifier" === this.callee.object.type)
                    s = this.callee.object.name;
                  else {
                    s = this.findScope(!0).createDeclaration("ref");
                    var o = this.callee.object;
                    e.prependRight(o.start, "(" + s + " = "),
                      e.appendLeft(o.end, ")");
                  }
                  e.appendLeft(this.callee.end, ".apply"),
                    a
                      ? ((a.noCall = !0),
                        this.arguments.length > 1 &&
                          ("SpreadElement" !== n.type &&
                            e.prependRight(n.start, "[ "),
                          e.appendLeft(
                            this.arguments[this.arguments.length - 1].end,
                            " )"
                          )))
                      : 1 === this.arguments.length
                      ? e.prependRight(n.start, s + ", ")
                      : ("SpreadElement" === n.type
                          ? e.appendLeft(n.start, s + ", ")
                          : e.appendLeft(n.start, s + ", [ "),
                        e.appendLeft(
                          this.arguments[this.arguments.length - 1].end,
                          " )"
                        ));
                }
              }
              i.trailingFunctionCommas &&
                this.arguments.length &&
                fe(e, this.arguments[this.arguments.length - 1].end),
                t.prototype.transpile.call(this, e, i);
            }),
            e
          );
        })(Qt),
        ke = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.transpile = function(e, i, s, r) {
              var n = this;
              if (i.classes) {
                var a = this.parent.name,
                  o = e.getIndentString(),
                  p = this.getIndentation() + (s ? o : ""),
                  h = p + o,
                  c = re(this.body, function(t) {
                    return "constructor" === t.kind;
                  }),
                  l = this.body[c],
                  u = "",
                  d = "";
                if (
                  (this.body.length
                    ? (e.remove(this.start, this.body[0].start),
                      e.remove(this.body[this.body.length - 1].end, this.end))
                    : e.remove(this.start, this.end),
                  l)
                ) {
                  l.value.body.isConstructorBody = !0;
                  var f = this.body[c - 1],
                    m = this.body[c + 1];
                  c > 0 &&
                    (e.remove(f.end, l.start),
                    e.move(
                      l.start,
                      m ? m.start : this.end - 1,
                      this.body[0].start
                    )),
                    s || e.appendLeft(l.end, ";");
                }
                var y = !1 !== this.program.options.namedFunctionExpressions,
                  g =
                    y ||
                    this.parent.superClass ||
                    "ClassDeclaration" !== this.parent.type;
                if (this.parent.superClass) {
                  var v =
                    "if ( " +
                    r +
                    " ) " +
                    a +
                    ".__proto__ = " +
                    r +
                    ";\n" +
                    p +
                    a +
                    ".prototype = Object.create( " +
                    r +
                    " && " +
                    r +
                    ".prototype );\n" +
                    p +
                    a +
                    ".prototype.constructor = " +
                    a +
                    ";";
                  if (l) u += "\n\n" + p + v;
                  else
                    u +=
                      (v =
                        "function " +
                        a +
                        " () {" +
                        (r
                          ? "\n" +
                            h +
                            r +
                            ".apply(this, arguments);\n" +
                            p +
                            "}"
                          : "}") +
                        (s ? "" : ";") +
                        (this.body.length ? "\n\n" + p : "") +
                        v) +
                      "\n\n" +
                      p;
                } else if (!l) {
                  var x = "function " + (g ? a + " " : "") + "() {}";
                  "ClassDeclaration" === this.parent.type && (x += ";"),
                    this.body.length && (x += "\n\n" + p),
                    (u += x);
                }
                var b,
                  _,
                  k = this.findScope(!1),
                  S = [],
                  w = [];
                if (
                  (this.body.forEach(function(t, s) {
                    if (
                      ("get" === t.kind || "set" === t.kind) &&
                      i.getterSetter
                    )
                      throw new se(
                        "getters and setters are not supported. Use `transforms: { getterSetter: false }` to skip transformation and disable this error",
                        t
                      );
                    if ("constructor" !== t.kind) {
                      if (t.static) {
                        var r = " " == e.original[t.start + 6] ? 7 : 6;
                        e.remove(t.start, t.start + r);
                      }
                      var o,
                        h = "method" !== t.kind,
                        l = t.key.name;
                      (Yt[l] || t.value.body.scope.references[l]) &&
                        (l = k.createIdentifier(l));
                      var u = !1;
                      if (
                        (t.computed ||
                          "Literal" !== t.key.type ||
                          ((u = !0), (t.computed = !0)),
                        h)
                      ) {
                        if (t.computed)
                          throw new Error(
                            "Computed accessor properties are not currently supported"
                          );
                        e.remove(t.start, t.key.start),
                          t.static
                            ? (~w.indexOf(t.key.name) || w.push(t.key.name),
                              _ || (_ = k.createIdentifier("staticAccessors")),
                              (o = "" + _))
                            : (~S.indexOf(t.key.name) || S.push(t.key.name),
                              b ||
                                (b = k.createIdentifier("prototypeAccessors")),
                              (o = "" + b));
                      } else o = t.static ? "" + a : a + ".prototype";
                      t.computed || (o += "."),
                        ((c > 0 && s === c + 1) ||
                          (0 === s && c === n.body.length - 1)) &&
                          (o = "\n\n" + p + o);
                      var d = t.key.end;
                      if (t.computed)
                        if (u)
                          e.prependRight(t.key.start, "["),
                            e.appendLeft(t.key.end, "]");
                        else {
                          for (; "]" !== e.original[d]; ) d += 1;
                          d += 1;
                        }
                      var f = t.computed || h || !y ? "" : l + " ",
                        m =
                          (h ? "." + t.kind : "") +
                          " = function" +
                          (t.value.generator ? "* " : " ") +
                          f;
                      e.remove(d, t.value.start),
                        e.prependRight(t.value.start, m),
                        e.appendLeft(t.end, ";"),
                        t.value.generator && e.remove(t.start, t.key.start),
                        e.prependRight(t.start, o);
                    } else {
                      var v = g ? " " + a : "";
                      e.overwrite(t.key.start, t.key.end, "function" + v);
                    }
                  }),
                  S.length || w.length)
                ) {
                  var E = [],
                    A = [];
                  S.length &&
                    (E.push(
                      "var " +
                        b +
                        " = { " +
                        S.map(function(t) {
                          return t + ": { configurable: true }";
                        }).join(",") +
                        " };"
                    ),
                    A.push(
                      "Object.defineProperties( " +
                        a +
                        ".prototype, " +
                        b +
                        " );"
                    )),
                    w.length &&
                      (E.push(
                        "var " +
                          _ +
                          " = { " +
                          w
                            .map(function(t) {
                              return t + ": { configurable: true }";
                            })
                            .join(",") +
                          " };"
                      ),
                      A.push(
                        "Object.defineProperties( " + a + ", " + _ + " );"
                      )),
                    l && (u += "\n\n" + p),
                    (u += E.join("\n" + p)),
                    l || (u += "\n\n" + p),
                    (d += "\n\n" + p + A.join("\n" + p));
                }
                l ? e.appendLeft(l.end, u) : e.prependRight(this.start, u),
                  e.appendLeft(this.end, d);
              }
              t.prototype.transpile.call(this, e, i);
            }),
            e
          );
        })(Qt);
      var Se = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.initialise = function(e) {
              this.id
                ? ((this.name = this.id.name),
                  this.findScope(!0).addDeclaration(this.id, "class"))
                : (this.name = this.findScope(!0).createIdentifier(
                    "defaultExport"
                  )),
                t.prototype.initialise.call(this, e);
            }),
            (e.prototype.transpile = function(t, e) {
              if (e.classes) {
                this.superClass ||
                  (function(t, e) {
                    var i = t.start,
                      s = t.end,
                      r = e.getIndentString(),
                      n = r.length,
                      a = i - n;
                    t.program.indentExclusions[a] ||
                      e.original.slice(a, i) !== r ||
                      e.remove(a, i);
                    for (
                      var o,
                        p = new RegExp(r + "\\S", "g"),
                        h = e.original.slice(i, s);
                      (o = p.exec(h));

                    ) {
                      var c = i + o.index;
                      t.program.indentExclusions[c] || e.remove(c, c + n);
                    }
                  })(this.body, t);
                var i =
                    this.superClass && (this.superClass.name || "superclass"),
                  s = this.getIndentation(),
                  r = s + t.getIndentString(),
                  n = "ExportDefaultDeclaration" === this.parent.type;
                n && t.remove(this.parent.start, this.start);
                var a = this.start;
                this.id
                  ? (t.overwrite(a, this.id.start, "var "), (a = this.id.end))
                  : t.prependLeft(a, "var " + this.name),
                  this.superClass
                    ? this.superClass.end === this.body.start
                      ? (t.remove(a, this.superClass.start),
                        t.appendLeft(
                          a,
                          " = /*@__PURE__*/(function (" + i + ") {\n" + r
                        ))
                      : (t.overwrite(a, this.superClass.start, " = "),
                        t.overwrite(
                          this.superClass.end,
                          this.body.start,
                          "/*@__PURE__*/(function (" + i + ") {\n" + r
                        ))
                    : a === this.body.start
                    ? t.appendLeft(a, " = ")
                    : t.overwrite(a, this.body.start, " = "),
                  this.body.transpile(t, e, !!this.superClass, i);
                var o = n
                  ? "\n\n" + s + "export default " + this.name + ";"
                  : "";
                this.superClass
                  ? (t.appendLeft(
                      this.end,
                      "\n\n" + r + "return " + this.name + ";\n" + s + "}("
                    ),
                    t.move(
                      this.superClass.start,
                      this.superClass.end,
                      this.end
                    ),
                    t.prependRight(this.end, "));" + o))
                  : o && t.prependRight(this.end, o);
              } else this.body.transpile(t, e, !1, null);
            }),
            e
          );
        })(Qt),
        we = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.initialise = function(e) {
              (this.name =
                (this.id
                  ? this.id.name
                  : "VariableDeclarator" === this.parent.type
                  ? this.parent.id.name
                  : "AssignmentExpression" !== this.parent.type
                  ? null
                  : "Identifier" === this.parent.left.type
                  ? this.parent.left.name
                  : "MemberExpression" === this.parent.left.type
                  ? this.parent.left.property.name
                  : null) || this.findScope(!0).createIdentifier("anonymous")),
                t.prototype.initialise.call(this, e);
            }),
            (e.prototype.transpile = function(t, e) {
              if (e.classes) {
                var i =
                    this.superClass && (this.superClass.name || "superclass"),
                  s = this.getIndentation(),
                  r = s + t.getIndentString();
                this.superClass
                  ? (t.remove(this.start, this.superClass.start),
                    t.remove(this.superClass.end, this.body.start),
                    t.appendRight(
                      this.start,
                      "/*@__PURE__*/(function (" + i + ") {\n" + r
                    ))
                  : t.overwrite(
                      this.start,
                      this.body.start,
                      "/*@__PURE__*/(function () {\n" + r
                    ),
                  this.body.transpile(t, e, !0, i);
                var n = "";
                this.superClass &&
                  ((n = t.slice(this.superClass.start, this.superClass.end)),
                  t.remove(this.superClass.start, this.superClass.end)),
                  t.appendLeft(
                    this.end,
                    "\n\n" +
                      r +
                      "return " +
                      this.name +
                      ";\n" +
                      s +
                      "}(" +
                      n +
                      "))"
                  );
              } else this.body.transpile(t, e, !1);
            }),
            e
          );
        })(Qt),
        Ee = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.transpile = function(t) {
              if (this.findNearest(xe).shouldRewriteAsFunction) {
                if (this.label)
                  throw new se(
                    "Labels are not currently supported in a loop with locally-scoped variables",
                    this
                  );
                t.overwrite(this.start, this.start + 8, "return");
              }
            }),
            e
          );
        })(Qt),
        Ae = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.initialise = function(e) {
              if (e.moduleExport) throw new se("export is not supported", this);
              t.prototype.initialise.call(this, e);
            }),
            e
          );
        })(Qt),
        Ce = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.initialise = function(e) {
              if (e.moduleExport) throw new se("export is not supported", this);
              t.prototype.initialise.call(this, e);
            }),
            e
          );
        })(Qt),
        Ie = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.findScope = function(t) {
              return t || !this.createdScope
                ? this.parent.findScope(t)
                : this.body.scope;
            }),
            (e.prototype.initialise = function(e) {
              if (
                (this.body.createScope(),
                (this.createdScope = !0),
                (this.reassigned = Object.create(null)),
                (this.aliases = Object.create(null)),
                (this.thisRefs = []),
                t.prototype.initialise.call(this, e),
                e.letConst)
              )
                for (
                  var i = Object.keys(this.body.scope.declarations),
                    s = i.length;
                  s--;

                ) {
                  for (
                    var r = i[s],
                      n = this.body.scope.declarations[r],
                      a = n.instances.length;
                    a--;

                  ) {
                    var o = n.instances[a].findNearest(/Function/);
                    if (o && o.depth > this.depth) {
                      this.shouldRewriteAsFunction = !0;
                      for (var p = 0, h = this.thisRefs; p < h.length; p += 1) {
                        var c = h[p];
                        c.alias =
                          c.alias || c.findLexicalBoundary().getThisAlias();
                      }
                      break;
                    }
                  }
                  if (this.shouldRewriteAsFunction) break;
                }
            }),
            (e.prototype.transpile = function(e, i) {
              var s =
                "ForOfStatement" != this.type &&
                ("BlockStatement" !== this.body.type ||
                  ("BlockStatement" === this.body.type && this.body.synthetic));
              if (this.shouldRewriteAsFunction) {
                var r = this.getIndentation(),
                  n = r + e.getIndentString(),
                  a = this.args ? " " + this.args.join(", ") + " " : "",
                  o = this.params ? " " + this.params.join(", ") + " " : "",
                  p = this.findScope(!0),
                  h = p.createIdentifier("loop"),
                  c =
                    "var " +
                    h +
                    " = function (" +
                    o +
                    ") " +
                    (this.body.synthetic
                      ? "{\n" + r + e.getIndentString()
                      : ""),
                  l = (this.body.synthetic ? "\n" + r + "}" : "") + ";\n\n" + r;
                if (
                  (e.prependRight(this.body.start, c),
                  e.appendLeft(this.body.end, l),
                  e.move(this.start, this.body.start, this.body.end),
                  this.canBreak || this.canReturn)
                ) {
                  var u = p.createIdentifier("returned"),
                    d = "{\n" + n + "var " + u + " = " + h + "(" + a + ");\n";
                  this.canBreak &&
                    (d += "\n" + n + "if ( " + u + " === 'break' ) break;"),
                    this.canReturn &&
                      (d += "\n" + n + "if ( " + u + " ) return " + u + ".v;"),
                    (d += "\n" + r + "}"),
                    e.prependRight(this.body.end, d);
                } else {
                  var f = h + "(" + a + ");";
                  "DoWhileStatement" === this.type
                    ? e.overwrite(
                        this.start,
                        this.body.start,
                        "do {\n" + n + f + "\n" + r + "}"
                      )
                    : e.prependRight(this.body.end, f);
                }
              } else
                s &&
                  (e.appendLeft(this.body.start, "{ "),
                  e.prependRight(this.body.end, " }"));
              t.prototype.transpile.call(this, e, i);
            }),
            e
          );
        })(Qt),
        Le = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.findScope = function(t) {
              return t || !this.createdScope
                ? this.parent.findScope(t)
                : this.body.scope;
            }),
            (e.prototype.transpile = function(e, i) {
              var s = this,
                r = this.getIndentation() + e.getIndentString();
              if (this.shouldRewriteAsFunction) {
                var n =
                    "VariableDeclaration" === this.init.type
                      ? this.init.declarations.map(function(t) {
                          return Kt(t.id);
                        })
                      : [],
                  a = this.aliases;
                (this.args = n.map(function(t) {
                  return t in s.aliases ? s.aliases[t].outer : t;
                })),
                  (this.params = n.map(function(t) {
                    return t in s.aliases ? s.aliases[t].inner : t;
                  }));
                var o = Object.keys(this.reassigned).map(function(t) {
                  return a[t].outer + " = " + a[t].inner + ";";
                });
                if (o.length)
                  if (this.body.synthetic)
                    e.appendLeft(this.body.body[0].end, "; " + o.join(" "));
                  else {
                    var p = this.body.body[this.body.body.length - 1];
                    e.appendLeft(p.end, "\n\n" + r + o.join("\n" + r));
                  }
              }
              t.prototype.transpile.call(this, e, i);
            }),
            e
          );
        })(Ie),
        Pe = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.findScope = function(t) {
              return t || !this.createdScope
                ? this.parent.findScope(t)
                : this.body.scope;
            }),
            (e.prototype.transpile = function(e, i) {
              var s = this,
                r = "VariableDeclaration" === this.left.type;
              if (this.shouldRewriteAsFunction) {
                var n = r
                  ? this.left.declarations.map(function(t) {
                      return Kt(t.id);
                    })
                  : [];
                (this.args = n.map(function(t) {
                  return t in s.aliases ? s.aliases[t].outer : t;
                })),
                  (this.params = n.map(function(t) {
                    return t in s.aliases ? s.aliases[t].inner : t;
                  }));
              }
              t.prototype.transpile.call(this, e, i);
              var a = r ? this.left.declarations[0].id : this.left;
              "Identifier" !== a.type && this.destructurePattern(e, a, r);
            }),
            (e.prototype.destructurePattern = function(t, e, i) {
              var s = this.findScope(!0),
                r = this.getIndentation() + t.getIndentString(),
                n = s.createIdentifier("ref"),
                a = this.body.body.length
                  ? this.body.body[0].start
                  : this.body.start + 1;
              t.move(e.start, e.end, a),
                t.prependRight(e.end, i ? n : "var " + n);
              var o = [];
              ae(
                t,
                function(t) {
                  return s.createIdentifier(t);
                },
                function(t) {
                  var e = t.name;
                  return s.resolveName(e);
                },
                e,
                n,
                !1,
                o
              );
              var p = ";\n" + r;
              o.forEach(function(t, e) {
                e === o.length - 1 && (p = ";\n\n" + r), t(a, "", p);
              });
            }),
            e
          );
        })(Ie),
        Ne = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.initialise = function(e) {
              if (e.forOf && !e.dangerousForOf)
                throw new se(
                  "for...of statements are not supported. Use `transforms: { forOf: false }` to skip transformation and disable this error, or `transforms: { dangerousForOf: true }` if you know what you're doing",
                  this
                );
              t.prototype.initialise.call(this, e);
            }),
            (e.prototype.transpile = function(e, i) {
              if ((t.prototype.transpile.call(this, e, i), i.dangerousForOf))
                if (this.body.body[0]) {
                  var s = this.findScope(!0),
                    r = this.getIndentation(),
                    n = r + e.getIndentString(),
                    a = s.createIdentifier("i"),
                    o = s.createIdentifier("list");
                  this.body.synthetic &&
                    (e.prependRight(this.left.start, "{\n" + n),
                    e.appendLeft(this.body.body[0].end, "\n" + r + "}"));
                  var p = this.body.body[0].start;
                  e.remove(this.left.end, this.right.start),
                    e.move(this.left.start, this.left.end, p),
                    e.prependRight(
                      this.right.start,
                      "var " + a + " = 0, " + o + " = "
                    ),
                    e.appendLeft(
                      this.right.end,
                      "; " + a + " < " + o + ".length; " + a + " += 1"
                    );
                  var h = "VariableDeclaration" === this.left.type,
                    c = h ? this.left.declarations[0].id : this.left;
                  if ("Identifier" !== c.type) {
                    var l = [],
                      u = s.createIdentifier("ref");
                    ae(
                      e,
                      function(t) {
                        return s.createIdentifier(t);
                      },
                      function(t) {
                        var e = t.name;
                        return s.resolveName(e);
                      },
                      c,
                      u,
                      !h,
                      l
                    );
                    var d = ";\n" + n;
                    l.forEach(function(t, e) {
                      e === l.length - 1 && (d = ";\n\n" + n), t(p, "", d);
                    }),
                      h
                        ? (e.appendLeft(
                            this.left.start + this.left.kind.length + 1,
                            u
                          ),
                          e.appendLeft(
                            this.left.end,
                            " = " + o + "[" + a + "];\n" + n
                          ))
                        : e.appendLeft(
                            this.left.end,
                            "var " + u + " = " + o + "[" + a + "];\n" + n
                          );
                  } else
                    e.appendLeft(
                      this.left.end,
                      " = " + o + "[" + a + "];\n\n" + n
                    );
                } else
                  "VariableDeclaration" === this.left.type &&
                  "var" === this.left.kind
                    ? (e.remove(this.start, this.left.start),
                      e.appendLeft(this.left.end, ";"),
                      e.remove(this.left.end, this.end))
                    : e.remove(this.start, this.end);
            }),
            e
          );
        })(Ie),
        Te = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.initialise = function(e) {
              if (this.generator && e.generator)
                throw new se("Generators are not supported", this);
              this.body.createScope(),
                this.id &&
                  this.findScope(!0).addDeclaration(this.id, "function"),
                t.prototype.initialise.call(this, e);
            }),
            (e.prototype.transpile = function(e, i) {
              t.prototype.transpile.call(this, e, i),
                i.trailingFunctionCommas &&
                  this.params.length &&
                  fe(e, this.params[this.params.length - 1].end);
            }),
            e
          );
        })(Qt),
        Re = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.initialise = function(e) {
              if (this.generator && e.generator)
                throw new se("Generators are not supported", this);
              this.body.createScope(),
                this.id && this.body.scope.addDeclaration(this.id, "function"),
                t.prototype.initialise.call(this, e);
              var i,
                s = this.parent;
              if (
                ((e.conciseMethodProperty &&
                  "Property" === s.type &&
                  "init" === s.kind &&
                  s.method &&
                  "Identifier" === s.key.type) ||
                (e.classes &&
                  "MethodDefinition" === s.type &&
                  "method" === s.kind &&
                  "Identifier" === s.key.type)
                  ? (i = s.key.name)
                  : this.id &&
                    "Identifier" === this.id.type &&
                    (i = this.id.alias || this.id.name),
                i)
              )
                for (var r = 0, n = this.params; r < n.length; r += 1) {
                  var a = n[r];
                  if ("Identifier" === a.type && i === a.name) {
                    var o = this.body.scope,
                      p = o.declarations[i],
                      h = o.createIdentifier(i);
                    a.alias = h;
                    for (var c = 0, l = p.instances; c < l.length; c += 1) {
                      l[c].alias = h;
                    }
                    break;
                  }
                }
            }),
            (e.prototype.transpile = function(e, i) {
              t.prototype.transpile.call(this, e, i),
                i.trailingFunctionCommas &&
                  this.params.length &&
                  fe(e, this.params[this.params.length - 1].end);
            }),
            e
          );
        })(Qt);
      var Oe = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.findScope = function(t) {
              return (this.parent.params &&
                ~this.parent.params.indexOf(this)) ||
                ("FunctionExpression" === this.parent.type &&
                  this === this.parent.id)
                ? this.parent.body.scope
                : this.parent.findScope(t);
            }),
            (e.prototype.initialise = function(t) {
              if (
                (function t(e, i) {
                  return "MemberExpression" === e.type
                    ? !e.computed && t(e.object, e)
                    : "Identifier" === e.type
                    ? !i ||
                      (!/(Function|Class)Expression/.test(i.type) &&
                        ("VariableDeclarator" === i.type
                          ? e === i.init
                          : "MemberExpression" === i.type ||
                            "MethodDefinition" === i.type
                          ? i.computed || e === i.object
                          : "ArrayPattern" !== i.type &&
                            ("Property" === i.type
                              ? "ObjectPattern" !== i.parent.type &&
                                (i.computed || e === i.value)
                              : "MethodDefinition" !== i.type &&
                                ("ExportSpecifier" !== i.type ||
                                  e === i.local))))
                    : void 0;
                })(this, this.parent)
              ) {
                if (
                  t.arrow &&
                  "arguments" === this.name &&
                  !this.findScope(!1).contains(this.name)
                ) {
                  var e = this.findLexicalBoundary(),
                    i = this.findNearest("ArrowFunctionExpression"),
                    s = this.findNearest(xe);
                  i &&
                    i.depth > e.depth &&
                    (this.alias = e.getArgumentsAlias()),
                    s &&
                      s.body.contains(this) &&
                      s.depth > e.depth &&
                      (this.alias = e.getArgumentsAlias());
                }
                this.findScope(!1).addReference(this);
              }
            }),
            (e.prototype.transpile = function(t) {
              this.alias &&
                t.overwrite(this.start, this.end, this.alias, {
                  storeName: !0,
                  contentOnly: !0
                });
            }),
            e
          );
        })(Qt),
        je = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.initialise = function(e) {
              t.prototype.initialise.call(this, e);
            }),
            (e.prototype.transpile = function(e, i) {
              ("BlockStatement" !== this.consequent.type ||
                ("BlockStatement" === this.consequent.type &&
                  this.consequent.synthetic)) &&
                (e.appendLeft(this.consequent.start, "{ "),
                e.prependRight(this.consequent.end, " }")),
                this.alternate &&
                  "IfStatement" !== this.alternate.type &&
                  ("BlockStatement" !== this.alternate.type ||
                    ("BlockStatement" === this.alternate.type &&
                      this.alternate.synthetic)) &&
                  (e.appendLeft(this.alternate.start, "{ "),
                  e.prependRight(this.alternate.end, " }")),
                t.prototype.transpile.call(this, e, i);
            }),
            e
          );
        })(Qt),
        Ve = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.initialise = function(e) {
              if (e.moduleImport) throw new se("import is not supported", this);
              t.prototype.initialise.call(this, e);
            }),
            e
          );
        })(Qt),
        De = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.initialise = function(e) {
              this.findScope(!0).addDeclaration(this.local, "import"),
                t.prototype.initialise.call(this, e);
            }),
            e
          );
        })(Qt),
        Fe = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.initialise = function(e) {
              this.findScope(!0).addDeclaration(this.local, "import"),
                t.prototype.initialise.call(this, e);
            }),
            e
          );
        })(Qt),
        Be = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.transpile = function(e, i) {
              var s,
                r = this.name,
                n = r.start,
                a = r.name,
                o = this.value ? this.value.start : this.name.end;
              e.overwrite(
                n,
                o,
                (/-/.test((s = a)) ? "'" + s + "'" : s) +
                  ": " +
                  (this.value ? "" : "true")
              ),
                t.prototype.transpile.call(this, e, i);
            }),
            e
          );
        })(Qt);
      var Me = (function(t) {
        function e() {
          t.apply(this, arguments);
        }
        return (
          t && (e.__proto__ = t),
          (e.prototype = Object.create(t && t.prototype)),
          (e.prototype.constructor = e),
          (e.prototype.transpile = function(t) {
            var e,
              i = !0,
              s = this.parent.children[this.parent.children.length - 1];
            ((s &&
              "JSXText" === (e = s).type &&
                !/\S/.test(e.value) &&
                /\n/.test(e.value)) ||
              this.parent.openingElement.attributes.length) &&
              (i = !1),
              t.overwrite(this.start, this.end, i ? " )" : ")");
          }),
          e
        );
      })(Qt);
      var Ue = (function(t) {
        function e() {
          t.apply(this, arguments);
        }
        return (
          t && (e.__proto__ = t),
          (e.prototype = Object.create(t && t.prototype)),
          (e.prototype.constructor = e),
          (e.prototype.transpile = function(t) {
            var e,
              i = !0,
              s = this.parent.children[this.parent.children.length - 1];
            s &&
              "JSXText" === (e = s).type &&
                !/\S/.test(e.value) &&
                /\n/.test(e.value) &&
              (i = !1),
              t.overwrite(this.start, this.end, i ? " )" : ")");
          }),
          e
        );
      })(Qt);
      function qe(t, e) {
        return (
          (t = t.replace(/\u00a0/g, "&nbsp;")),
          e && /\n/.test(t) && (t = t.replace(/\s+$/, "")),
          (t = t.replace(/^\n\r?\s+/, "").replace(/\s*\n\r?\s*/gm, " ")),
          JSON.stringify(t)
        );
      }
      var Xe = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.transpile = function(e, i) {
              t.prototype.transpile.call(this, e, i);
              var s = this.children.filter(function(t) {
                return (
                  "JSXText" !== t.type || /\S/.test(t.raw) || !/\n/.test(t.raw)
                );
              });
              if (s.length) {
                var r,
                  n = (this.openingElement || this.openingFragment).end;
                for (r = 0; r < s.length; r += 1) {
                  var a = s[r];
                  if (
                    "JSXExpressionContainer" === a.type &&
                    "JSXEmptyExpression" === a.expression.type
                  );
                  else {
                    var o =
                      "\n" === e.original[n] && "JSXText" !== a.type ? "" : " ";
                    e.appendLeft(n, "," + o);
                  }
                  if ("JSXText" === a.type) {
                    var p = qe(a.value, r === s.length - 1);
                    e.overwrite(a.start, a.end, p);
                  }
                  n = a.end;
                }
              }
            }),
            e
          );
        })(Qt),
        Je = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.transpile = function(e, i) {
              e.remove(this.start, this.expression.start),
                e.remove(this.expression.end, this.end),
                t.prototype.transpile.call(this, e, i);
            }),
            e
          );
        })(Qt),
        We = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            e
          );
        })(Xe),
        He = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.transpile = function(e, i) {
              t.prototype.transpile.call(this, e, i),
                e.overwrite(
                  this.start,
                  this.name.start,
                  this.program.jsx + "( "
                );
              var s =
                "JSXIdentifier" === this.name.type &&
                this.name.name[0] === this.name.name[0].toLowerCase();
              s && e.prependRight(this.name.start, "'");
              var r = this.attributes.length,
                n = this.name.end;
              if (r) {
                var a,
                  o,
                  p,
                  h = !1;
                for (a = 0; a < r; a += 1)
                  if ("JSXSpreadAttribute" === this.attributes[a].type) {
                    h = !0;
                    break;
                  }
                for (n = this.attributes[0].end, a = 0; a < r; a += 1) {
                  var c = this.attributes[a];
                  if (
                    (a > 0 &&
                      (c.start === n
                        ? e.prependRight(n, ", ")
                        : e.overwrite(n, c.start, ", ")),
                    h && "JSXSpreadAttribute" !== c.type)
                  ) {
                    var l = this.attributes[a - 1],
                      u = this.attributes[a + 1];
                    (l && "JSXSpreadAttribute" !== l.type) ||
                      e.prependRight(c.start, "{ "),
                      (u && "JSXSpreadAttribute" !== u.type) ||
                        e.appendLeft(c.end, " }");
                  }
                  n = c.end;
                }
                if (h)
                  if (1 === r) p = s ? "'," : ",";
                  else {
                    if (!this.program.options.objectAssign)
                      throw new se(
                        "Mixed JSX attributes ending in spread requires specified objectAssign option with 'Object.assign' or polyfill helper.",
                        this
                      );
                    (p = s
                      ? "', " + this.program.options.objectAssign + "({},"
                      : ", " + this.program.options.objectAssign + "({},"),
                      (o = ")");
                  }
                else (p = s ? "', {" : ", {"), (o = " }");
                e.prependRight(this.name.end, p),
                  o && e.appendLeft(this.attributes[r - 1].end, o);
              } else
                e.appendLeft(this.name.end, s ? "', null" : ", null"),
                  (n = this.name.end);
              this.selfClosing
                ? e.overwrite(n, this.end, this.attributes.length ? ")" : " )")
                : e.remove(n, this.end);
            }),
            e
          );
        })(Qt),
        ze = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.transpile = function(t) {
              t.overwrite(
                this.start,
                this.end,
                this.program.jsx + "( React.Fragment, null"
              );
            }),
            e
          );
        })(Qt),
        Ge = (function(t) {
          function e() {
            t.apply(this, arguments);
          }
          return (
            t && (e.__proto__ = t),
            (e.prototype = Object.create(t && t.prototype)),
            (e.prototype.constructor = e),
            (e.prototype.transpile = function(e, i) {
              e.remove(this.start, this.argument.start),
                e.remove(this.argument.end, this.end),
                t.prototype.transpile.call(this, e, i);
            }),
            e
          );
        })(Qt),
        Qe = /[\u2028-\u2029]/g,
        Ke = {
          ArrayExpression: de,
          ArrowFunctionExpression: me,
          AssignmentExpression: ge,
          BinaryExpression: ve,
          BreakStatement: be,
          CallExpression: _e,
          ClassBody: ke,
          ClassDeclaration: Se,
          ClassExpression: we,
          ContinueStatement: Ee,
          DoWhileStatement: Ie,
          ExportNamedDeclaration: Ce,
          ExportDefaultDeclaration: Ae,
          ForStatement: Le,
          ForInStatement: Pe,
          ForOfStatement: Ne,
          FunctionDeclaration: Te,
          FunctionExpression: Re,
          Identifier: Oe,
          IfStatement: je,
          ImportDeclaration: Ve,
          ImportDefaultSpecifier: De,
          ImportSpecifier: Fe,
          JSXAttribute: Be,
          JSXClosingElement: Me,
          JSXClosingFragment: Ue,
          JSXElement: Xe,
          JSXExpressionContainer: Je,
          JSXFragment: We,
          JSXOpeningElement: He,
          JSXOpeningFragment: ze,
          JSXSpreadAttribute: Ge,
          Literal: (function(t) {
            function e() {
              t.apply(this, arguments);
            }
            return (
              t && (e.__proto__ = t),
              (e.prototype = Object.create(t && t.prototype)),
              (e.prototype.constructor = e),
              (e.prototype.initialise = function() {
                "string" == typeof this.value &&
                  this.program.indentExclusionElements.push(this);
              }),
              (e.prototype.transpile = function(t, e) {
                if (
                  (e.numericLiteral &&
                    this.raw.match(/^0[bo]/i) &&
                    t.overwrite(this.start, this.end, String(this.value), {
                      storeName: !0,
                      contentOnly: !0
                    }),
                  this.regex)
                ) {
                  var i = this.regex,
                    s = i.pattern,
                    n = i.flags;
                  if (e.stickyRegExp && /y/.test(n))
                    throw new se(
                      "Regular expression sticky flag is not supported",
                      this
                    );
                  e.unicodeRegExp &&
                    /u/.test(n) &&
                    t.overwrite(
                      this.start,
                      this.end,
                      "/" + r()(s, n) + "/" + n.replace("u", ""),
                      { contentOnly: !0 }
                    );
                } else
                  "string" == typeof this.value &&
                    this.value.match(Qe) &&
                    t.overwrite(
                      this.start,
                      this.end,
                      this.raw.replace(Qe, function(t) {
                        return "\u2028" == t ? "\\u2028" : "\\u2029";
                      }),
                      { contentOnly: !0 }
                    );
              }),
              e
            );
          })(Qt),
          MemberExpression: (function(t) {
            function e() {
              t.apply(this, arguments);
            }
            return (
              t && (e.__proto__ = t),
              (e.prototype = Object.create(t && t.prototype)),
              (e.prototype.constructor = e),
              (e.prototype.transpile = function(e, i) {
                i.reservedProperties &&
                  Yt[this.property.name] &&
                  (e.overwrite(this.object.end, this.property.start, "['"),
                  e.appendLeft(this.property.end, "']")),
                  t.prototype.transpile.call(this, e, i);
              }),
              e
            );
          })(Qt),
          NewExpression: (function(t) {
            function e() {
              t.apply(this, arguments);
            }
            return (
              t && (e.__proto__ = t),
              (e.prototype = Object.create(t && t.prototype)),
              (e.prototype.constructor = e),
              (e.prototype.initialise = function(e) {
                if (e.spreadRest && this.arguments.length)
                  for (
                    var i = this.findLexicalBoundary(),
                      s = this.arguments.length;
                    s--;

                  ) {
                    var r = this.arguments[s];
                    if ("SpreadElement" === r.type && le(r.argument)) {
                      this.argumentsArrayAlias = i.getArgumentsArrayAlias();
                      break;
                    }
                  }
                t.prototype.initialise.call(this, e);
              }),
              (e.prototype.transpile = function(e, i) {
                if (
                  (t.prototype.transpile.call(this, e, i),
                  i.spreadRest && this.arguments.length)
                ) {
                  var s = this.arguments[0];
                  ue(
                    e,
                    this.arguments,
                    s.start,
                    this.argumentsArrayAlias,
                    !0
                  ) &&
                    (e.prependRight(
                      this.start + "new".length,
                      " (Function.prototype.bind.apply("
                    ),
                    e.overwrite(
                      this.callee.end,
                      s.start,
                      ", [ null ].concat( "
                    ),
                    e.appendLeft(this.end, " ))"));
                }
                this.arguments.length &&
                  fe(e, this.arguments[this.arguments.length - 1].end);
              }),
              e
            );
          })(Qt),
          ObjectExpression: (function(t) {
            function e() {
              t.apply(this, arguments);
            }
            return (
              t && (e.__proto__ = t),
              (e.prototype = Object.create(t && t.prototype)),
              (e.prototype.constructor = e),
              (e.prototype.transpile = function(e, i) {
                t.prototype.transpile.call(this, e, i);
                for (
                  var s = this.start + 1,
                    r = 0,
                    n = 0,
                    a = null,
                    o = null,
                    p = 0;
                  p < this.properties.length;
                  ++p
                ) {
                  var h = this.properties[p];
                  "SpreadElement" === h.type
                    ? ((r += 1), null === a && (a = p))
                    : h.computed &&
                      i.computedProperty &&
                      ((n += 1), null === o && (o = p));
                }
                if (!r || i.objectRestSpread || (n && i.computedProperty)) {
                  if (r) {
                    if (!this.program.options.objectAssign)
                      throw new se(
                        "Object spread operator requires specified objectAssign option with 'Object.assign' or polyfill helper.",
                        this
                      );
                    for (var c = this.properties.length; c--; ) {
                      var l = this.properties[c];
                      if ("Property" === l.type && !n) {
                        var u = this.properties[c - 1],
                          d = this.properties[c + 1];
                        (u && "Property" === u.type) ||
                          e.prependRight(l.start, "{"),
                          (d && "Property" === d.type) ||
                            e.appendLeft(l.end, "}");
                      }
                      "SpreadElement" === l.type &&
                        (e.remove(l.start, l.argument.start),
                        e.remove(l.argument.end, l.end));
                    }
                    (s = this.properties[0].start),
                      n
                        ? "SpreadElement" === this.properties[0].type
                          ? (e.overwrite(
                              this.start,
                              s,
                              this.program.options.objectAssign + "({}, "
                            ),
                            e.remove(this.end - 1, this.end),
                            e.appendRight(this.end, ")"))
                          : (e.prependLeft(
                              this.start,
                              this.program.options.objectAssign + "("
                            ),
                            e.appendRight(this.end, ")"))
                        : (e.overwrite(
                            this.start,
                            s,
                            this.program.options.objectAssign + "({}, "
                          ),
                          e.overwrite(
                            this.properties[this.properties.length - 1].end,
                            this.end,
                            ")"
                          ));
                  }
                } else (r = 0), (a = null);
                if (n && i.computedProperty) {
                  var f,
                    m,
                    y = this.getIndentation();
                  "VariableDeclarator" === this.parent.type &&
                  1 === this.parent.parent.declarations.length &&
                  "Identifier" === this.parent.id.type
                    ? ((f = !0),
                      (m = this.parent.id.alias || this.parent.id.name))
                    : (("AssignmentExpression" === this.parent.type &&
                        "ExpressionStatement" === this.parent.parent.type &&
                        "Identifier" === this.parent.left.type) ||
                        ("AssignmentPattern" === this.parent.type &&
                          "Identifier" === this.parent.left.type)) &&
                      ((f = !0),
                      (m = this.parent.left.alias || this.parent.left.name)),
                    r && (f = !1),
                    (m = this.findScope(!1).resolveName(m));
                  var g = s,
                    v = this.end;
                  f ||
                    (null === a || o < a
                      ? ((m = this.findScope(!0).createDeclaration("obj")),
                        e.prependRight(this.start, "( " + m + " = "))
                      : (m = null));
                  for (
                    var x, b = this.properties.length, _ = !1, k = !0, S = 0;
                    S < b;
                    S += 1
                  ) {
                    var w = this.properties[S],
                      E = S > 0 ? this.properties[S - 1].end : g;
                    if ("Property" === w.type && (w.computed || (x && !r))) {
                      if ((0 === S && (E = this.start + 1), (x = w), m)) {
                        var A =
                          (f ? ";\n" + y + m : ", " + m) +
                          ("Literal" === w.key.type || w.computed ? "" : ".");
                        E < w.start
                          ? e.overwrite(E, w.start, A)
                          : e.prependRight(w.start, A);
                      } else {
                        var C =
                          (m = this.findScope(!0).createDeclaration("obj")) +
                          (w.computed ? "" : ".");
                        e.appendRight(w.start, "( " + m + " = {}, " + C);
                      }
                      var I = w.key.end;
                      if (w.computed) {
                        for (; "]" !== e.original[I]; ) I += 1;
                        I += 1;
                      }
                      "Literal" !== w.key.type || w.computed
                        ? w.shorthand ||
                          (w.method && !w.computed && i.conciseMethodProperty)
                          ? e.overwrite(
                              w.key.start,
                              w.key.end,
                              e.slice(w.key.start, w.key.end).replace(/:/, " =")
                            )
                          : (w.value.start > I && e.remove(I, w.value.start),
                            e.prependLeft(I, " = "))
                        : e.overwrite(
                            w.start,
                            w.key.end + 1,
                            "[" + e.slice(w.start, w.key.end) + "] = "
                          ),
                        !w.method ||
                          (!w.computed && i.conciseMethodProperty) ||
                          (w.value.generator && e.remove(w.start, w.key.start),
                          e.prependRight(
                            w.value.start,
                            "function" + (w.value.generator ? "*" : "") + " "
                          ));
                    } else
                      "SpreadElement" === w.type
                        ? m &&
                          S > 0 &&
                          (x || (x = this.properties[S - 1]),
                          e.appendLeft(x.end, ", " + m + " )"),
                          (x = null),
                          (m = null))
                        : (!k &&
                            r &&
                            (e.prependRight(w.start, "{"),
                            e.appendLeft(w.end, "}")),
                          (_ = !0));
                    if (k && ("SpreadElement" === w.type || w.computed)) {
                      var L = _
                        ? this.properties[this.properties.length - 1].end
                        : this.end - 1;
                      "," == e.original[L] && ++L;
                      var P = e.slice(L, v);
                      e.prependLeft(E, P), e.remove(L, v), (k = !1);
                    }
                    var N = w.end;
                    if (S < b - 1 && !_) for (; "," !== e.original[N]; ) N += 1;
                    else S == b - 1 && (N = this.end);
                    w.end != N &&
                      e.overwrite(w.end, N, "", { contentOnly: !0 });
                  }
                  !f && m && e.appendLeft(x.end, ", " + m + " )");
                }
              }),
              e
            );
          })(Qt),
          Property: (function(t) {
            function e() {
              t.apply(this, arguments);
            }
            return (
              t && (e.__proto__ = t),
              (e.prototype = Object.create(t && t.prototype)),
              (e.prototype.constructor = e),
              (e.prototype.initialise = function(e) {
                if (
                  ("get" === this.kind || "set" === this.kind) &&
                  e.getterSetter
                )
                  throw new se(
                    "getters and setters are not supported. Use `transforms: { getterSetter: false }` to skip transformation and disable this error",
                    this
                  );
                t.prototype.initialise.call(this, e);
              }),
              (e.prototype.transpile = function(e, i) {
                if (
                  (t.prototype.transpile.call(this, e, i),
                  i.conciseMethodProperty &&
                    !this.computed &&
                    "ObjectPattern" !== this.parent.type)
                )
                  if (this.shorthand)
                    e.prependRight(this.start, this.key.name + ": ");
                  else if (this.method) {
                    var s = "";
                    !1 !== this.program.options.namedFunctionExpressions &&
                      (s =
                        " " +
                        (s =
                          "Literal" === this.key.type &&
                          "number" == typeof this.key.value
                            ? ""
                            : "Identifier" === this.key.type
                            ? Yt[this.key.name] ||
                              !/^[a-z_$][a-z0-9_$]*$/i.test(this.key.name) ||
                              this.value.body.scope.references[this.key.name]
                              ? this.findScope(!0).createIdentifier(
                                  this.key.name
                                )
                              : this.key.name
                            : this.findScope(!0).createIdentifier(
                                this.key.value
                              ))),
                      this.value.generator &&
                        e.remove(this.start, this.key.start),
                      e.appendLeft(
                        this.key.end,
                        ": function" + (this.value.generator ? "*" : "") + s
                      );
                  }
                i.reservedProperties &&
                  Yt[this.key.name] &&
                  (e.prependRight(this.key.start, "'"),
                  e.appendLeft(this.key.end, "'"));
              }),
              e
            );
          })(Qt),
          ReturnStatement: (function(t) {
            function e() {
              t.apply(this, arguments);
            }
            return (
              t && (e.__proto__ = t),
              (e.prototype = Object.create(t && t.prototype)),
              (e.prototype.constructor = e),
              (e.prototype.initialise = function(t) {
                (this.loop = this.findNearest(xe)),
                  (this.nearestFunction = this.findNearest(/Function/)),
                  this.loop &&
                    (!this.nearestFunction ||
                      this.loop.depth > this.nearestFunction.depth) &&
                    ((this.loop.canReturn = !0), (this.shouldWrap = !0)),
                  this.argument && this.argument.initialise(t);
              }),
              (e.prototype.transpile = function(t, e) {
                var i =
                  this.shouldWrap &&
                  this.loop &&
                  this.loop.shouldRewriteAsFunction;
                this.argument
                  ? (i && t.prependRight(this.argument.start, "{ v: "),
                    this.argument.transpile(t, e),
                    i && t.appendLeft(this.argument.end, " }"))
                  : i && t.appendLeft(this.start + 6, " {}");
              }),
              e
            );
          })(Qt),
          Super: (function(t) {
            function e() {
              t.apply(this, arguments);
            }
            return (
              t && (e.__proto__ = t),
              (e.prototype = Object.create(t && t.prototype)),
              (e.prototype.constructor = e),
              (e.prototype.initialise = function(t) {
                if (t.classes) {
                  if (
                    ((this.method = this.findNearest("MethodDefinition")),
                    !this.method)
                  )
                    throw new se("use of super outside class method", this);
                  var e = this.findNearest("ClassBody").parent;
                  if (
                    ((this.superClassName =
                      e.superClass && (e.superClass.name || "superclass")),
                    !this.superClassName)
                  )
                    throw new se("super used in base class", this);
                  if (
                    ((this.isCalled =
                      "CallExpression" === this.parent.type &&
                      this === this.parent.callee),
                    "constructor" !== this.method.kind && this.isCalled)
                  )
                    throw new se(
                      "super() not allowed outside class constructor",
                      this
                    );
                  if (
                    ((this.isMember = "MemberExpression" === this.parent.type),
                    !this.isCalled && !this.isMember)
                  )
                    throw new se(
                      "Unexpected use of `super` (expected `super(...)` or `super.*`)",
                      this
                    );
                }
                if (t.arrow) {
                  var i = this.findLexicalBoundary(),
                    s = this.findNearest("ArrowFunctionExpression"),
                    r = this.findNearest(xe);
                  s && s.depth > i.depth && (this.thisAlias = i.getThisAlias()),
                    r &&
                      r.body.contains(this) &&
                      r.depth > i.depth &&
                      (this.thisAlias = i.getThisAlias());
                }
              }),
              (e.prototype.transpile = function(t, e) {
                if (e.classes) {
                  var i =
                    this.isCalled || this.method.static
                      ? this.superClassName
                      : this.superClassName + ".prototype";
                  t.overwrite(this.start, this.end, i, {
                    storeName: !0,
                    contentOnly: !0
                  });
                  var s = this.isCalled ? this.parent : this.parent.parent;
                  if (s && "CallExpression" === s.type) {
                    this.noCall || t.appendLeft(s.callee.end, ".call");
                    var r = this.thisAlias || "this";
                    s.arguments.length
                      ? t.appendLeft(s.arguments[0].start, r + ", ")
                      : t.appendLeft(s.end - 1, "" + r);
                  }
                }
              }),
              e
            );
          })(Qt),
          TaggedTemplateExpression: (function(t) {
            function e() {
              t.apply(this, arguments);
            }
            return (
              t && (e.__proto__ = t),
              (e.prototype = Object.create(t && t.prototype)),
              (e.prototype.constructor = e),
              (e.prototype.initialise = function(e) {
                if (e.templateString && !e.dangerousTaggedTemplateString)
                  throw new se(
                    "Tagged template strings are not supported. Use `transforms: { templateString: false }` to skip transformation and disable this error, or `transforms: { dangerousTaggedTemplateString: true }` if you know what you're doing",
                    this
                  );
                t.prototype.initialise.call(this, e);
              }),
              (e.prototype.transpile = function(e, i) {
                if (i.templateString && i.dangerousTaggedTemplateString) {
                  var s = this.quasi.expressions
                      .concat(this.quasi.quasis)
                      .sort(function(t, e) {
                        return t.start - e.start;
                      }),
                    r = this.program.body.scope,
                    n = this.quasi.quasis
                      .map(function(t) {
                        return JSON.stringify(t.value.cooked);
                      })
                      .join(", "),
                    a = this.program.templateLiteralQuasis[n];
                  a ||
                    ((a = r.createIdentifier("templateObject")),
                    e.prependRight(
                      this.program.prependAt,
                      "var " + a + " = Object.freeze([" + n + "]);\n"
                    ),
                    (this.program.templateLiteralQuasis[n] = a)),
                    e.overwrite(this.tag.end, s[0].start, "(" + a);
                  var o = s[0].start;
                  s.forEach(function(t) {
                    "TemplateElement" === t.type
                      ? e.remove(o, t.end)
                      : e.overwrite(o, t.start, ", "),
                      (o = t.end);
                  }),
                    e.overwrite(o, this.end, ")");
                }
                t.prototype.transpile.call(this, e, i);
              }),
              e
            );
          })(Qt),
          TemplateElement: (function(t) {
            function e() {
              t.apply(this, arguments);
            }
            return (
              t && (e.__proto__ = t),
              (e.prototype = Object.create(t && t.prototype)),
              (e.prototype.constructor = e),
              (e.prototype.initialise = function() {
                this.program.indentExclusionElements.push(this);
              }),
              e
            );
          })(Qt),
          TemplateLiteral: (function(t) {
            function e() {
              t.apply(this, arguments);
            }
            return (
              t && (e.__proto__ = t),
              (e.prototype = Object.create(t && t.prototype)),
              (e.prototype.constructor = e),
              (e.prototype.transpile = function(e, i) {
                if (
                  (t.prototype.transpile.call(this, e, i),
                  i.templateString &&
                    "TaggedTemplateExpression" !== this.parent.type)
                ) {
                  var s = this.expressions
                    .concat(this.quasis)
                    .sort(function(t, e) {
                      return t.start - e.start || t.end - e.end;
                    })
                    .filter(function(t, e) {
                      return (
                        "TemplateElement" !== t.type || !!t.value.raw || !e
                      );
                    });
                  if (s.length >= 3) {
                    var r = s[0],
                      n = s[2];
                    "TemplateElement" === r.type &&
                      "" === r.value.raw &&
                      "TemplateElement" === n.type &&
                      s.shift();
                  }
                  var a = !(
                    (1 === this.quasis.length &&
                      0 === this.expressions.length) ||
                    "TemplateLiteral" === this.parent.type ||
                    "AssignmentExpression" === this.parent.type ||
                    "AssignmentPattern" === this.parent.type ||
                    "VariableDeclarator" === this.parent.type ||
                    ("BinaryExpression" === this.parent.type &&
                      "+" === this.parent.operator)
                  );
                  a && e.appendRight(this.start, "(");
                  var o = this.start;
                  s.forEach(function(t, i) {
                    var s = 0 === i ? (a ? "(" : "") : " + ";
                    if ("TemplateElement" === t.type)
                      e.overwrite(o, t.end, s + JSON.stringify(t.value.cooked));
                    else {
                      var r = "Identifier" !== t.type;
                      r && (s += "("),
                        e.remove(o, t.start),
                        s && e.prependRight(t.start, s),
                        r && e.appendLeft(t.end, ")");
                    }
                    o = t.end;
                  }),
                    a && e.appendLeft(o, ")"),
                    e.overwrite(o, this.end, "", { contentOnly: !0 });
                }
              }),
              e
            );
          })(Qt),
          ThisExpression: (function(t) {
            function e() {
              t.apply(this, arguments);
            }
            return (
              t && (e.__proto__ = t),
              (e.prototype = Object.create(t && t.prototype)),
              (e.prototype.constructor = e),
              (e.prototype.initialise = function(t) {
                var e = this.findLexicalBoundary();
                if (t.letConst)
                  for (var i = this.findNearest(xe); i && i.depth > e.depth; )
                    i.thisRefs.push(this), (i = i.parent.findNearest(xe));
                if (t.arrow) {
                  var s = this.findNearest("ArrowFunctionExpression");
                  s && s.depth > e.depth && (this.alias = e.getThisAlias());
                }
              }),
              (e.prototype.transpile = function(t) {
                this.alias &&
                  t.overwrite(this.start, this.end, this.alias, {
                    storeName: !0,
                    contentOnly: !0
                  });
              }),
              e
            );
          })(Qt),
          UpdateExpression: (function(t) {
            function e() {
              t.apply(this, arguments);
            }
            return (
              t && (e.__proto__ = t),
              (e.prototype = Object.create(t && t.prototype)),
              (e.prototype.constructor = e),
              (e.prototype.initialise = function(e) {
                if ("Identifier" === this.argument.type) {
                  var i = this.findScope(!1).findDeclaration(
                      this.argument.name
                    ),
                    s = i && i.node.ancestor(3);
                  s &&
                    "ForStatement" === s.type &&
                    s.body.contains(this) &&
                    (s.reassigned[this.argument.name] = !0);
                }
                t.prototype.initialise.call(this, e);
              }),
              (e.prototype.transpile = function(e, i) {
                "Identifier" === this.argument.type &&
                  ye(this.argument, this.findScope(!1)),
                  t.prototype.transpile.call(this, e, i);
              }),
              e
            );
          })(Qt),
          VariableDeclaration: (function(t) {
            function e() {
              t.apply(this, arguments);
            }
            return (
              t && (e.__proto__ = t),
              (e.prototype = Object.create(t && t.prototype)),
              (e.prototype.constructor = e),
              (e.prototype.initialise = function(t) {
                (this.scope = this.findScope("var" === this.kind)),
                  this.declarations.forEach(function(e) {
                    return e.initialise(t);
                  });
              }),
              (e.prototype.transpile = function(t, e) {
                var i = this,
                  s = this.getIndentation(),
                  r = this.kind;
                if (
                  (e.letConst &&
                    "var" !== r &&
                    ((r = "var"),
                    t.overwrite(this.start, this.start + this.kind.length, r, {
                      contentOnly: !0,
                      storeName: !0
                    })),
                  e.destructuring &&
                    "ForOfStatement" !== this.parent.type &&
                    "ForInStatement" !== this.parent.type)
                ) {
                  var n,
                    a = this.start;
                  this.declarations.forEach(function(r, o) {
                    if ((r.transpile(t, e), "Identifier" === r.id.type))
                      o > 0 &&
                        "Identifier" !== i.declarations[o - 1].id.type &&
                        t.overwrite(a, r.id.start, "var ");
                    else {
                      var p = xe.test(i.parent.type);
                      0 === o
                        ? t.remove(a, r.id.start)
                        : t.overwrite(a, r.id.start, ";\n" + s);
                      var h = "Identifier" === r.init.type && !r.init.rewritten,
                        c = h
                          ? r.init.alias || r.init.name
                          : r.findScope(!0).createIdentifier("ref");
                      a = r.start;
                      var l = [];
                      h
                        ? t.remove(r.id.end, r.end)
                        : l.push(function(e, i, s) {
                            t.prependRight(r.id.end, "var " + c),
                              t.appendLeft(r.init.end, "" + s),
                              t.move(r.id.end, r.end, e);
                          });
                      var u = r.findScope(!1);
                      ae(
                        t,
                        function(t) {
                          return u.createIdentifier(t);
                        },
                        function(t) {
                          var e = t.name;
                          return u.resolveName(e);
                        },
                        r.id,
                        c,
                        p,
                        l
                      );
                      var d = p ? "var " : "",
                        f = p ? ", " : ";\n" + s;
                      l.forEach(function(t, e) {
                        o === i.declarations.length - 1 &&
                          e === l.length - 1 &&
                          (f = p ? "" : ";"),
                          t(r.start, 0 === e ? d : "", f);
                      });
                    }
                    (a = r.end), (n = "Identifier" !== r.id.type);
                  }),
                    n &&
                      this.end > a &&
                      t.overwrite(a, this.end, "", { contentOnly: !0 });
                } else
                  this.declarations.forEach(function(i) {
                    i.transpile(t, e);
                  });
              }),
              e
            );
          })(Qt),
          VariableDeclarator: (function(t) {
            function e() {
              t.apply(this, arguments);
            }
            return (
              t && (e.__proto__ = t),
              (e.prototype = Object.create(t && t.prototype)),
              (e.prototype.constructor = e),
              (e.prototype.initialise = function(e) {
                var i = this.parent.kind;
                "let" === i &&
                  "ForStatement" === this.parent.parent.type &&
                  (i = "for.let"),
                  this.parent.scope.addDeclaration(this.id, i),
                  t.prototype.initialise.call(this, e);
              }),
              (e.prototype.transpile = function(t, e) {
                if (!this.init && e.letConst && "var" !== this.parent.kind) {
                  var i = this.findNearest(
                    /Function|^For(In|Of)?Statement|^(?:Do)?WhileStatement/
                  );
                  !i ||
                    /Function/.test(i.type) ||
                    this.isLeftDeclaratorOfLoop() ||
                    t.appendLeft(this.id.end, " = (void 0)");
                }
                this.id && this.id.transpile(t, e),
                  this.init && this.init.transpile(t, e);
              }),
              (e.prototype.isLeftDeclaratorOfLoop = function() {
                return (
                  this.parent &&
                  "VariableDeclaration" === this.parent.type &&
                  this.parent.parent &&
                  ("ForInStatement" === this.parent.parent.type ||
                    "ForOfStatement" === this.parent.parent.type) &&
                  this.parent.parent.left &&
                  this.parent.parent.left.declarations[0] === this
                );
              }),
              e
            );
          })(Qt),
          WhileStatement: Ie
        },
        $e = { Program: ["body"], Literal: [] },
        Ye = {
          IfStatement: "consequent",
          ForStatement: "body",
          ForInStatement: "body",
          ForOfStatement: "body",
          WhileStatement: "body",
          DoWhileStatement: "body",
          ArrowFunctionExpression: "body"
        };
      function Ze(t, e, i, s) {
        (this.type = "Root"),
          (this.jsx = s.jsx || "React.createElement"),
          (this.options = s),
          (this.source = t),
          (this.magicString = new n.a(t)),
          (this.ast = e),
          (this.depth = 0),
          (function t(e, i) {
            if (e)
              if ("length" in e) for (var s = e.length; s--; ) t(e[s], i);
              else if (!e.__wrapped) {
                (e.__wrapped = !0),
                  $e[e.type] ||
                    ($e[e.type] = Object.keys(e).filter(function(t) {
                      return "object" == typeof e[t];
                    }));
                var r = Ye[e.type];
                if (r && "BlockStatement" !== e[r].type) {
                  var n = e[r];
                  e[r] = {
                    start: n.start,
                    end: n.end,
                    type: "BlockStatement",
                    body: [n],
                    synthetic: !0
                  };
                }
                (e.parent = i),
                  (e.program = i.program || i),
                  (e.depth = i.depth + 1),
                  (e.keys = $e[e.type]),
                  (e.indentation = void 0);
                for (var a = 0, o = $e[e.type]; a < o.length; a += 1) {
                  var p = o[a];
                  t(e[p], e);
                }
                e.program.magicString.addSourcemapLocation(e.start),
                  e.program.magicString.addSourcemapLocation(e.end);
                var h = ("BlockStatement" === e.type ? ce : Ke[e.type]) || Qt;
                e.__proto__ = h.prototype;
              }
          })((this.body = e), this),
          (this.body.__proto__ = ce.prototype),
          (this.templateLiteralQuasis = Object.create(null));
        for (var r = 0; r < this.body.body.length; ++r)
          if (!this.body.body[r].directive) {
            this.prependAt = this.body.body[r].start;
            break;
          }
        (this.objectWithoutPropertiesHelper = null),
          (this.indentExclusionElements = []),
          this.body.initialise(i),
          (this.indentExclusions = Object.create(null));
        for (var a = 0, o = this.indentExclusionElements; a < o.length; a += 1)
          for (var p = o[a], h = p.start; h < p.end; h += 1)
            this.indentExclusions[h] = !0;
        this.body.transpile(this.magicString, i);
      }
      Ze.prototype = {
        export: function(t) {
          return (
            void 0 === t && (t = {}),
            {
              code: this.magicString.toString(),
              map: this.magicString.generateMap({
                file: t.file,
                source: t.source,
                includeContent: !1 !== t.includeContent
              })
            }
          );
        },
        findNearest: function() {
          return null;
        },
        findScope: function() {
          return null;
        },
        getObjectWithoutPropertiesHelper: function(t) {
          return (
            this.objectWithoutPropertiesHelper ||
              ((this.objectWithoutPropertiesHelper = this.body.scope.createIdentifier(
                "objectWithoutProperties"
              )),
              t.prependLeft(
                this.prependAt,
                "function " +
                  this.objectWithoutPropertiesHelper +
                  " (obj, exclude) { var target = {}; for (var k in obj) if (Object.prototype.hasOwnProperty.call(obj, k) && exclude.indexOf(k) === -1) target[k] = obj[k]; return target; }\n"
              )),
            this.objectWithoutPropertiesHelper
          );
        }
      };
      var ti = {
          chrome: {
            48: 610719,
            49: 652287,
            50: 783359,
            51: 783359,
            52: 1045503,
            53: 1045503,
            54: 1045503,
            55: 3142655,
            56: 3142655,
            57: 3142655,
            58: 4191231,
            59: 4191231,
            60: 8385535,
            61: 8385535,
            62: 8385535,
            63: 8385535,
            64: 8385535,
            65: 8385535,
            66: 8385535,
            67: 8385535,
            68: 8385535,
            69: 8385535,
            70: 8385535,
            71: 8385535
          },
          firefox: {
            43: 643515,
            44: 643515,
            45: 643519,
            46: 774591,
            47: 774655,
            48: 774655,
            49: 774655,
            50: 774655,
            51: 775167,
            52: 4191231,
            53: 4191231,
            54: 4191231,
            55: 8385535,
            56: 8385535,
            57: 8385535,
            58: 8385535,
            59: 8385535,
            60: 8385535,
            61: 8385535,
            62: 8385535,
            63: 8385535,
            64: 8385535
          },
          safari: {
            8: 524297,
            9: 594141,
            10: 1831935,
            10.1: 4191231,
            11: 4191231,
            11.1: 8385535,
            12: 8385535
          },
          ie: { 8: 0, 9: 524289, 10: 524289, 11: 524289 },
          edge: {
            12: 610459,
            13: 774559,
            14: 2085887,
            15: 4183039,
            16: 4183039,
            17: 4183039,
            18: 4183039,
            19: 4183039
          },
          node: {
            "0.10": 524289,
            0.12: 524417,
            4: 594335,
            5: 594335,
            6: 783359,
            8: 4191231,
            8.3: 8385535,
            8.7: 8385535,
            "8.10": 8385535
          }
        },
        ei = [
          "getterSetter",
          "arrow",
          "classes",
          "computedProperty",
          "conciseMethodProperty",
          "defaultParameter",
          "destructuring",
          "forOf",
          "generator",
          "letConst",
          "moduleExport",
          "moduleImport",
          "numericLiteral",
          "parameterDestructuring",
          "spreadRest",
          "stickyRegExp",
          "templateString",
          "unicodeRegExp",
          "exponentiation",
          "reservedProperties",
          "trailingFunctionCommas",
          "asyncAwait",
          "objectRestSpread"
        ],
        ii = X.extend(zt, Jt()),
        si = ["dangerousTaggedTemplateString", "dangerousForOf"];
      function ri(t, e) {
        var i;
        void 0 === e && (e = {});
        var s = null;
        try {
          (i = ii.parse(t, {
            ecmaVersion: 10,
            preserveParens: !0,
            sourceType: "module",
            allowReturnOutsideFunction: !0,
            onComment: function(t, e) {
              if (!s) {
                var i = /@jsx\s+([^\s]+)/.exec(e);
                i && (s = i[1]);
              }
            }
          })),
            (e.jsx = s || e.jsx);
        } catch (n) {
          throw ((n.snippet = ie(t, n.loc)),
          (n.toString = function() {
            return n.name + ": " + n.message + "\n" + n.snippet;
          }),
          n);
        }
        var r = (function(t) {
          var e = Object.keys(t).length ? 8388607 : 524289;
          Object.keys(t).forEach(function(i) {
            var s = ti[i];
            if (!s)
              throw new Error(
                "Unknown environment '" +
                  i +
                  "'. Please raise an issue at https://github.com/Rich-Harris/buble/issues"
              );
            var r = t[i];
            if (!(r in s))
              throw new Error(
                "Support data exists for the following versions of " +
                  i +
                  ": " +
                  Object.keys(s).join(", ") +
                  ". Please raise an issue at https://github.com/Rich-Harris/buble/issues"
              );
            var n = s[r];
            e &= n;
          });
          var i = Object.create(null);
          return (
            ei.forEach(function(t, s) {
              i[t] = !(e & (1 << s));
            }),
            si.forEach(function(t) {
              i[t] = !1;
            }),
            i
          );
        })(e.target || {});
        return (
          Object.keys(e.transforms || {}).forEach(function(t) {
            if ("modules" === t)
              return (
                "moduleImport" in e.transforms ||
                  (r.moduleImport = e.transforms.modules),
                void (
                  "moduleExport" in e.transforms ||
                  (r.moduleExport = e.transforms.modules)
                )
              );
            if (!(t in r)) throw new Error("Unknown transform '" + t + "'");
            r[t] = e.transforms[t];
          }),
          !0 === e.objectAssign && (e.objectAssign = "Object.assign"),
          new Ze(t, i, r, e).export(e)
        );
      }
    }
  }
]);
//# sourceMappingURL=f0e45107-1fd5e85683663b7e4e88.js.map
